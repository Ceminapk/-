package com.example

import com.example.data.model.*
import com.example.ui.v216.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk = [35])
class V2162RulesTest {
    private val members = listOf(MemberEntity(fullName = "დავით ბატონიშვილი"), MemberEntity(fullName = "იაკობ დავიდაშვილი"), MemberEntity(fullName = "მოშე ლევი", status = MemberStatus.DECEASED))

    @Test fun `dictation becomes honours with amounts currencies and members`() {
        val r = DebriefParser.parse("დავითმა ფეთიხა 100 ლარი, იაკობმა შელიში 50 დოლარი", members)
        assertEquals(2, r.size)
        assertEquals("დავით ბატონიშვილი", r[0].memberName); assertEquals(AliyahType.PETICHA, r[0].type); assertEquals(100.0, r[0].amount, 0.0); assertEquals("GEL", r[0].currency)
        assertEquals("იაკობ დავიდაშვილი", r[1].memberName); assertEquals(AliyahType.SHLISHI, r[1].type); assertEquals("USD", r[1].currency)
    }

    @Test fun `neder is recognised and deceased members are not matched`() {
        val r = DebriefParser.parse("მოშემ ნედერი 200", members)
        assertEquals(AliyahType.NEDER, r.single().type)
        assertFalse(r.single().matchedMember)
    }

    @Test fun `budget alarm shows shortfall when stipends exceed income`() {
        val now = System.currentTimeMillis()
        val txs = listOf(TransactionEntity(title = "a", type = TransactionType.INCOME, category = FinanceCategory.OTHER_INCOME, amount = 500.0, dateMillis = now))
        val b = BudgetAlarm.status(txs, listOf(KollelStudentEntity(fullName = "x", monthlyStipend = 800.0)), 300.0, now)
        assertTrue(b.alarm); assertEquals(600.0, b.shortfall, 0.001)
    }

    @Test fun `minyan stars rank by attendance`() {
        val rows = List(5) { RegistryEntity(kind = RegistryKind.MINYAN.name, title = "შ", memberName = "A") } + RegistryEntity(kind = RegistryKind.MINYAN.name, title = "შ", memberName = "B")
        val r = MinyanStars.ranking(rows, 0)
        assertEquals("A", r[0].name); assertEquals(2, MinyanStars.stars(r[0].count)); assertEquals(1, MinyanStars.stars(1))
    }

    @Test fun `hazkara uses bat for a woman`() {
        assertTrue(BimahTexts.hazkara("שרה", "רבקה", true).contains("שרה בַּת רבקה"))
    }

    @Test fun `russian dollars and euro are not read as lari`() {
        assertEquals("USD", DebriefParser.currencyOf("шлиши 50 долларов", "GEL"))
        assertEquals("EUR", DebriefParser.currencyOf("ლევი 30 ევრო", "GEL"))
        assertEquals("ILS", DebriefParser.currencyOf("მაფტირი 18 შეკელი", "GEL"))
    }

    @Test fun `a name containing lari keeps the default currency`() {
        val m = listOf(MemberEntity(fullName = "ილარიონ კოხრეიძე"))
        val r = DebriefParser.parse("ილარიონმა ლევი 70", m, "USD").single()
        assertEquals("USD", r.currency); assertEquals("ილარიონ კოხრეიძე", r.memberName)
    }

    @Test fun `surname decides between two members with the same first name`() {
        val m = listOf(MemberEntity(fullName = "დავით ბატონიშვილი"), MemberEntity(fullName = "დავით მიზრახი"))
        assertEquals("დავით მიზრახი", DebriefParser.parse("დავით მიზრახმა ქოჰენი 100", m).single().memberName)
        assertFalse(DebriefParser.parse("დავითმა ქოჰენი 100", m).single().matchedMember)
    }

    @Test fun `number words and thousands are understood`() {
        assertEquals(1500.0, DebriefParser.amountOf("ფეთიხა 1 500 ლარი"), 0.0)
        assertEquals(200.0, DebriefParser.amountOf("ნედერი ორასი ლარი"), 0.0)
    }
}

class SyncRolesTest {
    @Test fun `treasurer edits only finances and deputy only aliyot`() {
        val r = com.example.data.sync.SyncRoles
        assertTrue(r.canWrite("treasurer", "finance")); assertFalse(r.canWrite("treasurer", "aliyot")); assertFalse(r.canRead("treasurer", "aliyot"))
        assertTrue(r.canWrite("deputy", "aliyot")); assertFalse(r.canRead("deputy", "finance")); assertTrue(r.canRead("deputy", "members"))
        assertTrue(r.canWrite("gabbai", "registry")); assertFalse(r.canRead(null, "members"))
    }
}
