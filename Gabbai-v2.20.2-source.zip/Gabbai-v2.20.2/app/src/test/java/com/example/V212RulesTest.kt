package com.example

import com.example.data.model.Catalogs
import com.example.data.model.FinanceCategory
import com.example.data.model.TransactionType
import com.example.ui.components.GuidedTour
import com.example.ui.viewmodel.GabbaiScreen
import com.example.ui.voice.AssistantNav
import org.junit.Assert.*
import org.junit.Test

class V212RulesTest {
    @Test fun otherIncomeIsAnIncomeOperation() {
        val p = Catalogs.operations.first { it.category == FinanceCategory.OTHER_INCOME }
        assertEquals(TransactionType.INCOME, p.type)
        assertTrue(FinanceCategory.OTHER_INCOME in FinanceCategory.values().take(7))
        assertFalse(FinanceCategory.OTHER_INCOME in FinanceCategory.values().drop(7))
    }
    @Test fun assistantNavigatesOnRequest() {
        assertEquals(GabbaiScreen.FINANCES, AssistantNav.route("გადამიყვანე ფინანსებში")?.screen)
        assertEquals(GabbaiScreen.KOLLEL, AssistantNav.route("открой коллель")?.screen)
        assertEquals(GabbaiScreen.SETTINGS, AssistantNav.route("take me to settings")?.screen)
    }
    @Test fun plainQuestionGoesToAi() {
        assertNull(AssistantNav.route("რა არის გაბაის მოვალეობები?"))
    }
    @Test fun tourCoversEverySection() {
        val shown = GuidedTour.steps.map { it.screen }.toSet()
        GabbaiScreen.values().filter { it != GabbaiScreen.TECH_DOCS }.forEach { assertTrue(it.name, it in shown) }
        GuidedTour.start(); repeat(GuidedTour.steps.size) { GuidedTour.next() }
        assertFalse(GuidedTour.running)
    }
}
