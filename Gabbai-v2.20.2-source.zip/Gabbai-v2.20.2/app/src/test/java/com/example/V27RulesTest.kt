package com.example

import com.example.data.model.*
import com.example.ui.calendar.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.util.*

@RunWith(RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk = [35])
class V27RulesTest {
    @Test fun `new congregation roles and status are present`() {
        assertEquals(listOf("მუშა", "დამლაგებელი", "დარაჯი", "გაბაის მოადგილე"), listOf(MemberRole.WORKER, MemberRole.CLEANER, MemberRole.GUARD, MemberRole.DEPUTY_GABBAI).map { it.keyKa })
        assertEquals("არ არის ჯამაათის წევრი", MemberStatus.NON_MEMBER.keyKa)
    }
    @Test fun `tzedakah has other direction`() = assertEquals("სხვა", TzedakahCategory.OTHER.keyKa)
    @Test fun `requested aliyah spellings are exact`() {
        assertEquals("შელიში", AliyahType.SHLISHI.keyKa); assertEquals("რევიყი", AliyahType.REVII.keyKa)
    }
    @Test fun `prayer offsets follow requested rules`() {
        val city = Cities.find("თბილისი")
        val ordinary = JewishCalendar.day(2026, 10, 4, city)
        val (mincha, maariv) = JewishCalendar.prayerTimes(ordinary, city)
        assertEquals(30 * 60_000L, ordinary.sunset!! - mincha!!)
        assertEquals(30 * 60_000L, maariv!! - ordinary.sunset!!)
    }
    @Test fun `Rosh Chodesh eve Maariv is 25 minutes after sunset`() {
        val city = Cities.find("თბილისი")
        val cal = GregorianCalendar(2026, Calendar.JANUARY, 1)
        repeat(366) {
            val info = JewishCalendar.day(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), city)
            val next = cal.clone() as GregorianCalendar; next.add(Calendar.DAY_OF_MONTH,1)
            val nextInfo = JewishCalendar.day(next.get(Calendar.YEAR),next.get(Calendar.MONTH)+1,next.get(Calendar.DAY_OF_MONTH),city)
            if (nextInfo.holidays.any { h -> h.ka == "როშ ხოდეში" }) {
                assertEquals(25*60_000L, JewishCalendar.prayerTimes(info,city).second!!-info.sunset!!); return
            }
            cal.add(Calendar.DAY_OF_MONTH,1)
        }
        fail("Rosh Chodesh eve not found")
    }
    @Test fun `yahrzeit reminder includes anniversary inside lead window`() {
        val nowCal = GregorianCalendar(2026, Calendar.OCTOBER, 4)
        val h = JewishCalendar.toHebrew(2026,10,14)
        val item = YahrzeitEntity(deceasedName="x", relatedMemberId=1, relatedMemberName="y", deathDateMillis=0, hebrewMonth=h.month, hebrewDay=h.day)
        val upcoming = YahrzeitTools.upcoming(item, nowCal.timeInMillis)
        assertNotNull(upcoming); assertTrue(upcoming!!.daysUntil in 9..11)
        assertEquals(1, YahrzeitTools.within(listOf(item), 30, nowCal.timeInMillis).size)
    }
}
