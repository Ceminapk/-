package com.example

import com.example.data.export.XlsxExporter
import com.example.data.model.*
import com.example.ui.components.MemberPhotos
import com.example.ui.viewmodel.GabbaiUiState
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class V210RulesTest {
    private fun tx(id: Long, t: TransactionType, c: FinanceCategory) =
        TransactionEntity(id = id, title = "t$id", amount = 10.0, type = t, category = c, dateMillis = 0L)

    private val state = GabbaiUiState(transactions = listOf(
        tx(1, TransactionType.INCOME, FinanceCategory.MEMBERSHIP_DUES),
        tx(2, TransactionType.INCOME, FinanceCategory.NEDARIM_PLEDGES),
        tx(3, TransactionType.EXPENSE, FinanceCategory.UTILITIES_COMMUNAL)))

    @Test fun onlySelectedModulesExported() {
        val s = XlsxExporter.sheetsFor(state, setOf(XlsxExporter.Module.FINANCES, XlsxExporter.Module.KOLLEL))
        assertEquals(listOf("Finances", "Kollel", "Attendance"), s.map { it.first })
    }
    @Test fun financeTypeFilter() {
        val s = XlsxExporter.sheetsFor(state, setOf(XlsxExporter.Module.FINANCES), TransactionType.EXPENSE)
        assertEquals(2, s[0].second.size) // header + 1
    }
    @Test fun financeCategoryFilter() {
        val s = XlsxExporter.sheetsFor(state, setOf(XlsxExporter.Module.FINANCES), null, FinanceCategory.NEDARIM_PLEDGES)
        assertEquals(2L, (s[0].second[1][0] as Number).toLong())
    }
    @Test fun csvEscapesCommas() {
        assertEquals("\uFEFFa,\"b,c\"\n", XlsxExporter.csvText(listOf(listOf("a", "b,c"))))
    }
    @Test fun cropIsSquareAndInside() {
        val r = MemberPhotos.cropRect(800, 600, 2f, 1f, 0f)
        assertEquals(300, r.width()); assertEquals(300, r.height())
        assertEquals(500, r.left); assertEquals(0, r.top)
    }
}
