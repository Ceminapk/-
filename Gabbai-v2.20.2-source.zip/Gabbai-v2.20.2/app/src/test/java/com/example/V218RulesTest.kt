package com.example

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LibraryBooks
import com.example.data.model.RegistryKind
import com.example.ui.components.OptionIcons
import com.example.ui.screens.QuickAccess
import org.junit.Assert.*
import org.junit.Test

class V218RulesTest {
    @Test fun `every journal has its own icon, not the fallback`() {
        RegistryKind.values().forEach { k ->
            assertNotEquals("missing icon for ${k.name}", Icons.Default.LibraryBooks, OptionIcons.registry(k.name))
        }
    }

    @Test fun `quick access keeps only known modules without duplicates`() {
        val known = setOf("S:ALIYOT", "R:MIKVEH")
        assertEquals(listOf("S:ALIYOT", "R:MIKVEH"), QuickAccess.sanitize(listOf("S:ALIYOT", "X:GONE", "R:MIKVEH", "S:ALIYOT"), known))
    }

    @Test fun `kollel stays reachable from quick access by default`() {
        assertTrue("S:KOLLEL" in QuickAccess.defaults)
    }
}
