package com.example

import android.graphics.Bitmap
import android.graphics.Color
import com.example.data.model.MemberEntity
import com.example.ui.components.MemberPhotos
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class MemberPhotoRulesTest {
    @Test fun `new member has no photo`() = assertEquals("", MemberEntity(fullName = "A").photoBase64)

    @Test fun `large photo shrinks to 256px and under 48KB`() {
        val big = Bitmap.createBitmap(2000, 1000, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLUE) }
        val b64 = MemberPhotos.encode(big)!!
        val back = MemberPhotos.decode(b64)!!
        assertEquals(256, maxOf(back.width, back.height))
        assertTrue(android.util.Base64.decode(b64, 0).size <= 48 * 1024)
    }

    @Test fun `sample size reduces huge camera images`() = assertEquals(8, MemberPhotos.sampleSize(4000, 3000))

    @Test fun `broken or empty photo decodes to null`() {
        assertNull(MemberPhotos.decode(""))
        assertNull(MemberPhotos.decode("not-an-image"))
    }
}
