package com.example

import com.example.data.model.*
import com.example.ui.calendar.HebrewNames
import org.junit.Assert.*
import org.junit.Test

class V216RulesTest {
    @Test fun maaserIsTenPercentMinusGiven() {
        val rows = listOf(RegistryEntity(kind = "MAASER", title = "ხელფასი", amount = 3000.0, paidAmount = 100.0))
        assertEquals(200.0, RegistryRules.maaserDue(rows), 0.001)
    }
    @Test fun goalProgressCapped() {
        assertEquals(0.25f, RegistryRules.goalProgress(RegistryEntity(kind = "GOAL", title = "სეფერ თორა", amount = 20000.0, paidAmount = 5000.0)), 0.001f)
        assertEquals(1f, RegistryRules.goalProgress(RegistryEntity(kind = "GOAL", title = "x", amount = 100.0, paidAmount = 500.0)), 0.001f)
    }
    @Test fun mezuzahCheckIn42Months() {
        val start = java.util.Calendar.getInstance().apply { set(2026, 0, 1) }.timeInMillis
        val next = java.util.Calendar.getInstance().apply { timeInMillis = RegistryRules.nextMezuzahCheck(start) }
        assertEquals(2029, next.get(java.util.Calendar.YEAR)); assertEquals(6, next.get(java.util.Calendar.MONTH))
    }
    @Test fun hebrewNames() {
        assertEquals("יעקב", HebrewNames.of("იაკობი"))
        assertEquals("יעקב בן שרה", HebrewNames.callName("იაკობ", "სარა"))
        assertNull(HebrewNames.of("ზზზ"))
    }
    @Test fun newJournalsExist() {
        listOf("TORAH_PASSPORT", "PUSHKE", "PAROCHET", "GENIZAH", "VOLUNTEER", "KIDDUSH_CAL", "BIKUR_CHOLIM", "NEW_FAMILY", "RAV_QUESTION", "PROGRAM", "FUND", "MAINTENANCE", "GOAL", "MEZUZAH", "MAASER", "CALL_CHAIN")
            .forEach { assertNotNull(RegistryKind.valueOf(it)) }
    }
}
