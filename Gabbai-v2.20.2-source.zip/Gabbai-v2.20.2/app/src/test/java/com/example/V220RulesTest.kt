package com.example

import com.example.ui.screens.HomeRules
import com.example.ui.screens.QuickLayout
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar

class V220RulesTest {
    @Test fun shabbatTimesOnlyFromWednesdayByDefault() {
        assertFalse(HomeRules.showShabbatTimes(false, Calendar.SUNDAY))
        assertFalse(HomeRules.showShabbatTimes(false, Calendar.TUESDAY))
        assertTrue(HomeRules.showShabbatTimes(false, Calendar.WEDNESDAY))
        assertTrue(HomeRules.showShabbatTimes(false, Calendar.SATURDAY))
    }
    @Test fun shabbatTimesDailyShowsEveryDay() {
        assertTrue(HomeRules.showShabbatTimes(true, Calendar.MONDAY))
    }
    @Test fun holidayIconFollowsNextHoliday() {
        assertEquals("🕎", HomeRules.holidayEmoji("ხანუქა"))
        assertEquals("📯", HomeRules.holidayEmoji("როშ ჰაშანა"))
        assertEquals("🍷", HomeRules.holidayEmoji("პესახი (II დღე)"))
        assertEquals("🎭", HomeRules.holidayEmoji("ფურიმი"))
        assertEquals("🌿", HomeRules.holidayEmoji("სუქოთი"))
    }
    @Test fun quickNederSitsInTheMiddle() {
        assertEquals(4, QuickLayout.split(7))
        assertEquals(3, QuickLayout.split(6))
    }
}
