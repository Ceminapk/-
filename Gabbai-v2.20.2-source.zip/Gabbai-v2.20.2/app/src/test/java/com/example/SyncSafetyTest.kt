package com.example
import com.example.data.sync.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
@RunWith(RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk = [35])
class SyncSafetyTest {
    @Test fun `offline changes survive a newer server version`() { assertEquals("conflict", SyncDecision.action(2,1,true,true,true)) }
    @Test fun `a clean device pulls newer server records`() { assertEquals("pull", SyncDecision.action(2,1,true,false,true)) }
    @Test fun `first join with existing records does not delete them`() { assertEquals("conflict", SyncDecision.action(1,0,true,true,true)) }
    @Test fun `only local changes are pushed`() { assertEquals("push", SyncDecision.action(1,1,true,true,true)) }
    @Test fun `a clean synchronized device does nothing`() { assertEquals("none", SyncDecision.action(1,1,true,false,true)) }
    @Test fun `read only sections never push`() { assertEquals("none", SyncDecision.action(1,1,true,true,false)) }
    @Test fun `unknown sections are denied`() { assertFalse(SyncRoles.canWrite("owner","unknown")) }
    @Test fun `registry belongs only to full access gabbaim`() { assertTrue(SyncRoles.canWrite("gabbai","registry")); assertFalse(SyncRoles.canRead("treasurer","registry")); assertFalse(SyncRoles.canWrite("deputy","registry")) }
    @Test fun `logout preserves synchronization baseline`() {
        val c = org.robolectric.RuntimeEnvironment.getApplication()
        val p = c.getSharedPreferences("gabbai_sync",0)
        p.edit().clear().putString("shul","test-shul").putInt("v_test-shul_members",3).putString("sha_test-shul_members","baseline").putString("refresh","secret-test").commit()
        val sync = CloudSync(c); sync.signOut()
        assertFalse(sync.signedIn); assertEquals("test-shul",sync.shulId); assertEquals(3,sync.localVersion("members")); assertEquals("baseline",p.getString("sha_test-shul_members",null))
    }
}
