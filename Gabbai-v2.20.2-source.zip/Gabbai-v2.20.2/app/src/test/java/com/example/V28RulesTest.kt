package com.example

import com.example.data.model.*
import com.example.ui.calendar.*
import com.example.ui.components.DualDates
import com.example.ui.settings.AppSettings
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk = [35])
class V28RulesTest {
    private fun member(born: Long, status: MemberStatus = MemberStatus.ACTIVE) = MemberEntity(fullName = "Test", status = status, birthDateMillis = born)

    @Test fun `birthday reminder default is 7 days`() = assertEquals(7, AppSettings().birthdayReminderDays)

    @Test fun `birthday in 5 days shows with 7 day lead, not with 3`() {
        val now = DualDates.localNoon(2026, 10, 7)
        val m = member(DualDates.localNoon(1980, 10, 12))
        assertEquals(5, BirthdayTools.upcoming(m, now)!!.daysUntil)
        assertEquals(46, BirthdayTools.upcoming(m, now)!!.turningAge)
        assertEquals(1, BirthdayTools.within(listOf(m), 7, now).size)
        assertTrue(BirthdayTools.within(listOf(m), 3, now).isEmpty())
    }

    @Test fun `deceased members and unknown birthdays get no reminder`() {
        val now = DualDates.localNoon(2026, 10, 7)
        assertNull(BirthdayTools.upcoming(member(DualDates.localNoon(1980, 10, 8), MemberStatus.DECEASED), now))
        assertNull(BirthdayTools.upcoming(member(0L), now))
    }

    @Test fun `passed birthday rolls to next year`() {
        val now = DualDates.localNoon(2026, 10, 7)
        assertEquals(364, BirthdayTools.upcoming(member(DualDates.localNoon(1990, 10, 6)), now)!!.daysUntil)
    }

    @Test fun `hebrew and gregorian dates convert both ways`() {
        val g = DualDates.localNoon(2026, 10, 7)
        val h = DualDates.hebrewOf(g)
        assertEquals(g, DualDates.fromHebrew(h.year, h.month, h.day))
    }

    @Test fun `adar I only offered in leap years`() {
        assertTrue(5 in DualDates.monthsFor(5784))   // leap year
        assertFalse(5 in DualDates.monthsFor(5785))
    }
}
