package com.example

import android.graphics.Bitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import com.example.ui.viewmodel.GabbaiScreen
import com.example.ui.viewmodel.GabbaiViewModel
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowLooper
import java.io.File

/** Small phone: Save must stay inside the screen; new screens must open. */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w360dp-h640dp-xxhdpi")
class V26ScreensTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    @Suppress("UNCHECKED_CAST")
    private fun windowViews(): List<android.view.View> {
        val cls = Class.forName("android.view.WindowManagerGlobal")
        val inst = cls.getMethod("getInstance").invoke(null)
        val f = cls.getDeclaredField("mViews").apply { isAccessible = true }
        return (f.get(inst) as List<android.view.View>).toList()
    }

    private fun shot(name: String, dialog: Boolean = false) {
        val dir = File(System.getProperty("shots.dir") ?: "build/shots").apply { mkdirs() }
        rule.mainClock.advanceTimeBy(800); ShadowLooper.idleMainLooper()
        val views = windowViews()
        val v = if (dialog) views.drop(1).lastOrNull { it.width > 1 } ?: views.last() else views.first()
        val bmp = Bitmap.createBitmap(v.width.coerceAtLeast(1), v.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        rule.runOnUiThread { v.draw(android.graphics.Canvas(bmp)) }
        File(dir, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private fun open(screen: GabbaiScreen) {
        rule.mainClock.autoAdvance = false
        rule.runOnUiThread { ViewModelProvider(rule.activity)[GabbaiViewModel::class.java].setScreen(screen) }
        rule.mainClock.advanceTimeBy(800)
    }

    private fun assertInsideScreen(tag: String) {
        val node = rule.onNodeWithTag(tag, useUnmergedTree = true).fetchSemanticsNode()
        val screenH = rule.activity.resources.displayMetrics.heightPixels
        val bottom = node.positionInWindow.y + node.size.height
        assertTrue("$tag bottom $bottom > screen $screenH", node.size.height > 0 && bottom <= screenH)
    }

    @Test fun quickNederDialogFitsSmallScreen() {
        rule.mainClock.autoAdvance = false
        rule.runOnUiThread { ViewModelProvider(rule.activity)[GabbaiViewModel::class.java].setScreen(GabbaiScreen.CALENDAR) }
        rule.mainClock.advanceTimeBy(500)
        rule.onNodeWithTag("bottom_ai_sphere").assertExists()
        val open = androidx.compose.runtime.mutableStateOf(false)
        rule.runOnUiThread {
            val root = rule.activity.window.decorView as android.view.ViewGroup
            root.addView(androidx.compose.ui.platform.ComposeView(rule.activity).apply {
                setContent {
                    if (open.value) com.example.ui.components.QuickNederDialog(listOf("a", "b"), {}, {}, { _, _, _, _, _ -> })
                }
            })
        }
        rule.runOnUiThread { open.value = true }
        repeat(10) { rule.mainClock.advanceTimeBy(200); org.robolectric.shadows.ShadowLooper.idleMainLooper() }
        rule.onNodeWithTag("neder_dialog").assertExists()
        assertInsideScreen("neder_save")
        shot("neder_dialog", dialog = true)
    }

    @Test fun calendarScreen() {
        open(GabbaiScreen.CALENDAR)
        rule.onNodeWithTag("calendar_screen").assertExists()
        shot("calendar")
        rule.onNodeWithTag("calendar_screen").performScrollToIndex(3)
        shot("calendar_zmanim")
    }

    @Test fun complianceRulesDialog() {
        open(GabbaiScreen.MEMBERS)
        rule.onAllNodesWithText(com.example.ui.settings.L("სიის წესები")).onFirst().performClick()
        rule.mainClock.advanceTimeBy(800)
        rule.onNodeWithTag("rule_days").assertExists()
        rule.onNodeWithTag("rule_preview").assertExists()
        assertInsideScreen("form_dialog_buttons")
        shot("rules", dialog = true)
    }

    @Test fun memberFormButtonsInsideScreen() {
        open(GabbaiScreen.MEMBERS)
        rule.onNodeWithTag("fab_add_member").performClick()
        rule.mainClock.advanceTimeBy(800)
        assertInsideScreen("form_dialog_buttons")
        shot("member_form", dialog = true)
    }
}
