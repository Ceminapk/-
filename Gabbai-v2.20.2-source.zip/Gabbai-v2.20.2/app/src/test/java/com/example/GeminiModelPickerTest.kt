package com.example

import com.example.data.service.GeminiModelPicker
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class GeminiModelPickerTest {
    private val live = listOf(
        "models/gemini-2.5-flash", "models/gemini-2.5-flash-preview-tts", "models/gemini-3.5-flash",
        "models/gemini-3.5-flash-lite", "models/gemini-3.1-flash-tts-preview", "models/gemini-3.8-flash-tts",
        "models/gemini-3.1-flash-image", "models/gemini-flash-latest", "models/gemma-4-31b-it", "models/gemini-3.5-transcribe"
    )

    @Test fun newestTextModelFirst() = assertEquals("gemini-3.5-flash", GeminiModelPicker.textModels(live).first())
    @Test fun futureVersionWinsAutomatically() =
        assertEquals("gemini-4.2-flash", GeminiModelPicker.textModels(live + "models/gemini-4.2-flash").first())
    @Test fun textListExcludesVoiceAndImage() =
        assertFalse(GeminiModelPicker.textModels(live).any { it.contains("tts") || it.contains("image") || it.contains("transcribe") })
    @Test fun newestVoiceModelFirst() = assertEquals("gemini-3.8-flash-tts", GeminiModelPicker.ttsModels(live).first())
    @Test fun wavHeaderStripped() {
        val pcm = byteArrayOf(1, 2, 3, 4)
        val wav = "RIFF".toByteArray() + ByteArray(4) + "WAVEfmt ".toByteArray() + byteArrayOf(16, 0, 0, 0, 1, 0, 1, 0, 0xC0.toByte(), 0x5D, 0, 0) + ByteArray(8) +
            "data".toByteArray() + byteArrayOf(4, 0, 0, 0) + pcm
        val (out, rate) = GeminiModelPicker.pcm(wav)
        assertEquals(24000, rate); assertEquals(pcm.toList(), out.toList())
    }
}
