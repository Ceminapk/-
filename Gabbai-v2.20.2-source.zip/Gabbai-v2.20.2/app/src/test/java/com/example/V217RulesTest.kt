package com.example

import com.example.data.backup.AutoBackupRules
import com.example.data.model.*
import com.example.ui.screens.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk = [35])
class V217RulesTest {
    private val day = 86_400_000L
    private val shabbat = Calendar.getInstance().apply { set(2026, Calendar.OCTOBER, 17, 9, 0, 0) }.timeInMillis

    @Test fun `advance plan excludes neder and verse sales`() {
        assertFalse(AliyahType.NEDER in AdvanceAliyot.types)
        assertFalse(AliyahType.PESUKIM in AdvanceAliyot.types)
        assertTrue(AliyahType.KOHEN in AdvanceAliyot.types && AliyahType.MAFTIR in AdvanceAliyot.types)
    }

    @Test fun `member honoured within 14 days is flagged as too soon`() {
        val a = listOf(AliyahEntity(parashaName = "x", aliyahType = AliyahType.LEVI, winnerName = "დავითი", amount = 0.0, dateMillis = shabbat - 7 * day))
        assertTrue(AdvanceAliyot.tooSoon("დავითი", a, shabbat))
        assertFalse(AdvanceAliyot.tooSoon("დავითი", a, shabbat + 14 * day))
        assertFalse(AdvanceAliyot.tooSoon("იაკობი", a, shabbat))
    }

    @Test fun `member without aliyah for 8 weeks is suggested`() {
        val m = MemberEntity(id = 1, fullName = "იაკობი")
        assertTrue(AdvanceAliyot.reasons(m, emptyList(), emptyList(), shabbat).isNotEmpty())
    }

    @Test fun `bar mitzvah is 13 hebrew years later`() {
        val birth = Calendar.getInstance().apply { set(2013, Calendar.MARCH, 10, 12, 0, 0) }.timeInMillis
        val c = Calendar.getInstance().apply { timeInMillis = BarMitzvah.date(birth) }
        assertEquals(2026, c.get(Calendar.YEAR))
    }

    @Test fun `auto backup keeps newest 7`() {
        val names = (1..10).map { "gabbai-2026-10-%02d.json".format(it) }
        val del = AutoBackupRules.toDelete(names, 7)
        assertEquals(listOf("gabbai-2026-10-03.json", "gabbai-2026-10-02.json", "gabbai-2026-10-01.json"), del)
    }

    @Test fun `certificate code changes when amount changes`() {
        val a = CertificateCode.of("დავითი", 2026, 100.0, "შული")
        assertEquals(a, CertificateCode.of("დავითი ", 2026, 100.0, "შული"))
        assertNotEquals(a, CertificateCode.of("დავითი", 2026, 101.0, "შული"))
        assertEquals(10, a.length)
    }

    @Test fun `finance chart sums paid records per month`() {
        val now = Calendar.getInstance().apply { set(2026, Calendar.OCTOBER, 13) }.timeInMillis
        val t = listOf(TransactionEntity(title = "a", type = TransactionType.INCOME, category = FinanceCategory.OTHER_INCOME, amount = 100.0, currency = "GEL", dateMillis = now),
            TransactionEntity(title = "b", type = TransactionType.EXPENSE, category = FinanceCategory.REPAIRS_RENOVATION, amount = 40.0, currency = "GEL", dateMillis = now),
            TransactionEntity(title = "c", type = TransactionType.INCOME, category = FinanceCategory.OTHER_INCOME, amount = 999.0, currency = "USD", dateMillis = now))
        val last = FinanceChart.monthly(t, "GEL", 6, now).last()
        assertEquals(100.0, last.second, 0.0); assertEquals(40.0, last.third, 0.0)
    }

    @Test fun `dedication for the departed adds zl`() {
        assertTrue(Dedication.text("לעילוי נשמת", "משה", "יעקב", true, "").startsWith("לעילוי נשמת משה בן יעקב ז״ל"))
    }
}
