package com.example.voice

import com.example.ui.voice.splitForSpeech
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechSplitTest {
    @Test fun firstPieceIsShortForFastStart() {
        val text = "პირველი წინადადება. " + "მეორე წინადადება გრძელია. ".repeat(40)
        val parts = splitForSpeech(text)
        assertTrue(parts[0].length <= 160)
        assertTrue(parts.all { it.length <= 500 })
    }
    @Test fun nothingIsLost() {
        val text = "ა. ბ! გ? დ."
        assertEquals("ა. ბ! გ? დ.", splitForSpeech(text).joinToString(" "))
    }
}
