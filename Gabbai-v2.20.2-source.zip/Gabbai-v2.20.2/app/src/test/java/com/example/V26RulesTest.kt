package com.example

import com.example.data.model.MemberCompliance
import com.example.data.model.MemberEntity
import com.example.ui.calendar.Cities
import com.example.ui.calendar.JewishCalendar
import com.example.ui.settings.ComplianceRules
import com.example.ui.settings.ListStatus
import com.example.ui.voice.VoiceCommandParser
import com.example.ui.viewmodel.GabbaiScreen
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.text.SimpleDateFormat
import java.util.*

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class V26RulesTest {
    private val day = 86_400_000L
    private val now = 1_790_000_000_000L
    private fun m(debt: Double = 0.0, paid: Boolean = true, lastPayDaysAgo: Int? = 1, cat: MemberCompliance = MemberCompliance.NORMAL) =
        MemberEntity(fullName = "x", outstandingDebt = debt, duesPaid = paid, complianceCategory = cat,
            lastPaymentDateMillis = lastPayDaysAgo?.let { now - it * day } ?: 0L)

    // --- Red / black list ---
    @Test fun `debt at the amount limit is red even if dues are paid`() =
        assertEquals(ListStatus.RED, ComplianceRules.statusFor(m(debt = 300.0, paid = true), 60, 300.0, now))

    @Test fun `small debt paid recently is not red`() =
        assertEquals(ListStatus.NORMAL, ComplianceRules.statusFor(m(debt = 50.0, lastPayDaysAgo = 10), 60, 300.0, now))

    @Test fun `small debt with no payment for the day limit is red`() =
        assertEquals(ListStatus.RED, ComplianceRules.statusFor(m(debt = 50.0, lastPayDaysAgo = 61), 60, 300.0, now))

    @Test fun `no debt and dues paid is never red however old the payment`() =
        assertEquals(ListStatus.NORMAL, ComplianceRules.statusFor(m(lastPayDaysAgo = 500), 60, 300.0, now))

    @Test fun `black list wins over a big debt`() =
        assertEquals(ListStatus.BLACK, ComplianceRules.statusFor(m(debt = 5000.0, cat = MemberCompliance.BLACK_LIST), 60, 300.0, now))

    @Test fun `manual red list stays red without debt`() =
        assertEquals(ListStatus.RED, ComplianceRules.statusFor(m(cat = MemberCompliance.RED_LIST), 60, 300.0, now))

    // --- Voice ---
    @Test fun `saying neder opens the quick pledge`() = assertTrue(VoiceCommandParser.parse("ნედერი").openNeder)
    @Test fun `saying shabbat opens the calendar`() = assertEquals(GabbaiScreen.CALENDAR, VoiceCommandParser.parse("შაბათის დრო").screen)

    // --- Calendar ---
    @Test fun `4 October 2026 is 23 Tishrei 5787`() {
        val h = JewishCalendar.toHebrew(2026, 10, 4)
        assertEquals(5787, h.year); assertEquals(0, h.month); assertEquals(23, h.day)
    }

    @Test fun `Simchat Torah on 23 Tishrei is a holiday outside Israel only`() {
        assertTrue(JewishCalendar.day(2026, 10, 4, Cities.find("თბილისი")).isYomTov)
        assertFalse(JewishCalendar.day(2026, 10, 4, Cities.find("იერუსალიმი")).isYomTov)
    }

    @Test fun `Friday has candle lighting and Saturday has havdalah, Thursday has neither`() {
        val tb = Cities.find("თბილისი")
        val fri = JewishCalendar.day(2026, 10, 9, tb)
        assertNotNull(fri.candleLighting); assertNull(fri.havdalah)
        assertNotNull(JewishCalendar.day(2026, 10, 10, tb).havdalah)
        val thu = JewishCalendar.day(2026, 10, 8, tb)
        assertNull(thu.candleLighting); assertNull(thu.havdalah)
    }

    @Test fun `Tbilisi candle lighting is 18 minutes before sunset, in the evening`() {
        val fri = JewishCalendar.day(2026, 10, 9, Cities.find("თბილისი"))
        assertEquals(18 * 60_000L, fri.sunset!! - fri.candleLighting!!)
        val f = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("Asia/Tbilisi") }
        val t = f.format(Date(fri.candleLighting!!))
        assertTrue("candle at $t", t in "17:50".."18:45")
    }

    @Test fun `Jerusalem candle lighting is 40 minutes before sunset`() {
        val fri = JewishCalendar.day(2026, 10, 9, Cities.find("იერუსალიმი"))
        assertEquals(40 * 60_000L, fri.sunset!! - fri.candleLighting!!)
    }

    @Test fun `eve of Yom Kippur 2026 has candle lighting`() {
        // Yom Kippur 5787 = Monday 21 Sep 2026
        val eve = JewishCalendar.day(2026, 9, 20, Cities.find("თბილისი"))
        assertNotNull(eve.candleLighting)
        assertNotNull(JewishCalendar.day(2026, 9, 21, Cities.find("თბილისი")).havdalah)
    }

    @Test fun `hebrew numerals`() {
        assertEquals("ט״ו", JewishCalendar.gematria(15))
        assertEquals("תשפ״ז", JewishCalendar.gematria(5787))
    }
}
