package com.example

import android.graphics.Bitmap
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import com.example.ui.viewmodel.GabbaiScreen
import com.example.ui.viewmodel.GabbaiViewModel
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowLooper
import java.io.File

/** v2.13 screens open and their forms fit a small phone. */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [35], qualifiers = "w360dp-h640dp-xxhdpi")
class V213ScreensTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    @Suppress("UNCHECKED_CAST")
    private fun windowViews(): List<android.view.View> {
        val cls = Class.forName("android.view.WindowManagerGlobal")
        val inst = cls.getMethod("getInstance").invoke(null)
        val f = cls.getDeclaredField("mViews").apply { isAccessible = true }
        return (f.get(inst) as List<android.view.View>).toList()
    }

    private fun shot(name: String, dialog: Boolean = false) {
        val dir = File(System.getProperty("shots.dir") ?: "build/shots").apply { mkdirs() }
        rule.mainClock.advanceTimeBy(800); ShadowLooper.idleMainLooper()
        val views = windowViews()
        val v = if (dialog) views.drop(1).lastOrNull { it.width > 1 } ?: views.last() else views.first()
        val bmp = Bitmap.createBitmap(v.width.coerceAtLeast(1), v.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        rule.runOnUiThread { v.draw(android.graphics.Canvas(bmp)) }
        File(dir, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private fun open(screen: GabbaiScreen) {
        rule.mainClock.autoAdvance = false
        rule.runOnUiThread { ViewModelProvider(rule.activity)[GabbaiViewModel::class.java].setScreen(screen) }
        rule.mainClock.advanceTimeBy(800)
    }

    private fun assertInsideScreen(tag: String) {
        val node = rule.onNodeWithTag(tag, useUnmergedTree = true).fetchSemanticsNode()
        val screenH = rule.activity.resources.displayMetrics.heightPixels
        val bottom = node.positionInWindow.y + node.size.height
        assertTrue("$tag bottom $bottom > screen $screenH", node.size.height > 0 && bottom <= screenH)
    }

    @Test fun registersScreenOpensAndAddFormFits() {
        open(GabbaiScreen.REGISTERS)
        rule.onNodeWithTag("registers_screen").assertExists()
        shot("v213_registers")
        rule.onNodeWithTag("fab_add_registry").performClick()
        repeat(5) { rule.mainClock.advanceTimeBy(200); ShadowLooper.idleMainLooper() }
        rule.onNodeWithTag("registry_title").assertExists()
        assertInsideScreen("btn_save_registry")
        shot("v213_registry_form", dialog = true)
    }

    @Test fun toolsScreenOpens() {
        open(GabbaiScreen.TOOLS)
        rule.onNodeWithTag("tools_screen").assertExists()
        shot("v213_tools")
        rule.onNodeWithTag("tools_screen").performScrollToIndex(3)
        shot("v213_tools_birth")
    }

    @Test fun membersScreenOpens() {
        open(GabbaiScreen.MEMBERS)
        rule.onAllNodesWithText(com.example.ui.viewmodel.GabbaiScreen.MEMBERS.title).onFirst().assertExists()
        shot("v213_members")
    }
}
