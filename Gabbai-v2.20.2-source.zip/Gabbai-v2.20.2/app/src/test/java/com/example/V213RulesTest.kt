package com.example

import com.example.data.model.*
import com.example.ui.calendar.*
import com.example.ui.components.DualDates
import com.example.ui.components.MemberQr
import com.example.ui.components.Relative
import com.example.ui.components.Relatives
import com.example.ui.share.Share
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.util.Calendar
import java.util.TimeZone

@RunWith(RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk = [35])
class V213RulesTest {
    private fun loan(amount: Double, paid: Double = 0.0, count: Int = 1, kind: RegistryKind = RegistryKind.GEMACH) =
        RegistryEntity(kind = kind.name, title = "x", amount = amount, paidAmount = paid, count = count)

    @Test fun `gemach payment reduces balance and closes when fully repaid`() {
        val l = RegistryRules.pay(loan(1000.0), 400.0)
        assertEquals(600.0, RegistryRules.remaining(l), 0.001)
        assertEquals(RegistryStatus.OPEN, l.status)
        val done = RegistryRules.pay(l, 600.0)
        assertEquals(0.0, RegistryRules.remaining(done), 0.001)
        assertEquals(RegistryStatus.DONE, done.status)
    }

    @Test fun `overpayment never makes the balance negative`() =
        assertEquals(0.0, RegistryRules.remaining(RegistryRules.pay(loan(100.0), 500.0)), 0.001)

    @Test fun `neder of 1200 over 12 months is 100 a month`() =
        assertEquals(100.0, RegistryRules.installment(loan(1200.0, count = 12, kind = RegistryKind.INSTALLMENT)), 0.001)

    @Test fun `mikveh total is price times visits`() =
        assertEquals(150.0, RegistryRules.total(loan(30.0, count = 5, kind = RegistryKind.MIKVEH)), 0.001)

    @Test fun `utilities are summed only for the current month`() {
        val now = DualDates.localNoon(2026, 10, 12)
        val rows = listOf(
            RegistryEntity(kind = RegistryKind.UTILITY.name, title = "a", amount = 300.0, dateMillis = DualDates.localNoon(2026, 10, 1)),
            RegistryEntity(kind = RegistryKind.UTILITY.name, title = "b", amount = 200.0, dateMillis = DualDates.localNoon(2026, 10, 20)),
            RegistryEntity(kind = RegistryKind.UTILITY.name, title = "c", amount = 999.0, dateMillis = DualDates.localNoon(2026, 9, 30)),
            RegistryEntity(kind = RegistryKind.MIKVEH.name, title = "d", amount = 50.0, dateMillis = now)
        )
        assertEquals(500.0, RegistryRules.monthSpent(rows, now), 0.001)
    }

    @Test fun `mikveh, auction and utilities post to finances, gemach does not`() {
        assertEquals(FinanceCategory.OTHER_INCOME, RegistryKind.MIKVEH.finance)
        assertEquals(TransactionType.EXPENSE, RegistryKind.UTILITY.financeType)
        assertEquals(FinanceCategory.ALIYOT_TORAH, RegistryKind.AUCTION.finance)
        assertNull(RegistryKind.GEMACH.finance)
    }

    @Test fun `tehillim split covers all 150 psalms without gaps`() {
        val r = JewishTools.splitTehillim(7)
        assertEquals(7, r.size)
        assertEquals(1, r.first().first); assertEquals(150, r.last().last)
        assertEquals(150, r.sumOf { it.count() })
        r.zipWithNext().forEach { (a, b) -> assertEquals(a.last + 1, b.first) }
    }

    @Test fun `georgian numbers become international for whatsapp`() {
        assertEquals("995599123456", Share.waNumber("599 12 34 56"))
        assertEquals("995599123456", Share.waNumber("0599123456"))
        assertEquals("972501234567", Share.waNumber("+972 50 123 4567"))
    }

    @Test fun `brit is on the 8th day, a day later when born after sunset`() {
        val born = DualDates.localNoon(2026, 10, 1)
        val brit = Calendar.getInstance().apply { timeInMillis = JewishTools.britMilah(born, false) }
        assertEquals(8, brit.get(Calendar.DAY_OF_MONTH))
        val late = Calendar.getInstance().apply { timeInMillis = JewishTools.britMilah(born, true) }
        assertEquals(9, late.get(Calendar.DAY_OF_MONTH))
    }

    @Test fun `bar mitzvah is on the same hebrew date 13 years later`() {
        val born = DualDates.localNoon(2013, 10, 1)
        val hb = JewishTools.hebrewBirth(born, false)
        val bm = JewishTools.barMitzvah(born, false)
        assertEquals(hb.year + 13, bm.heb.year)
        assertEquals(hb.day, bm.heb.day)
        assertEquals(Calendar.SATURDAY, Calendar.getInstance().apply { timeInMillis = bm.shabbatMillis }.get(Calendar.DAY_OF_WEEK))
        val bat = JewishTools.barMitzvah(born, false, girl = true)
        assertEquals(hb.year + 12, bat.heb.year)
    }

    @Test fun `molad tishrei 5784 is friday 15 sep 2023 at 5_48 jerusalem time`() {
        val c = Calendar.getInstance(TimeZone.getTimeZone("GMT+2")).apply { timeInMillis = JewishTools.molad(5784, 0) }
        assertEquals(2023, c.get(Calendar.YEAR)); assertEquals(Calendar.SEPTEMBER, c.get(Calendar.MONTH)); assertEquals(15, c.get(Calendar.DAY_OF_MONTH))
        assertEquals(5, c.get(Calendar.HOUR_OF_DAY)); assertEquals(48, c.get(Calendar.MINUTE))
    }

    @Test fun `kiddush levana runs from day 7 to day 15 after the molad`() {
        val w = JewishTools.kiddushLevana(5787, 0)
        val m = JewishTools.molad(5787, 0)
        assertEquals(7, ((w.start - m) / 86_400_000L).toInt())
        assertEquals(15, ((w.end - m) / 86_400_000L).toInt())
    }

    @Test fun `omer day 8 is one week and one day`() =
        assertEquals("היום 8 ימים שהם שבוע אחד ויום אחד לעומר", JewishTools.omerText(8))

    @Test fun `family links survive save and load`() {
        val list = listOf(Relative("ვაჟი", "დავითი", 123L, true), Relative("ქალიშვილი", "სარა", 0L, false))
        assertEquals(list, Relatives.parse(Relatives.encode(list)))
    }

    @Test fun `member qr code resolves back to the member id`() {
        val m = MemberEntity(id = 42, fullName = "Test")
        assertEquals(42L, MemberQr.parse(MemberQr.payload(m)))
        assertNull(MemberQr.parse("https://example.com"))
    }
}
