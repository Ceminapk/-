package com.example

import com.example.data.model.*
import com.example.ui.calendar.HebDate
import com.example.ui.screens.HalachaRules
import com.example.ui.screens.SeatMap
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar

class V219RulesTest {
    private fun hall(id: Long, day: Long, slot: String) = RegistryEntity(id = id, kind = RegistryKind.HALL_BOOKING.name, title = "x", dueMillis = day, extra = slot)

    @Test fun `same day and slot is a double booking`() {
        val d = 1_800_000_000_000L
        assertEquals(setOf(1L, 2L), V219Rules.hallConflicts(listOf(hall(1, d, "საღამო"), hall(2, d + 3600_000, "საღამო"), hall(3, d, "დილა"))))
    }

    @Test fun `gps coordinates parse and reject bad input`() {
        assertEquals(41.69 to 44.8, V219Rules.parseGps("41.69, 44.8"))
        assertNull(V219Rules.parseGps("200, 10"))
        assertNull(V219Rules.parseGps("თბილისი"))
    }

    @Test fun `no tachanun on shabbat, rosh chodesh and all of nisan`() {
        assertTrue(HalachaRules.noTachanun(HebDate(5787, 4, 10, false), Calendar.SATURDAY))
        assertTrue(HalachaRules.noTachanun(HebDate(5787, 4, 1, false), Calendar.MONDAY))
        assertTrue(HalachaRules.noTachanun(HebDate(5787, 7, 20, false), Calendar.MONDAY))
        assertFalse(HalachaRules.noTachanun(HebDate(5787, 4, 10, false), Calendar.MONDAY))
    }

    @Test fun `mashiv haruach from shemini atzeret until pesach`() {
        assertTrue(HalachaRules.mashivHaruach(HebDate(5787, 0, 22, false)))
        assertFalse(HalachaRules.mashivHaruach(HebDate(5787, 0, 21, false)))
        assertFalse(HalachaRules.mashivHaruach(HebDate(5787, 7, 15, false)))
    }

    @Test fun `seat label row-seat parses`() = assertEquals(3 to 12, SeatMap.parse("3-12"))

    @Test fun `new journals exist`() {
        listOf("HALL_BOOKING", "CEMETERY", "HONOR_WALL", "FOOD_BASKETS", "MIKVEH_APPT", "SHABBAT_PREP", "SYNAGOGUE_DIR").forEach { RegistryKind.valueOf(it) }
    }
}
