package com.example.ui.share

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.data.model.*
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.settings.money
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Ready-made texts the gabbai sends with one tap. */
object Messages {
    private fun d(millis: Long) = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(millis))
    private fun t(millis: Long?) = if (millis == null) "—" else SimpleDateFormat("HH:mm", Locale.US).format(Date(millis))

    fun yahrzeit(y: YahrzeitEntity, dateMillis: Long, daysUntil: Int, shul: String) = Lf(
        "შალომ, {0}! გახსენებთ, რომ {1} ז״ל-ის იორცაიტი არის {2} ({3} დღეში). სინაგოგაში გელოდებით კადიშისა და ჰაზქარისთვის. {4}",
        y.relatedMemberName, y.deceasedName, d(dateMillis), daysUntil, shul
    ) + if (y.cemetery.isNotBlank()) "\n" + Lf("სასაფლაო: {0} {1}", y.cemetery, y.plot) else ""

    fun birthday(name: String, shul: String) = Lf("მაზალ ტოვ, {0}! გილოცავთ დაბადების დღეს — ად მეა ვეესრიმ! ბრახა, ჯანმრთელობა და ნახათ. {1}", name, shul)

    fun nederReminder(name: String, amount: Double, currency: String, shul: String) =
        Lf("შალომ, {0}! მეგობრული შეხსენება: თქვენი ნედერი/საწევრო {1} ჯერ არ არის დაფარული. თოდა რაბა! {2}", name, money(amount, currency), shul)

    fun minyanSos(prayer: String, timeText: String, missing: Int, shul: String) =
        Lf("🆘 მინიანი! {0} — {1}. გვაკლია {2} კაცი. გთხოვთ, მობრძანდით სინაგოგაში. {3}", prayer, timeText, missing, shul)

    fun thankYou(name: String, amount: Double, currency: String, purpose: String, dateMillis: Long, shul: String) =
        Lf("თოდა რაბა, {0}! {1} მიიღო თქვენი შემოწირულობა: {2} — {3} ({4}). ჰაშემ დაგლოცოთ — იევარეხეხა ჰაშემ!", name, shul, money(amount, currency), purpose, d(dateMillis))

    fun tehillim(forWhom: String, reason: String, reader: String, range: IntRange) =
        Lf("შალომ, {0}! {1}-ისთვის ({2}) ვკითხულობთ თეჰილიმს. თქვენი წილი: ფსალმუნები {3}–{4}. თოდა რაბა!", reader, forWhom, reason, range.first, range.last)

    fun miShebeirach(name: String, hebrewName: String, sick: String, amount: Double, currency: String) = buildString {
        append("מִי שֶׁבֵּרַךְ אֲבוֹתֵינוּ אַבְרָהָם יִצְחָק וְיַעֲקֹב, הוּא יְבָרֵךְ אֶת ")
        append(hebrewName.ifBlank { name })
        append(" בַּעֲבוּר שֶׁעָלָה לִכְבוֹד הַמָּקוֹם וְלִכְבוֹד הַתּוֹרָה")
        if (amount > 0) append(" וְנָדַר ${money(amount, currency)} לִצְדָקָה")
        append(". בִּשְׂכַר זֶה הַקָּדוֹשׁ בָּרוּךְ הוּא יִשְׁמְרֵהוּ וְיַצִּילֵהוּ מִכָּל צָרָה וְצוּקָה")
        if (sick.isNotBlank()) append(", וְיִשְׁלַח רְפוּאָה שְׁלֵמָה לְ$sick")
        append(", וְיִשְׁלַח בְּרָכָה וְהַצְלָחָה בְּכָל מַעֲשֵׂה יָדָיו, וְנֹאמַר אָמֵן.")
        append("\n\n"); append(Lf("ქართულად: ვინც აკურთხა ჩვენი მამები... აკურთხოს {0}, რომელიც ავიდა თორაზე", name))
        if (amount > 0) append(Lf(" და აღთქვა {0} ცედაკისთვის", money(amount, currency)))
        if (sick.isNotBlank()) append(Lf("; სრული განკურნება {0}-ს", sick))
        append(". ამენ.")
    }

    /** Annual donation summary for one member (paid income records in that calendar year). */
    fun annualCertificate(member: String, year: Int, txs: List<TransactionEntity>, shul: String): String {
        val mine = txs.filter { it.type == TransactionType.INCOME && it.status == TransactionStatus.PAID && it.memberName.equals(member, true) &&
            Calendar.getInstance().apply { timeInMillis = it.dateMillis }.get(Calendar.YEAR) == year }
        val sb = StringBuilder()
        sb.append(Lf("{0}\nშემოწირულობების წლიური ცნობა — {1}\n\n", shul, year))
        sb.append(Lf("წევრი: {0}\n\n", member))
        mine.groupBy { it.currency }.forEach { (cur, list) ->
            list.groupBy { it.category }.forEach { (cat, l) -> sb.append("• ${cat.titleKa}: ${money(l.sumOf { it.amount }, cur)}\n") }
            sb.append(Lf("სულ: {0}\n", money(list.sumOf { it.amount }, cur)))
        }
        if (mine.isEmpty()) sb.append(L("ამ წელს გადახდილი შემოწირულობა არ არის აღრიცხული.") + "\n")
        sb.append("\n" + L("გმადლობთ თქვენი ერთგულებისთვის. ხაზაკ უვარუხ!"))
        return sb.toString()
    }

    data class DigestInput(val parasha: String, val candle: Long?, val havdalah: Long?, val shacharit: String, val mincha: Long?, val maariv: Long?,
                           val yahrzeits: List<String>, val birthdays: List<String>, val events: List<String>)

    fun weeklyDigest(i: DigestInput, shul: String) = buildString {
        append("✡ $shul — " + L("შაბათის დაიჯესტი") + "\n")
        if (i.parasha.isNotBlank()) append(Lf("ფარაშა: {0}\n", i.parasha))
        append(Lf("🕯 სანთლის ანთება: {0}\n", t(i.candle)))
        append(Lf("შახარითი: {0} • მინხა: {1} • ყარბითი: {2}\n", i.shacharit, t(i.mincha), t(i.maariv)))
        append(Lf("✨ შაბათის გასვლა: {0}\n", t(i.havdalah)))
        if (i.yahrzeits.isNotEmpty()) append("\n" + L("იორცაიტები:") + "\n" + i.yahrzeits.joinToString("\n") { "• $it" } + "\n")
        if (i.birthdays.isNotEmpty()) append("\n" + L("მაზალ ტოვ — დაბადების დღეები:") + "\n" + i.birthdays.joinToString("\n") { "• $it" } + "\n")
        if (i.events.isNotEmpty()) append("\n" + L("ღონისძიებები:") + "\n" + i.events.joinToString("\n") { "• $it" } + "\n")
        append("\n" + L("შაბათ შალომ!"))
    }

    /** Renders a gold-on-night thank-you card (1080×1350) for sharing in messengers. */
    fun thankYouCard(name: String, amount: Double, currency: String, purpose: String, dateMillis: Long, shul: String): Bitmap {
        val w = 1080; val h = 1350
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint().apply { shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF0B1026.toInt(), 0xFF1B2450.toInt(), Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)
        val gold = 0xFFE9C46A.toInt()
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f; color = gold }
        c.drawRoundRect(RectF(40f, 40f, w - 40f, h - 40f), 40f, 40f, frame)
        c.drawRoundRect(RectF(64f, 64f, w - 64f, h - 64f), 30f, 30f, Paint(frame).apply { strokeWidth = 2f; alpha = 140 })
        fun block(text: String, size: Float, color: Int, top: Float, bold: Boolean = false): Float {
            val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }
            val l = StaticLayout.Builder.obtain(text, 0, text.length, p, w - 200).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
            c.save(); c.translate(100f, top); l.draw(c); c.restore()
            return top + l.height
        }
        var y = 130f
        y = block("✡", 110f, gold, y) + 20f
        y = block("תודה רבה", 92f, gold, y, true) + 10f
        y = block(L("დიდი მადლობა"), 54f, 0xFFFFFFFF.toInt(), y, true) + 50f
        y = block(name, 70f, 0xFFFFFFFF.toInt(), y, true) + 40f
        y = block(money(amount, currency), 96f, gold, y, true) + 24f
        y = block(purpose, 44f, 0xFFC9D1F5.toInt(), y) + 50f
        y = block(L("იევარეხეხა ჰაშემ ვეიშმერეხა") + "\nיְבָרֶכְךָ ה׳ וְיִשְׁמְרֶךָ", 40f, 0xFFC9D1F5.toInt(), y) + 60f
        block(shul + "\n" + d(dateMillis), 38f, gold, h - 230f)
        return bmp
    }
}
