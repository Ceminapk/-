package com.example.ui.calendar

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Calendar
import java.util.GregorianCalendar
import java.util.TimeZone
import kotlin.math.*

/** A city for prayer times. candleMinutes = minutes before sunset for candle lighting. */
data class ZmanimCity(
    val nameKa: String,
    val lat: Double,
    val lon: Double,
    val tz: String,
    val israel: Boolean = false,
    val candleMinutes: Int = 18
)

object Cities {
    val all = listOf(
        ZmanimCity("თბილისი", 41.7151, 44.8271, "Asia/Tbilisi"),
        ZmanimCity("ქუთაისი", 42.2679, 42.6946, "Asia/Tbilisi"),
        ZmanimCity("ბათუმი", 41.6168, 41.6367, "Asia/Tbilisi"),
        ZmanimCity("ახალციხე", 41.6390, 42.9826, "Asia/Tbilisi"),
        ZmanimCity("ონი", 42.5794, 43.4425, "Asia/Tbilisi"),
        ZmanimCity("სენაკი", 42.2700, 42.0675, "Asia/Tbilisi"),
        ZmanimCity("იერუსალიმი", 31.7683, 35.2137, "Asia/Jerusalem", israel = true, candleMinutes = 40),
        ZmanimCity("თელ-ავივი", 32.0853, 34.7818, "Asia/Jerusalem", israel = true, candleMinutes = 18),
        ZmanimCity("ბნეი-ბრაკი", 32.0807, 34.8338, "Asia/Jerusalem", israel = true, candleMinutes = 18),
        ZmanimCity("აშდოდი", 31.8014, 34.6435, "Asia/Jerusalem", israel = true, candleMinutes = 18),
        ZmanimCity("მოსკოვი", 55.7558, 37.6173, "Europe/Moscow"),
        ZmanimCity("ბაქო", 40.4093, 49.8671, "Asia/Baku"),
        ZmanimCity("ერევანი", 40.1872, 44.5152, "Asia/Yerevan"),
        ZmanimCity("ლონდონი", 51.5074, -0.1278, "Europe/London"),
        ZmanimCity("ნიუ-იორკი", 40.7128, -74.0060, "America/New_York")
    )
    fun find(name: String) = all.firstOrNull { it.nameKa == name } ?: all.first()
}

object CalendarPrefs {
    var cityName by mutableStateOf(Cities.all.first().nameKa)
    var gpsCity by mutableStateOf<ZmanimCity?>(null)
    private var prefs: android.content.SharedPreferences? = null
    fun init(context: Context) {
        prefs = context.getSharedPreferences("gabbai_settings", Context.MODE_PRIVATE)
        cityName = prefs?.getString("zmanim_city", Cities.all.first().nameKa) ?: Cities.all.first().nameKa
        if (cityName == "GPS — მიმდინარე მდებარეობა") {
            val lat = java.lang.Double.longBitsToDouble(prefs?.getLong("zmanim_gps_lat", 0L) ?: 0L)
            val lon = java.lang.Double.longBitsToDouble(prefs?.getLong("zmanim_gps_lon", 0L) ?: 0L)
            if (lat != 0.0 || lon != 0.0) gpsCity = ZmanimCity(cityName, lat, lon, TimeZone.getDefault().id)
        }
    }
    fun set(name: String) { cityName = name; prefs?.edit()?.putString("zmanim_city", name)?.apply() }
    fun setGps(lat: Double, lon: Double) {
        cityName = "GPS — მიმდინარე მდებარეობა"
        gpsCity = ZmanimCity(cityName, lat, lon, TimeZone.getDefault().id)
        prefs?.edit()?.putString("zmanim_city", cityName)
            ?.putLong("zmanim_gps_lat", java.lang.Double.doubleToRawLongBits(lat))
            ?.putLong("zmanim_gps_lon", java.lang.Double.doubleToRawLongBits(lon))?.apply()
    }
    val city: ZmanimCity get() = gpsCity?.takeIf { cityName == it.nameKa } ?: Cities.find(cityName)
}

/** Sun-based times (NOAA "Almanac for Computers" algorithm). Returns epoch millis or null (polar). */
object Sun {
    const val SUNRISE_ZENITH = 90.833
    /** Dawn (עלות השחר), sun 16.1° below horizon. */
    const val ALOT_ZENITH = 106.1
    /** Nightfall (צאת הכוכבים), sun 8.5° below horizon. */
    const val TZEIT_ZENITH = 98.5

    fun time(y: Int, m: Int, d: Int, lat: Double, lon: Double, tz: TimeZone, zenith: Double, rising: Boolean): Long? {
        val cal = GregorianCalendar(tz).apply { clear(); set(y, m - 1, d, 12, 0, 0) }
        val n = cal.get(Calendar.DAY_OF_YEAR)
        val lngHour = lon / 15.0
        val t = n + ((if (rising) 6.0 else 18.0) - lngHour) / 24.0
        val mAnom = 0.9856 * t - 3.289
        var l = mAnom + 1.916 * sin(Math.toRadians(mAnom)) + 0.020 * sin(Math.toRadians(2 * mAnom)) + 282.634
        l = norm(l, 360.0)
        var ra = Math.toDegrees(atan(0.91764 * tan(Math.toRadians(l))))
        ra = norm(ra, 360.0)
        ra += floor(l / 90.0) * 90.0 - floor(ra / 90.0) * 90.0
        ra /= 15.0
        val sinDec = 0.39782 * sin(Math.toRadians(l))
        val cosDec = cos(asin(sinDec))
        val cosH = (cos(Math.toRadians(zenith)) - sinDec * sin(Math.toRadians(lat))) / (cosDec * cos(Math.toRadians(lat)))
        if (cosH > 1 || cosH < -1) return null
        var h = if (rising) 360.0 - Math.toDegrees(acos(cosH)) else Math.toDegrees(acos(cosH))
        h /= 15.0
        val localT = h + ra - 0.06571 * t - 6.622
        val ut = norm(localT - lngHour, 24.0)
        val utc = GregorianCalendar(TimeZone.getTimeZone("UTC")).apply { clear(); set(y, m - 1, d, 0, 0, 0) }
        var millis = utc.timeInMillis + (ut * 3_600_000).toLong()
        // Make sure the result lands on the requested local date.
        val check = GregorianCalendar(tz).apply { timeInMillis = millis }
        val diff = (check.get(Calendar.YEAR) * 400 + check.get(Calendar.DAY_OF_YEAR)) - (y * 400 + n)
        if (diff > 0) millis -= 86_400_000L else if (diff < 0) millis += 86_400_000L
        return millis
    }

    private fun norm(v: Double, r: Double): Double { var x = v % r; if (x < 0) x += r; return x }
}

/** Hebrew date (ICU month numbering: 0 = Tishrei … 5 = Adar I, 6 = Adar / Adar II … 12 = Elul). */
data class HebDate(val year: Int, val month: Int, val day: Int, val leap: Boolean)

data class Holiday(val ka: String, val he: String, val yomTov: Boolean = false, val fast: Boolean = false)

data class DayInfo(
    val y: Int, val m: Int, val d: Int,
    val weekday: Int,              // Calendar.SUNDAY..SATURDAY
    val heb: HebDate,
    val holidays: List<Holiday>,
    val isShabbat: Boolean,
    val isYomTov: Boolean,
    val omer: Int?,
    val alot: Long?, val sunrise: Long?, val sofShema: Long?, val sofTefila: Long?,
    val chatzot: Long?, val minchaGedola: Long?, val plag: Long?,
    val sunset: Long?, val tzeit: Long?,
    /** Candle lighting this evening (Friday / eve of a holiday). */
    val candleLighting: Long?,
    /** True when candles are lit only after nightfall (second day of a holiday). */
    val candleAfterNightfall: Boolean,
    /** Shabbat / holiday ends this evening (Havdalah). */
    val havdalah: Long?
)

object JewishCalendar {
    fun isLeap(hy: Int) = ((7 * hy + 1) % 19) < 7

    fun toHebrew(y: Int, m: Int, d: Int): HebDate {
        val g = android.icu.util.GregorianCalendar(y, m - 1, d, 12, 0)
        val h = android.icu.util.HebrewCalendar()
        h.timeInMillis = g.timeInMillis
        val hy = h.get(android.icu.util.Calendar.EXTENDED_YEAR)
        return HebDate(hy, h.get(android.icu.util.Calendar.MONTH), h.get(android.icu.util.Calendar.DAY_OF_MONTH), isLeap(hy))
    }

    private fun monthLength(hy: Int, month: Int): Int {
        val h = android.icu.util.HebrewCalendar(hy, month, 1)
        return h.getActualMaximum(android.icu.util.Calendar.DAY_OF_MONTH)
    }

    /** Weekday (Calendar.SUNDAY..SATURDAY) of a Hebrew date. */
    private fun weekdayOf(hy: Int, month: Int, day: Int): Int =
        android.icu.util.HebrewCalendar(hy, month, day).get(android.icu.util.Calendar.DAY_OF_WEEK)

    fun holidays(h: HebDate, weekday: Int, israel: Boolean): List<Holiday> {
        val out = mutableListOf<Holiday>()
        val (hy, m, d) = Triple(h.year, h.month, h.day)
        val adar = 6
        fun add(ka: String, he: String, yt: Boolean = false, fast: Boolean = false) = out.add(Holiday(ka, he, yt, fast))
        when (m) {
            0 -> {
                if (d == 1 || d == 2) add("როშ ჰაშანა", "ראש השנה", yt = true)
                if (d == 3 && weekday != Calendar.SATURDAY || d == 4 && weekday == Calendar.SUNDAY) add("ცომ გედალია", "צום גדליה", fast = true)
                if (d == 9) add("ერევ იომ კიპური", "ערב יום כיפור")
                if (d == 10) add("იომ კიპური", "יום כיפור", yt = true, fast = true)
                if (d == 14) add("ერევ სუქოთი", "ערב סוכות")
                if (d == 15) add("სუქოთი", "סוכות", yt = true)
                if (d == 16) { if (israel) add("სუქოთი — ხოლ ჰამოედი", "חול המועד סוכות") else add("სუქოთი (II დღე)", "סוכות ב׳", yt = true) }
                if (d in 17..20) add("სუქოთი — ხოლ ჰამოედი", "חול המועד סוכות")
                if (d == 21) add("ჰოშანა რაბა", "הושענא רבה")
                if (d == 22) add(if (israel) "შემინი აცერეთ / სიმხათ თორა" else "შემინი აცერეთ", if (israel) "שמיני עצרת / שמחת תורה" else "שמיני עצרת", yt = true)
                if (d == 23 && !israel) add("სიმხათ თორა", "שמחת תורה", yt = true)
            }
            2 -> if (d >= 25) add("ხანუქა", "חנוכה")
            3 -> {
                val kislevLen = monthLength(hy, 2)
                if (d <= (if (kislevLen == 30) 2 else 3)) add("ხანუქა", "חנוכה")
                if (d == 10) add("ასარა ბეტევეთი", "עשרה בטבת", fast = true)
            }
            4 -> if (d == 15) add("ტუ ბიშვატი", "ט״ו בשבט")
            5 -> if (h.leap && d == 14) add("პურიმ კატანი", "פורים קטן")
            adar -> {
                val esther = if (weekdayOf(hy, adar, 13) == Calendar.SATURDAY) 11 else 13
                if (d == esther) add("თაანით ესთერი", "תענית אסתר", fast = true)
                if (d == 14) add("ფურიმი", "פורים")
                if (d == 15) add("შუშან ფურიმი", "שושן פורים")
            }
            7 -> {
                if (d == 14) add("ერევ პესახი", "ערב פסח")
                if (d == 15) add("პესახი", "פסח", yt = true)
                if (d == 16) { if (israel) add("პესახი — ხოლ ჰამოედი", "חול המועד פסח") else add("პესახი (II დღე)", "פסח ב׳", yt = true) }
                if (d in 17..20) add("პესახი — ხოლ ჰამოედი", "חול המועד פסח")
                if (d == 21) add("შვიი შელ პესახი", "שביעי של פסח", yt = true)
                if (d == 22 && !israel) add("აჰარონ შელ პესახი", "אחרון של פסח", yt = true)
                if (d == 27) add("იომ ჰაშოა", "יום השואה")
            }
            8 -> {
                if (d == 5) add("იომ ჰააცმაუთი", "יום העצמאות")
                if (d == 18) add("ლაგ ბაომერი", "ל״ג בעומר")
                if (d == 28) add("იომ იერუშალაიმი", "יום ירושלים")
            }
            9 -> {
                if (d == 5) add("ერევ შავუყოთი", "ערב שבועות")
                if (d == 6) add("შავუყოთი", "שבועות", yt = true)
                if (d == 7 && !israel) add("შავუყოთი (II დღე)", "שבועות ב׳", yt = true)
            }
            10 -> {
                val day = if (weekdayOf(hy, 10, 17) == Calendar.SATURDAY) 18 else 17
                if (d == day) add("შივა ასარ ბეთამუზი", "שבעה עשר בתמוז", fast = true)
            }
            11 -> {
                val day = if (weekdayOf(hy, 11, 9) == Calendar.SATURDAY) 10 else 9
                if (d == day) add("თიშა ბეავი", "תשעה באב", fast = true)
                if (d == 15) add("ტუ ბეავი", "ט״ו באב")
            }
            12 -> if (d == 29) add("ერევ როშ ჰაშანა", "ערב ראש השנה")
        }
        if ((d == 1 && m != 0) || d == 30) add("როშ ხოდეში", "ראש חודש")
        return out
    }

    /** Day of the Omer count (1..49) for the given Hebrew date, else null. Counted the evening before. */
    fun omer(h: HebDate): Int? {
        val n = when (h.month) {
            7 -> if (h.day >= 16) h.day - 15 else 0
            8 -> 15 + h.day
            9 -> if (h.day <= 5) 44 + h.day else 0
            else -> 0
        }
        return n.takeIf { it in 1..49 }
    }

    private fun basic(y: Int, m: Int, d: Int, city: ZmanimCity): Triple<HebDate, Int, List<Holiday>> {
        val wd = GregorianCalendar(y, m - 1, d).get(Calendar.DAY_OF_WEEK)
        val h = toHebrew(y, m, d)
        return Triple(h, wd, holidays(h, wd, city.israel))
    }

    private fun isRestDay(wd: Int, hol: List<Holiday>) = wd == Calendar.SATURDAY || hol.any { it.yomTov }

    fun day(y: Int, m: Int, d: Int, city: ZmanimCity): DayInfo {
        val tz = TimeZone.getTimeZone(city.tz)
        val (h, wd, hol) = basic(y, m, d, city)
        val next = GregorianCalendar(y, m - 1, d).apply { add(Calendar.DAY_OF_MONTH, 1) }
        val (_, nwd, nhol) = basic(next.get(Calendar.YEAR), next.get(Calendar.MONTH) + 1, next.get(Calendar.DAY_OF_MONTH), city)

        val sunrise = Sun.time(y, m, d, city.lat, city.lon, tz, Sun.SUNRISE_ZENITH, true)
        val sunset = Sun.time(y, m, d, city.lat, city.lon, tz, Sun.SUNRISE_ZENITH, false)
        val alot = Sun.time(y, m, d, city.lat, city.lon, tz, Sun.ALOT_ZENITH, true)
        val tzeit = Sun.time(y, m, d, city.lat, city.lon, tz, Sun.TZEIT_ZENITH, false)
        val hour = if (sunrise != null && sunset != null) (sunset - sunrise) / 12.0 else null
        fun sh(n: Double) = if (hour != null && sunrise != null) sunrise + (hour * n).toLong() else null

        val restToday = isRestDay(wd, hol)
        val restTomorrow = isRestDay(nwd, nhol)
        var candle: Long? = null
        var afterNight = false
        if (restTomorrow && sunset != null) {
            if (!restToday || nwd == Calendar.SATURDAY) {
                candle = sunset - city.candleMinutes * 60_000L
            } else {
                candle = tzeit; afterNight = true
            }
        }
        val havdalah = if (restToday && !restTomorrow) tzeit else null

        return DayInfo(
            y, m, d, wd, h, hol, wd == Calendar.SATURDAY, hol.any { it.yomTov }, omer(h),
            alot, sunrise, sh(3.0), sh(4.0), sh(6.0), sh(6.5), sh(10.75), sunset, tzeit,
            candle, afterNight, havdalah
        )
    }

    /** Requested synagogue schedule: Mincha 30m before sunset; Maariv 25m after sunset on Rosh Chodesh eve, otherwise 30m. */
    fun prayerTimes(info: DayInfo, city: ZmanimCity): Pair<Long?, Long?> {
        val next = GregorianCalendar(info.y, info.m - 1, info.d).apply { add(Calendar.DAY_OF_MONTH, 1) }
        val nextDay = day(next.get(Calendar.YEAR), next.get(Calendar.MONTH) + 1, next.get(Calendar.DAY_OF_MONTH), city)
        val roshChodeshTonight = nextDay.holidays.any { it.ka == "როშ ხოდეში" }
        return info.sunset?.minus(30 * 60_000L) to info.sunset?.plus((if (roshChodeshTonight) 25 else 30) * 60_000L)
    }

    /** Next candle lighting and the matching end time, starting from today. */
    fun nextRestPeriod(fromY: Int, fromM: Int, fromD: Int, city: ZmanimCity): Pair<DayInfo, DayInfo?>? {
        val c = GregorianCalendar(fromY, fromM - 1, fromD)
        var start: DayInfo? = null
        repeat(30) {
            val di = day(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), city)
            if (start == null && di.candleLighting != null && !di.candleAfterNightfall) start = di
            else if (start == null && (di.isShabbat || di.isYomTov) && di.havdalah != null && it == 0) {
                // We are already inside Shabbat / holiday today.
                return di to di
            }
            if (start != null && di.havdalah != null) return start!! to di
            c.add(Calendar.DAY_OF_MONTH, 1)
        }
        return start?.let { it to null }
    }

    // ---------- Formatting ----------

    private val monthsHe = arrayOf("תשרי", "חשון", "כסלו", "טבת", "שבט", "אדר א׳", "אדר", "ניסן", "אייר", "סיון", "תמוז", "אב", "אלול")
    private val monthsKa = arrayOf("თიშრეი", "ხეშვანი", "კისლევი", "ტევეთი", "შვატი", "ადარ I", "ადარი", "ნისანი", "იიარი", "სივანი", "თამუზი", "ავი", "ელული")

    fun monthNameHe(h: HebDate) = if (h.month == 6 && h.leap) "אדר ב׳" else monthsHe[h.month]
    fun monthNameKa(h: HebDate) = if (h.month == 6 && h.leap) "ადარ II" else monthsKa[h.month]

    /** Hebrew numerals (gematria), e.g. 15 -> ט״ו, 5787 -> תשפ״ז. */
    fun gematria(n0: Int): String {
        var n = n0 % 1000
        val sb = StringBuilder()
        val hundreds = arrayOf("", "ק", "ר", "ש", "ת", "תק", "תר", "תש", "תת", "תתק")
        val tens = arrayOf("", "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ", "צ")
        val ones = arrayOf("", "א", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט")
        sb.append(hundreds[n / 100]); n %= 100
        when (n) {
            15 -> sb.append("טו")
            16 -> sb.append("טז")
            else -> { sb.append(tens[n / 10]); sb.append(ones[n % 10]) }
        }
        val s = sb.toString()
        return if (s.length == 1) "$s׳" else s.dropLast(1) + "״" + s.last()
    }

    fun hebrewDateHe(h: HebDate) = "${gematria(h.day)} ${monthNameHe(h)} ${gematria(h.year)}"
    fun hebrewDateKa(h: HebDate) = "${h.day} ${monthNameKa(h)} ${h.year}"
}
