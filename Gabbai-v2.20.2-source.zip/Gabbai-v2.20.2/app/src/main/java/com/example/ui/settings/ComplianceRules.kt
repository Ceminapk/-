package com.example.ui.settings

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.data.model.MemberCompliance
import com.example.data.model.MemberEntity

enum class ListStatus { NORMAL, RED, BLACK }

/** Why a member is on the red list (shown on the member card). */
enum class RedReason { MANUAL, DEBT_OVER_LIMIT, OVERDUE_DAYS }

/**
 * Red / black list rules.
 * - Black list: only when the gabbai sets it by hand (sanction). Black always wins over red.
 * - Red list: set by hand, OR automatically when the debt reaches the amount limit,
 *   OR when there is an unpaid debt / unpaid dues and no payment for the given number of days.
 */
object ComplianceRules {
    var daysThreshold by mutableStateOf(60)
    var amountThreshold by mutableStateOf(300.0)
    private var prefs: android.content.SharedPreferences? = null

    fun init(context: Context) {
        val p = context.getSharedPreferences("gabbai_settings", Context.MODE_PRIVATE)
        prefs = p
        daysThreshold = p.getInt("red_days", 60)
        amountThreshold = p.getFloat("red_amount", 300f).toDouble()
    }

    fun save(days: Int, amount: Double) {
        daysThreshold = days.coerceIn(1, 3650)
        amountThreshold = amount.coerceAtLeast(1.0)
        prefs?.edit()?.putInt("red_days", daysThreshold)?.putFloat("red_amount", amountThreshold.toFloat())?.apply()
    }

    fun status(m: MemberEntity, now: Long = System.currentTimeMillis()): ListStatus =
        statusFor(m, daysThreshold, amountThreshold, now)

    fun redReason(m: MemberEntity, now: Long = System.currentTimeMillis()): RedReason? =
        redReasonFor(m, daysThreshold, amountThreshold, now)

    fun statusFor(m: MemberEntity, days: Int, amount: Double, now: Long): ListStatus = when {
        m.complianceCategory == MemberCompliance.BLACK_LIST -> ListStatus.BLACK
        redReasonFor(m, days, amount, now) != null -> ListStatus.RED
        else -> ListStatus.NORMAL
    }

    fun redReasonFor(m: MemberEntity, days: Int, amount: Double, now: Long): RedReason? {
        if (m.complianceCategory == MemberCompliance.BLACK_LIST) return null
        if (m.complianceCategory == MemberCompliance.RED_LIST) return RedReason.MANUAL
        if (m.outstandingDebt > 0 && m.outstandingDebt >= amount) return RedReason.DEBT_OVER_LIMIT
        val owes = m.outstandingDebt > 0 || !m.duesPaid
        if (owes && daysSincePayment(m, now) >= days) return RedReason.OVERDUE_DAYS
        return null
    }

    /** Days since the last payment; never paid counts as "very long ago". */
    fun daysSincePayment(m: MemberEntity, now: Long): Long =
        if (m.lastPaymentDateMillis <= 0L) Long.MAX_VALUE / 4
        else ((now - m.lastPaymentDateMillis).coerceAtLeast(0L)) / 86_400_000L
}
