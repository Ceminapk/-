package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemberStatus
import com.example.ui.calendar.*
import com.example.ui.components.*
import com.example.ui.settings.*
import com.example.ui.share.Messages
import com.example.ui.share.Share
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private fun hm(t: Long?) = if (t == null) "—" else SimpleDateFormat("HH:mm", Locale.US).format(Date(t))
private fun dhm(t: Long) = SimpleDateFormat("dd.MM HH:mm", Locale.US).format(Date(t))

/** Halachic calculators, texts and community tools. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ToolsScreen(viewModel: GabbaiViewModel, modifier: Modifier = Modifier) {
    val state by viewModel.uiState.collectAsState()
    val settings = LocalAppSettings.current
    val context = LocalContext.current
    val city = CalendarPrefs.city
    val now = remember { System.currentTimeMillis() }
    val c = remember { Calendar.getInstance() }
    val today = remember(city) { JewishCalendar.day(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), city) }
    val living = state.members.filter { it.status != MemberStatus.DECEASED }
    var scanned by remember { mutableStateOf<com.example.data.model.MemberEntity?>(null) }

    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp).testTag("tools_screen"), contentPadding = PaddingValues(top = 10.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // ---------- QR scan ----------
        item {
            Tool(Icons.Default.QrCodeScanner, L("წევრის სწრაფი ძებნა QR კოდით")) {
                Button(onClick = {
                    runCatching {
                        com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(context).startScan()
                            .addOnSuccessListener { b -> val id = MemberQr.parse(b.rawValue); scanned = state.members.firstOrNull { it.id == id }
                                if (scanned == null) android.widget.Toast.makeText(context, L("ეს QR კოდი წევრს არ ეკუთვნის"), android.widget.Toast.LENGTH_SHORT).show() }
                    }
                }, modifier = Modifier.testTag("btn_scan_qr")) { Icon(Icons.Default.QrCodeScanner, null); Spacer(Modifier.width(6.dp)); Text(L("სკანირება")) }
            }
        }
        // ---------- Today ----------
        item {
            Tool(Icons.Default.NightsStay, L("დღეს: ომერი და ქიდუშ ლევანა")) {
                Text(JewishCalendar.hebrewDateKa(today.heb) + " • " + JewishCalendar.hebrewDateHe(today.heb), color = CosmicCelestialGold)
                // The omer of tonight is the count of the next Hebrew day.
                val tomorrow = JewishCalendar.toHebrew(JewishTools.plusDays(now, 1).let { Calendar.getInstance().apply { timeInMillis = it } }.let { it.get(Calendar.YEAR) }, Calendar.getInstance().apply { timeInMillis = JewishTools.plusDays(now, 1) }.get(Calendar.MONTH) + 1, Calendar.getInstance().apply { timeInMillis = JewishTools.plusDays(now, 1) }.get(Calendar.DAY_OF_MONTH))
                val omer = JewishCalendar.omer(tomorrow)
                if (omer != null) {
                    Text(Lf("სეფირათ ჰაომერი ამაღამ (ცეთ ჰაქოხავიმის შემდეგ, {0}): დღე {1}", hm(today.tzeit), omer), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                    Text("בָּרוּךְ אַתָּה ה׳ אֱלֹהֵינוּ מֶלֶךְ הָעוֹלָם אֲשֶׁר קִדְּשָׁנוּ בְּמִצְוֹתָיו וְצִוָּנוּ עַל סְפִירַת הָעֹמֶר", color = CosmicTextSecondary, fontSize = 13.sp)
                    Text(JewishTools.omerText(omer), color = CosmicCelestialGold, fontWeight = FontWeight.Bold)
                    val (ka, he) = JewishTools.omerSefira(omer); Text("$ka • $he", color = CosmicTextSecondary, fontSize = 12.sp)
                } else Text(L("ომერის დათვლის პერიოდი არ არის (ფესახიდან შავუყოთამდე)."), color = CosmicTextMuted, fontSize = 13.sp)
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                val kl = JewishTools.kiddushLevana(today.heb.year, today.heb.month)
                Text(Lf("მოლადი: {0}", dhm(JewishTools.molad(today.heb.year, today.heb.month))), color = CosmicTextSecondary, fontSize = 13.sp)
                Text(Lf("ქიდუშ ლევანა: {0} — {1}", dhm(kl.start), dhm(kl.end)), color = CosmicTextPrimary, fontWeight = FontWeight.SemiBold)
                Text(if (now in kl.start..kl.end) L("✅ ახლა შეიძლება — მოწმენდილ საღამოს გამოიყვანეთ ჯამაათი ეზოში (საუკეთესოა მოცაეი შაბათს).") else L("ამ წუთას ქიდუშ ლევანას დრო არ არის."), color = CosmicEmeraldSuccess, fontSize = 13.sp)
                Text(L("ზოგი თემი იწყებს მოლადიდან მე-3 დღეს; აქ ნაჩვენებია სეფარდული წესი (მე-7 დღე)."), color = CosmicTextMuted, fontSize = 11.sp)
            }
        }
        // ---------- Fasts / Eruv / Yizkor ----------
        item {
            val fasts = remember(city) { JewishTools.upcomingFasts(now, 90, city) }
            val eruv = remember(city) { JewishTools.eruvTavshilinDays(now, 120, city) }
            val yizkor = remember(city) { JewishTools.nextYizkor(now, city) }
            Tool(Icons.Default.NoFood, L("მარხვები, ერუვ თავშილინი და იზქორი")) {
                if (fasts.isEmpty()) Text(L("უახლოეს 90 დღეში მარხვა არ არის."), color = CosmicTextMuted, fontSize = 13.sp)
                fasts.forEach { f ->
                    Text("${f.name} • ${f.nameHe} — ${DualDates.gregorianText(f.dayMillis)}", fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                    Text(Lf("იწყება: {0} ({1}) • მთავრდება: {2}", hm(f.starts), if (f.fromSunsetBefore) L("წინა საღამოს, მზის ჩასვლისას") else L("განთიადისას"), hm(f.ends)), color = CosmicTextSecondary, fontSize = 13.sp)
                    Text(L("შახარითსა და მინხაში: „ვაიეხალი“ (თორის კითხვა), ჰაზანი — „ანენუ“; მინხაზე — თეფილინი (თიშა ბეავს)."), color = CosmicTextMuted, fontSize = 12.sp)
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                if (eruv.isEmpty()) Text(L("ერუვ თავშილინი უახლოეს 4 თვეში საჭირო არ არის."), color = CosmicTextMuted, fontSize = 13.sp)
                eruv.forEach { e ->
                    Text(Lf("🍞 ერუვ თავშილინი: {0} — დღესასწაული პარასკევს ემთხვევა.", DualDates.gregorianText(e)), color = CosmicCelestialGold, fontWeight = FontWeight.Bold)
                    OutlinedButton(onClick = { Share.text(context, Lf("შეხსენება: {0} გააკეთეთ ერუვ თავშილინი (პური და მოხარშული საკვები), რომ დღესასწაულზე შაბათისთვის მომზადება შეიძლებოდეს. {1}", DualDates.gregorianText(e), settings.shulName())) }) { Text(L("ჯამაათისთვის შეხსენება")) }
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                yizkor?.let { (d, name) -> Text(Lf("შემდეგი იზქორი: {0} — {1}", DualDates.gregorianText(d), name), color = CosmicTextPrimary, fontWeight = FontWeight.SemiBold) }
                val names = state.yahrzeits.sortedBy { it.deceasedName }.map { y -> (y.hebrewName.ifBlank { y.deceasedName }) + " ז״ל" + if (y.relatedMemberName.isNotBlank()) " — ${y.relatedMemberName}" else "" }
                Text(Lf("იზქორის სია: {0} სახელი", names.size), color = CosmicTextSecondary, fontSize = 13.sp)
                OutlinedButton(onClick = { Share.text(context, L("იზქორი — მოსახსენიებელი სულები") + "\n\n" + names.joinToString("\n")) }, enabled = names.isNotEmpty()) { Text(L("იზქორის სიის გაზიარება / ამობეჭდვა")) }
            }
        }
        // ---------- Birth calculators ----------
        item {
            var birth by remember { mutableStateOf(0L) }
            var afterSunset by remember { mutableStateOf(false) }
            var girl by remember { mutableStateOf(false) }
            Tool(Icons.Default.ChildCare, L("ბრით-მილა, პიდიონ ჰაბენი, ბარ/ბათ-მიცვა")) {
                DualDateField(L("დაბადების თარიღი"), birth, { birth = it }, optional = true)
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(afterSunset, { afterSunset = it }); Text(L("დაიბადა მზის ჩასვლის შემდეგ"), fontSize = 13.sp, color = CosmicTextSecondary) }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(girl, { girl = it }); Text(L("გოგონა (ბათ-მიცვა 12 წელზე)"), fontSize = 13.sp, color = CosmicTextSecondary) }
                if (birth > 0) {
                    val hb = JewishTools.hebrewBirth(birth, afterSunset)
                    Text(Lf("ებრაული დაბადების დღე: {0}", JewishCalendar.hebrewDateKa(hb) + " • " + JewishCalendar.hebrewDateHe(hb)), color = CosmicCelestialGold)
                    if (!girl) {
                        val brit = JewishTools.britMilah(birth, afterSunset)
                        Text(Lf("✂ ბრით-მილა (მე-8 დღე): {0}", DualDates.bothText(brit)), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                        Text(L("შაბათსაც ტარდება, თუ ბავშვი ბუნებრივად დაიბადა; საკეისრო კვეთის ან ჯანმრთელობის მიზეზით — გადაიდება. მოჰელთან დაადასტურეთ."), color = CosmicTextMuted, fontSize = 12.sp)
                        val pid = JewishTools.pidyonHaben(birth, afterSunset, city)
                        Text(Lf("🪙 პიდიონ ჰაბენი (31-ე დღე): {0}", DualDates.bothText(pid)), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                        Text(L("მხოლოდ დედის პირმშო ვაჟზე, თუ მშობლები არ არიან ქოჰენი/ლევი. მოიწვიეთ ქოჰენი; შაბათსა და დღესასწაულზე არ ტარდება."), color = CosmicTextMuted, fontSize = 12.sp)
                    }
                    val bm = JewishTools.barMitzvah(birth, afterSunset, girl)
                    Text(Lf(if (girl) "ბათ-მიცვა: {0}" else "ბარ-მიცვა: {0}", DualDates.bothText(bm.dateMillis)), fontWeight = FontWeight.Bold, color = CosmicCelestialGold)
                    Text(Lf("თორაზე ასვლის შაბათი: {0}", DualDates.bothText(bm.shabbatMillis)), color = CosmicTextSecondary)
                }
                val soon = remember(state.members) { Relatives.upcomingMitzvot(state.members, 365) }
                if (soon.isNotEmpty()) {
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    Text(L("მომავალი წლის ბარ/ბათ-მიცვები ჯამაათში:"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                    soon.forEach { Text("• ${it.child.name} (${it.member.fullName}) — ${DualDates.gregorianText(it.dateMillis)}", color = CosmicTextSecondary, fontSize = 13.sp) }
                }
            }
        }
        // ---------- Mi Shebeirach ----------
        item {
            var name by remember { mutableStateOf("") }
            var sick by remember { mutableStateOf("") }
            var amount by remember { mutableStateOf("") }
            var cur by remember { mutableStateOf(I18n.defaultCurrency) }
            val m = living.firstOrNull { it.fullName == name }
            Tool(Icons.Default.AutoStories, L("მიშებერახი — ცოცხალი ტექსტი")) {
                MemberField(L("ვინ ავიდა თორაზე"), name, { name = it }, living.map { it.fullName }, viewModel::quickAddMember)
                OutlinedTextField(sick, { sick = it }, label = { Text(L("ავადმყოფის სახელი (რაფუა შელემა), არასავალდებულო")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                AmountCurrencyField(L("ნედერის თანხა"), amount, { amount = it }, cur, { cur = it })
                if (name.isNotBlank()) {
                    val text = Messages.miShebeirach(name, m?.hebrewName.orEmpty(), sick, amount.toDoubleOrNull() ?: 0.0, cur)
                    CosmicGlassCard(Modifier.fillMaxWidth(), borderColor = CosmicCelestialGold) { Text(text, fontSize = 17.sp, color = CosmicTextPrimary, lineHeight = 26.sp) }
                    Row { OutlinedButton(onClick = { Share.text(context, text) }) { Text(L("გაზიარება")) }
                        Spacer(Modifier.width(6.dp))
                        if ((amount.toDoubleOrNull() ?: 0.0) > 0) Button(onClick = { viewModel.addQuickNeder(name, amount.toDouble(), cur, L("მიშებერახი"), false) }) { Text(L("ნედერის ჩაწერა")) } }
                }
            }
        }
        // ---------- Minyan SOS ----------
        item {
            var prayer by remember { mutableStateOf(L("მინხა")) }
            var missing by remember { mutableStateOf("2") }
            val (mincha, maariv) = JewishCalendar.prayerTimes(today, city)
            val time = when (prayer) { L("მინხა") -> hm(mincha); L("ყარბითი") -> hm(maariv); else -> settings.shacharitTime }
            val msg = Messages.minyanSos(prayer, time, missing.toIntOrNull() ?: 1, settings.shulName())
            Tool(Icons.Default.Groups, L("მინიანის SOS")) {
                AppDropdown(L("ლოცვა"), prayer, listOf(L("შახარითი"), L("მინხა"), L("ყარბითი")), { it }, { prayer = it })
                OutlinedTextField(missing, { v -> missing = v.filter(Char::isDigit).take(1) }, label = { Text(L("რამდენი კაცი აკლია")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = { Share.text(context, msg) }, modifier = Modifier.testTag("btn_minyan_sos")) { Icon(Icons.Default.Campaign, null); Spacer(Modifier.width(6.dp)); Text(L("გაგზავნა ჯგუფში")) }
                Text(L("ან პირადად (ტელეფონის მქონე წევრები):"), color = CosmicTextSecondary, fontSize = 12.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    living.filter { it.phone.isNotBlank() }.take(40).forEach { mm -> AssistChip(onClick = { Share.whatsapp(context, mm.phone, msg) }, label = { Text(mm.fullName, fontSize = 12.sp) }) }
                }
            }
        }
        // ---------- Weekly digest ----------
        item {
            Tool(Icons.Default.Newspaper, L("შაბათის დაიჯესტი")) {
                var parasha by remember { mutableStateOf("") }
                SuggestField(L("კვირის ფარაშა"), parasha, { parasha = it }, state.aliyot.map { it.parashaName }.distinct())
                Button(onClick = {
                    val rest = JewishCalendar.nextRestPeriod(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), city)
                    val eve = rest?.first
                    val (mi, ma) = if (eve != null) JewishCalendar.prayerTimes(eve, city) else (null to null)
                    val ys = YahrzeitTools.within(state.yahrzeits, 8).map { "${it.item.deceasedName} ז״ל — ${DualDates.gregorianText(it.dateMillis)}" }
                    val bs = BirthdayTools.within(state.members, 8).map { "${it.member.fullName} — ${DualDates.gregorianText(it.dateMillis)}" } +
                        Relatives.upcomingMitzvot(state.members, 8).map { "${it.child.name} — " + (if (it.bat) L("ბათ-მიცვა") else L("ბარ-მიცვა")) }
                    val ev = state.events.filter { it.dateMillis in now..(now + 8 * 86_400_000L) }.map { "${it.title} — ${DualDates.gregorianText(it.dateMillis)}" }
                    Share.text(context, Messages.weeklyDigest(Messages.DigestInput(parasha, eve?.candleLighting, rest?.second?.havdalah, settings.shacharitTime, mi, ma, ys, bs, ev), settings.shulName()))
                }, modifier = Modifier.testTag("btn_weekly_digest")) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text(L("დაიჯესტის შექმნა და გაზიარება")) }
            }
        }
        // ---------- Rosh Hashana ----------
        item {
            var open by remember { mutableStateOf(false) }
            Tool(Icons.Default.Celebration, L("როშ ჰაშანას სედერი და თაშლიხი")) {
                TextButton(onClick = { open = !open }) { Text(if (open) L("დამალვა") else L("გზამკვლევის ჩვენება")) }
                if (open) {
                    simanim.forEach { (ka, he) -> Text("• " + L(ka), fontWeight = FontWeight.SemiBold, color = CosmicTextPrimary); Text(he, color = CosmicCelestialGold, fontSize = 14.sp) }
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    Text(L("თაშლიხი: როშ ჰაშანას პირველ დღეს მინხის შემდეგ (თუ შაბათია — მეორე დღეს) ჯამაათი მიდის მდინარესთან ან წყალთან, ამბობს „მი ელ კამოხა“ (მიხა 7:18–20) და ფსალმუნებს, და ჯიბეებს იბერტყავს — ცოდვების „გადაყრის“ სიმბოლოდ."), color = CosmicTextSecondary, fontSize = 13.sp)
                    Text("מִי אֵל כָּמוֹךָ נֹשֵׂא עָוֹן וְעֹבֵר עַל פֶּשַׁע... וְתַשְׁלִיךְ בִּמְצֻלוֹת יָם כָּל חַטֹּאתָם", color = CosmicCelestialGold, fontSize = 14.sp)
                }
            }
        }
        item { HalachaPrompterTool() }
        item { SeatMapTool(state) }
        item { AliyahFairnessTool(state) }
        item { WhatsappReceiptTool(state) }
        item { BoardMonthlyReportTool(state) }
        item { KioskLauncherTool(state) }
        item { VoiceDebriefTool(state, viewModel) }
        item { PdfReceiptTool(state) }
        item { BimahHelperTool(state) }
        item { MinyanStarsTool(state, viewModel) }
        item { BudgetAlarmTool(state) }
        item { AnnualReportTool(state) }
        item { ShabbatShalomTool(state) }
        item { HebrewNameTool(state) }
        item { MemberTimelineTool(state) }
        item { AdvanceAliyotTool(state, viewModel) }
        item { ShabbatBulletinTool(state) }
        item { FinanceChartTool(state) }
        item { ReceiptPhotosTool(state) }
        item { GroupMessageTool(state) }
        item { BarMitzvahTool(state) }
        item { CertificateQrTool(state) }
        item { NetzCountdownTool() }
        item { DedicationTool() }
        item { KashrutGuideTool() }
    }
    scanned?.let { m ->
        FormDialog(onDismissRequest = { scanned = null },
            title = { Text(m.fullName, fontWeight = FontWeight.Bold) },
            text = { Column {
                if (m.hebrewName.isNotBlank()) Text(m.hebrewName, color = CosmicCelestialGold)
                Text(m.role.titleKa + " • " + m.status.titleKa, color = CosmicTextSecondary)
                if (m.phone.isNotBlank()) Text(m.phone, color = CosmicTextSecondary)
                Text(Lf("ვალი: {0}", money(m.outstandingDebt, m.currency)), color = if (m.outstandingDebt > 0) CosmicAlertRose else CosmicEmeraldSuccess)
                Text(if (m.duesPaid) L("საწევრო: გადახდილია ✓") else L("საწევრო: ვალი"), color = CosmicTextSecondary)
                val given = state.transactions.filter { it.memberName.equals(m.fullName, true) && it.type == com.example.data.model.TransactionType.INCOME }
                Text(Lf("შემოწირულობები: {0} ჩანაწერი", given.size), color = CosmicTextSecondary)
                MemberQuickActions(m, state.transactions)
            } },
            confirmButton = { TextButton(onClick = { scanned = null }) { Text(L("დახურვა")) } })
    }
}

private val simanim = listOf(
    "ვაშლი თაფლში — ტკბილი წელი" to "יְהִי רָצוֹן... שֶׁתְּחַדֵּשׁ עָלֵינוּ שָׁנָה טוֹבָה וּמְתוּקָה",
    "ფინიკი (თამარ) — მტრები დასრულდნენ" to "יְהִי רָצוֹן... שֶׁיִּתַּמּוּ אוֹיְבֵינוּ",
    "ბროწეული — მიცვები ბროწეულის მარცვლებივით" to "שֶׁנִּרְבֶּה זְכֻיּוֹת כְּרִמּוֹן",
    "ლობიო (რუბია) — დამსახურებები გაგვიმრავლდეს" to "שֶׁיִּרְבּוּ זְכֻיּוֹתֵינוּ",
    "პრასი (კარტი) — მტრები მოიკვეთონ" to "שֶׁיִּכָּרְתוּ שׂוֹנְאֵינוּ",
    "ჭარხლის ფოთოლი (სილკა) — მტრები განიდევნონ" to "שֶׁיִּסְתַּלְּקוּ אוֹיְבֵינוּ",
    "გოგრა (კრა) — გაუქმდეს მძიმე განაჩენი" to "שֶׁתִּקְרַע רֹעַ גְּזַר דִּינֵנוּ",
    "თევზის / ცხვრის თავი — ვიყოთ თავი და არა კუდი" to "שֶׁנִּהְיֶה לְרֹאשׁ וְלֹא לְזָנָב"
)

@Composable
private fun Tool(icon: ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    CosmicGlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = CosmicCelestialGold); Spacer(Modifier.width(8.dp)); Text(title, fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 16.sp) }
        Spacer(Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
    }
}
