package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.sync.*
import com.example.ui.components.AppDropdown
import com.example.ui.components.CosmicGlassCard
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.share.Share
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

fun roleTitle(r: String) = when (r) {
    "owner" -> L("მთავარი გაბაი (მფლობელი)"); "gabbai" -> L("გაბაი — სრული წვდომა")
    "treasurer" -> L("ხაზინადარი — ფინანსები"); "deputy" -> L("მოადგილე — ალიები"); else -> r
}
private fun sectionTitle(s: String) = when (s) { "members" -> L("წევრები"); "finance" -> L("ფინანსები"); "aliyot" -> L("ალიები"); else -> L("ჟურნალები") }

/** Online server: password sign-in, synagogue team with roles, two-way sync. */
@Composable
fun OnlineTeamSection() {
    val ctx = LocalContext.current
    val sync = remember { CloudSync(ctx.applicationContext) }
    val scope = rememberCoroutineScope()
    var signedIn by remember { mutableStateOf(sync.signedIn) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var shuls by remember { mutableStateOf<List<Shul>>(emptyList()) }
    var team by remember { mutableStateOf<List<TeamMember>>(emptyList()) }
    val current = shuls.firstOrNull { it.id == sync.shulId }

    fun run(block: suspend () -> Unit) { scope.launch { busy = true; msg = ""; try { block() } catch (e: Exception) { msg = "⚠ " + onlineError(e.message) }; busy = false } }
    suspend fun refresh() {
        shuls = sync.myShuls()
        if (sync.shulId.isBlank() || shuls.none { it.id == sync.shulId }) sync.shulId = shuls.firstOrNull()?.id ?: ""
        team = if (sync.shulId.isNotBlank()) sync.team() else emptyList()
    }
    LaunchedEffect(signedIn) { if (signedIn) run { refresh() } }

    CosmicGlassCard(Modifier.fillMaxWidth().testTag("online_team")) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CloudSync, null, tint = CosmicCelestialGold); Spacer(Modifier.width(8.dp))
            Text(L("რამდენიმე გაბაის ერთად მუშაობა (ონლაინ)"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 16.sp)
        }
        Spacer(Modifier.height(6.dp))
        if (!signedIn) {
            var email by remember { mutableStateOf("") }
            var pass by remember { mutableStateOf("") }
            Text(L("შედით ელფოსტითა და პაროლით. მონაცემები ტელეფონზეც რჩება და ინტერნეტის გარეშეც მუშაობს."), color = CosmicTextMuted, fontSize = 12.sp)
            OutlinedTextField(email, { email = it }, label = { Text(L("ელფოსტა")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(pass, { pass = it }, label = { Text(L("პაროლი (მინ. 8 სიმბოლო)")) }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy && email.contains("@") && pass.length >= 8, onClick = { run { sync.signIn(email, pass); signedIn = true } }, modifier = Modifier.weight(1f)) { Text(L("შესვლა")) }
                OutlinedButton(enabled = !busy && email.contains("@") && pass.length >= 8, onClick = { run {
                    if (sync.signUp(email, pass)) signedIn = true else msg = L("დადასტურების ბმული გამოგზავნილია ელფოსტაზე. დააჭირეთ მას და შემდეგ შედით.")
                } }, modifier = Modifier.weight(1f)) { Text(L("რეგისტრაცია")) }
            }
            TextButton(enabled = email.contains("@"), onClick = { run { sync.resetPassword(email); msg = L("პაროლის აღდგენის ბმული გამოგზავნილია ელფოსტაზე.") } }) { Text(L("დაგავიწყდათ პაროლი?")) }
        } else {
            Text(Lf("შესული ხართ: {0}", sync.email), color = CosmicTextSecondary, fontSize = 13.sp)
            if (shuls.isEmpty()) {
                var name by remember { mutableStateOf("") }
                var code by remember { mutableStateOf("") }
                Text(L("შექმენით სინაგოგა (თქვენ იქნებით მთავარი გაბაი) ან შეუერთდით კოდით."), color = CosmicTextMuted, fontSize = 12.sp)
                OutlinedTextField(name, { name = it }, label = { Text(L("სინაგოგის სახელი")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(enabled = !busy && name.isNotBlank(), onClick = { run { sync.shulId = sync.createShul(name); refresh(); sync.sync("owner", true); msg = L("სინაგოგა შეიქმნა და მონაცემები აიტვირთა.") } }, modifier = Modifier.fillMaxWidth()) { Text(L("სინაგოგის შექმნა")) }
                OutlinedTextField(code, { code = it }, label = { Text(L("მოწვევის კოდი")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedButton(enabled = !busy && code.length >= 6, onClick = { run { sync.shulId = sync.join(code); refresh(); msg = L("შეუერთდით! ახლა დააჭირეთ „სინქრონიზაციას“.") } }, modifier = Modifier.fillMaxWidth()) { Text(L("შეერთება")) }
            } else {
                if (shuls.size > 1) AppDropdown(label = L("სინაგოგა"), value = sync.shulId, options = shuls.map { it.id }, optionLabel = { id -> shuls.first { it.id == id }.name },
                    onSelected = { sync.shulId = it; run { refresh() } })
                current?.let { c ->
                    Text(c.name, color = CosmicCelestialGold, fontWeight = FontWeight.Bold)
                    Text(Lf("თქვენი როლი: {0}", roleTitle(c.role)), color = CosmicTextSecondary, fontSize = 13.sp)
                    Text(L("ხედავთ: ") + SyncRoles.sections.filter { SyncRoles.canRead(c.role, it) }.joinToString { sectionTitle(it) } +
                        " • " + L("ცვლით: ") + SyncRoles.sections.filter { SyncRoles.canWrite(c.role, it) }.joinToString { sectionTitle(it) }, color = CosmicTextMuted, fontSize = 12.sp)
                    if (sync.lastSync > 0) Text(Lf("ბოლო სინქრონიზაცია: {0}", SimpleDateFormat("dd.MM HH:mm", Locale.US).format(Date(sync.lastSync))), color = CosmicTextMuted, fontSize = 12.sp)
                    Button(enabled = !busy, onClick = { run {
                        val r = sync.sync(c.role, true)
                        msg = buildString {
                            append(L("სინქრონიზაცია დასრულდა.")); if (r.pulled.isNotEmpty()) append(" " + L("მიღებულია: ") + r.pulled.joinToString { sectionTitle(it) })
                            if (r.pushed.isNotEmpty()) append(" " + L("გაგზავნილია: ") + r.pushed.joinToString { sectionTitle(it) })
                            if (r.conflicts.isNotEmpty()) append(" ⚠ " + L("ონლაინ მონაცემებიც და თქვენი ცვლილებებიც არსებობს. არაფერი წაიშალა. კონფლიქტური სექციები: ") + r.conflicts.joinToString { sectionTitle(it) })
                        }
                    } }, modifier = Modifier.fillMaxWidth().testTag("btn_sync")) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.Sync, null)
                        Spacer(Modifier.width(6.dp)); Text(L("სინქრონიზაცია"))
                    }
                    Text(L("გუნდი:"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                    team.forEach { t ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(t.email, color = CosmicTextPrimary, fontSize = 13.sp); Text(roleTitle(t.role), color = CosmicTextMuted, fontSize = 11.sp) }
                            if (c.role == "owner" && t.role != "owner") {
                                AppDropdown(label = L("როლი"), value = t.role, options = listOf("gabbai", "treasurer", "deputy", "remove"),
                                    optionLabel = { if (it == "remove") L("გუნდიდან ამოღება") else roleTitle(it) },
                                    onSelected = { r -> run { sync.setRole(t.userId, r); refresh() } }, modifier = Modifier.width(150.dp))
                            }
                        }
                    }
                    if (c.role == "owner") {
                        var role by remember { mutableStateOf("gabbai") }
                        AppDropdown(label = L("ახალი წევრის როლი"), value = role, options = listOf("gabbai", "treasurer", "deputy"), optionLabel = { roleTitle(it) }, onSelected = { role = it })
                        OutlinedButton(enabled = !busy, onClick = { run {
                            val code = sync.createInvite(role)
                            Share.text(ctx, Lf("მოგიწვიეთ სინაგოგის აპში „{0}“ — როლი: {1}. Gabbai Cosmos → პარამეტრები → ონლაინ → კოდი: {2} (მოქმედებს 7 დღე)", c.name, roleTitle(role), code))
                            msg = Lf("მოწვევის კოდი: {0}", code)
                        } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(6.dp)); Text(L("მოწვევის გაგზავნა")) }
                    }
                }
            }
            TextButton(onClick = { sync.signOut(); signedIn = false; shuls = emptyList(); team = emptyList() }) { Text(L("გასვლა")) }
        }
        if (msg.isNotBlank()) Text(msg, color = CosmicCelestialGold, fontSize = 13.sp)
    }
}

private fun onlineError(message: String?): String = L(when {
    message == null -> "შეცდომა"
    message.contains("Invalid login", true) -> "არასწორი ელფოსტა ან პაროლი."
    message.contains("Email not confirmed", true) -> "ჯერ დაადასტურეთ ელფოსტა."
    message.contains("not signed in", true) || message.contains("refresh token", true) -> "ხელახლა შედით ანგარიშში."
    message.contains("permission", true) || message.contains("owner", true) -> "ამ მოქმედებისთვის უფლება არ გაქვთ."
    message.contains("invite", true) -> "მოწვევის კოდი არასწორია ან ვადა გაუვიდა."
    message.contains("rate", true) || message.contains("429") -> "ძალიან ბევრი მოთხოვნაა. სცადეთ მოგვიანებით."
    message.any { it in '\u10A0'..'\u10FF' } -> message
    else -> "ონლაინ კავშირი ვერ შესრულდა. შეამოწმეთ ინტერნეტი და სცადეთ ხელახლა."
})
