package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.calendar.*
import com.example.ui.components.*
import com.example.ui.settings.*
import com.example.ui.share.PdfMaker
import com.example.ui.share.Share
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiUiState
import com.example.ui.viewmodel.GabbaiViewModel
import java.text.SimpleDateFormat
import java.util.*

private fun d7(t: Long) = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(t))
private fun hm7(t: Long?) = if (t == null) "—" else SimpleDateFormat("HH:mm", Locale.US).format(Date(t))
private fun dayKey(t: Long): Int { val c = Calendar.getInstance().apply { timeInMillis = t }; return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR) }
private fun nextShabbat(): Calendar = nextFriday().apply { add(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }

/** Rules of the advance aliyot scheduler (pure, unit tested). */
object AdvanceAliyot {
    const val DAY = 86_400_000L
    /** Honours that are given out in advance (pledges and verse sales stay on the bimah). */
    val types: List<AliyahType> = AliyahType.values().filter { it != AliyahType.NEDER && it != AliyahType.PESUKIM }

    fun lastAliyah(name: String, aliyot: List<AliyahEntity>, before: Long = Long.MAX_VALUE): Long? =
        aliyot.filter { it.winnerName.trim().equals(name.trim(), true) && it.dateMillis < before && it.aliyahType != AliyahType.NEDER }.maxOfOrNull { it.dateMillis }

    /** True when the member already had an honour within [days] days before this Shabbat. */
    fun tooSoon(name: String, aliyot: List<AliyahEntity>, shabbat: Long, days: Int = 14): Boolean =
        lastAliyah(name, aliyot, shabbat)?.let { shabbat - it < days * DAY } ?: false

    /** Reasons a member should be honoured this Shabbat: yahrzeit in the coming week, birthday / bar mitzvah week, long wait. */
    fun reasons(m: MemberEntity, yahrzeits: List<YahrzeitEntity>, aliyot: List<AliyahEntity>, shabbat: Long): List<String> {
        val out = mutableListOf<String>()
        val weekStart = shabbat - 6 * DAY
        yahrzeits.filter { it.relatedMemberId == m.id || it.relatedMemberName.equals(m.fullName, true) }.forEach { y ->
            YahrzeitTools.upcoming(y, weekStart)?.takeIf { it.daysUntil in 0..7 }?.let { out += Lf("იორცაიტი: {0}", y.deceasedName) }
        }
        if (m.birthDateMillis > 0) {
            val b = Calendar.getInstance().apply { timeInMillis = m.birthDateMillis }
            val s = Calendar.getInstance().apply { timeInMillis = shabbat }
            val bThis = (s.clone() as Calendar).apply { set(Calendar.MONTH, b.get(Calendar.MONTH)); set(Calendar.DAY_OF_MONTH, minOf(b.get(Calendar.DAY_OF_MONTH), getActualMaximum(Calendar.DAY_OF_MONTH))) }
            val diff = (shabbat - bThis.timeInMillis) / DAY
            if (diff in -1..6) out += if (s.get(Calendar.YEAR) - b.get(Calendar.YEAR) == 13) L("ბარ-მიცვას კვირა") else L("დაბადების დღის კვირა")
        }
        val last = lastAliyah(m.fullName, aliyot, shabbat)
        if (last == null || shabbat - last > 56 * DAY) out += L("დიდი ხანია ალია არ ჰქონია")
        return out
    }

    fun message(name: String, parasha: String, honour: String, shul: String) =
        Lf("შალომ {0}! ამ შაბათს ({1}) თქვენ გებოძათ პატივი: {2}. გელოდებით შახარითზე! {3}", name, parasha.ifBlank { L("შაბათი") }, honour, shul)
}

/** Advance aliyot: assign every honour before Shabbat, see who should be honoured, notify and push to the bimah. */
@Composable
fun AdvanceAliyotTool(state: GabbaiUiState, vm: GabbaiViewModel) {
    val s = LocalAppSettings.current
    val ctx = LocalContext.current
    var weekOffset by remember { mutableStateOf(0) }
    val shabbat = remember(weekOffset) { nextShabbat().apply { add(Calendar.DAY_OF_MONTH, 7 * weekOffset) }.timeInMillis }
    val plans = state.registry.filter { it.kind == RegistryKind.ALIYAH_PLAN.name && dayKey(it.dueMillis) == dayKey(shabbat) }
    var parasha by remember(shabbat) { mutableStateOf(plans.firstOrNull()?.extra ?: "") }
    val draft = remember(shabbat) { mutableStateMapOf<AliyahType, String>() }
    val living = state.members.filter { it.status != MemberStatus.DECEASED }
    val people = living.map { it.fullName }
    fun planOf(t: AliyahType) = plans.firstOrNull { it.details == t.name }
    val honoured = living.map { it to AdvanceAliyot.reasons(it, state.yahrzeits, state.aliyot, shabbat) }.filter { it.second.any { r -> r != L("დიდი ხანია ალია არ ჰქონია") } }
    ToolCard7(Icons.Default.EventSeat, L("ალიების წინასწარი დარიგება")) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (weekOffset > 0) weekOffset-- }) { Icon(Icons.Default.ChevronLeft, null) }
            Text(Lf("შაბათი {0}", d7(shabbat)), color = CosmicCelestialGold, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { weekOffset++ }) { Icon(Icons.Default.ChevronRight, null) }
        }
        OutlinedTextField(parasha, { parasha = it }, label = { Text(L("ფარაშა / შემთხვევა")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (honoured.isNotEmpty()) {
            Text(L("ამ შაბათს პატივი უპირველესად ეკუთვნით:"), color = CosmicTextSecondary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            honoured.forEach { (m, r) -> Text("• ${m.fullName} — ${r.joinToString(", ")}", color = CosmicEmeraldSuccess, fontSize = 12.sp) }
        }
        AdvanceAliyot.types.forEach { t ->
            val saved = planOf(t)
            val name = draft[t] ?: saved?.memberName ?: ""
            SuggestField(label = t.titleKa, value = name, suggestions = people, onValueChange = { draft[t] = it })
            if (name.isNotBlank()) {
                val last = AdvanceAliyot.lastAliyah(name, state.aliyot, shabbat)
                val warn = AdvanceAliyot.tooSoon(name, state.aliyot, shabbat)
                Text((if (last == null) L("ალია ჯერ არ ჰქონია") else Lf("ბოლო ალია: {0}", d7(last))) + if (warn) "  ⚠ " + L("ცოტა ხნის წინ ჰქონდა") else "",
                    color = if (warn) CosmicAlertRose else CosmicTextMuted, fontSize = 11.sp)
                if (saved != null && saved.memberName == name) {
                    val phone = living.firstOrNull { it.fullName == name }?.phone.orEmpty()
                    val msg = AdvanceAliyot.message(name, parasha, t.titleKa, s.shulName())
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        AssistChip(onClick = { if (phone.isNotBlank()) Share.whatsapp(ctx, phone, msg) else Share.text(ctx, msg) }, label = { Text("WhatsApp") }, leadingIcon = { Icon(Icons.Default.Chat, null) })
                        if (phone.isNotBlank()) AssistChip(onClick = { Share.sms(ctx, phone, msg) }, label = { Text("SMS") }, leadingIcon = { Icon(Icons.Default.Sms, null) })
                        if (saved.status == RegistryStatus.DONE) AssistChip(onClick = {}, label = { Text(L("ბიმაზეა")) }, leadingIcon = { Icon(Icons.Default.Check, null) })
                    }
                }
            }
        }
        Button(onClick = {
            AdvanceAliyot.types.forEach { t ->
                val name = (draft[t] ?: planOf(t)?.memberName ?: "").trim()
                val saved = planOf(t)
                if (name.isBlank()) { if (saved != null && draft.containsKey(t)) vm.deleteRegistry(saved.id) }
                else vm.saveRegistry((saved ?: RegistryEntity(kind = RegistryKind.ALIYAH_PLAN.name, title = t.keyKa, details = t.name, dueMillis = shabbat))
                    .copy(memberName = name, extra = parasha, phone = living.firstOrNull { it.fullName == name }?.phone.orEmpty()), postToFinance = false)
            }
            draft.clear()
        }, modifier = Modifier.fillMaxWidth().testTag("btn_plan_save")) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text(L("გეგმის შენახვა")) }
        val open = plans.filter { it.status == RegistryStatus.OPEN && it.memberName.isNotBlank() }
        if (open.isNotEmpty()) OutlinedButton(onClick = {
            open.forEach { p ->
                val t = runCatching { AliyahType.valueOf(p.details) }.getOrNull() ?: return@forEach
                vm.addAliyah(p.extra.ifBlank { parasha.ifBlank { L("შაბათი") } }, t, p.memberName, 0.0, TransactionStatus.PLEDGED)
                vm.saveRegistry(p.copy(status = RegistryStatus.DONE), postToFinance = false)
            }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.MenuBook, null); Spacer(Modifier.width(6.dp)); Text(Lf("ბიმაზე გადატანა ({0})", open.size)) }
    }
}

@Composable
private fun ToolCard7(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    CosmicGlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = CosmicCelestialGold); Spacer(Modifier.width(8.dp)); Text(title, fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 16.sp) }
        Spacer(Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
    }
}

/** Printable Shabbat bulletin for the bimah and the notice board. */
@Composable
fun ShabbatBulletinTool(state: GabbaiUiState) {
    val s = LocalAppSettings.current
    val ctx = LocalContext.current
    val shabbat = remember { nextShabbat().timeInMillis }
    val fri = shabbat - AdvanceAliyot.DAY
    val city = CalendarPrefs.city
    val fc = Calendar.getInstance().apply { timeInMillis = fri }
    val sc = Calendar.getInstance().apply { timeInMillis = shabbat }
    val fInfo = remember(city) { JewishCalendar.day(fc.get(Calendar.YEAR), fc.get(Calendar.MONTH) + 1, fc.get(Calendar.DAY_OF_MONTH), city) }
    val sInfo = remember(city) { JewishCalendar.day(sc.get(Calendar.YEAR), sc.get(Calendar.MONTH) + 1, sc.get(Calendar.DAY_OF_MONTH), city) }
    val plans = state.registry.filter { it.kind == RegistryKind.ALIYAH_PLAN.name && dayKey(it.dueMillis) == dayKey(shabbat) }
    var parasha by remember { mutableStateOf(plans.firstOrNull()?.extra ?: "") }
    ToolCard7(Icons.Default.Newspaper, L("შაბათის ბიულეტენი (PDF)")) {
        OutlinedTextField(parasha, { parasha = it }, label = { Text(L("კვირის ფარაშა")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val lines = mutableListOf<String>()
            lines += Lf("სანთლის ანთება: {0}", hm7(fInfo.candleLighting))
            lines += Lf("შაბათის გასვლა: {0}", hm7(sInfo.havdalah))
            lines += Lf("სოფ ზმან კრიათ შემა: {0}", hm7(sInfo.sofShema)); lines += ""
            if (plans.isNotEmpty()) { lines += L("ალიები:"); plans.forEach { p -> lines += "  " + (runCatching { AliyahType.valueOf(p.details).titleKa }.getOrDefault(p.title)) + " — " + p.memberName }; lines += "" }
            val kid = state.registry.filter { it.kind == RegistryKind.KIDDUSH_CAL.name && it.dueMillis in (fri - AdvanceAliyot.DAY)..(shabbat + AdvanceAliyot.DAY) }
            if (kid.isNotEmpty()) { lines += L("კიდუშის სპონსორები:"); kid.forEach { lines += "  ${it.memberName} — ${it.title}" }; lines += "" }
            val yz = YahrzeitTools.within(state.yahrzeits, 7, shabbat - 6 * AdvanceAliyot.DAY)
            if (yz.isNotEmpty()) { lines += L("ამ კვირის იორცაიტები:"); yz.forEach { lines += "  ${it.item.deceasedName} ${it.item.hebrewName} — ${d7(it.dateMillis)}" } }
            val f = PdfMaker.build(ctx, "bulletin-" + d7(shabbat), PdfMaker.Doc(s.shulName(), L("შაბათის ბიულეტენი") + " • " + parasha + " • " + d7(shabbat), lines, L("შაბათ შალომ!")))
            PdfMaker.share(ctx, f, L("შაბათის ბიულეტენი"))
        }, modifier = Modifier.fillMaxWidth().testTag("btn_bulletin")) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(6.dp)); Text(L("PDF-ის შექმნა და გაზიარება")) }
    }
}

object BarMitzvah {
    /** Hebrew-calendar 13th birthday (boys) or 12th (girls) as a Gregorian date. */
    fun date(birth: Long, years: Int = 13): Long {
        val h = android.icu.util.HebrewCalendar(); h.timeInMillis = birth
        h.add(android.icu.util.Calendar.YEAR, years)
        return h.timeInMillis
    }
}

@Composable
fun BarMitzvahTool(state: GabbaiUiState) {
    val withBirth = state.members.filter { it.status != MemberStatus.DECEASED && it.birthDateMillis > 0 }
    var who by remember { mutableStateOf("") }
    var girl by remember { mutableStateOf(false) }
    ToolCard7(Icons.Default.Cake, L("ბარ/ბათ-მიცვას კალკულატორი")) {
        SuggestField(label = L("წევრი (დაბადების თარიღით)"), value = who, suggestions = withBirth.map { it.fullName }, onValueChange = { who = it })
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(girl, { girl = it }); Spacer(Modifier.width(6.dp)); Text(L("ბათ-მიცვა (12 წელი)"), color = CosmicTextSecondary) }
        withBirth.firstOrNull { it.fullName == who }?.let { m ->
            val t = BarMitzvah.date(m.birthDateMillis, if (girl) 12 else 13)
            Text(Lf("თარიღი: {0} • {1}", d7(t), run { val c = Calendar.getInstance().apply { timeInMillis = t }; JewishCalendar.hebrewDateHe(JewishCalendar.toHebrew(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))) }),
                color = CosmicCelestialGold, fontWeight = FontWeight.Bold)
            Text(L("გეგმა: თეფილინის შეკვეთა 6 თვით ადრე, ფარაშისა და ჰაფტარას სწავლა, დრაშა, პირველი ალია. დეტალური ნაბიჯებისთვის გამოიყენეთ ჟურნალი „ბარ-მიცვას გეგმა“."), color = CosmicTextMuted, fontSize = 12.sp)
        }
        val soon = withBirth.mapNotNull { m -> BarMitzvah.date(m.birthDateMillis).takeIf { it in System.currentTimeMillis()..(System.currentTimeMillis() + 365 * AdvanceAliyot.DAY) }?.let { m to it } }
        if (soon.isNotEmpty()) { Text(L("მომავალი 12 თვის ბარ-მიცვები:"), color = CosmicTextSecondary, fontSize = 12.sp); soon.sortedBy { it.second }.forEach { Text("• ${it.first.fullName} — ${d7(it.second)}", color = CosmicTextPrimary, fontSize = 12.sp) } }
    }
}

/** Group WhatsApp / SMS with filters by status, debt and role. */
@Composable
fun GroupMessageTool(state: GabbaiUiState) {
    val ctx = LocalContext.current
    val s = LocalAppSettings.current
    val filters = listOf(L("ყველა აქტიური"), L("დავალიანების მქონე"), L("ქოჰენები"), L("ლევიები"), L("პასიური წევრები"))
    var f by remember { mutableStateOf(filters[0]) }
    var text by remember { mutableStateOf("") }
    val list = state.members.filter { it.phone.isNotBlank() && it.status != MemberStatus.DECEASED }.filter { m ->
        when (filters.indexOf(f)) { 1 -> m.outstandingDebt > 0 || !m.duesPaid; 2 -> m.tribalStatus.contains("כהן"); 3 -> m.tribalStatus.contains("לוי"); 4 -> m.status == MemberStatus.PASSIVE; else -> m.status == MemberStatus.ACTIVE }
    }
    ToolCard7(Icons.Default.Campaign, L("ჯგუფური WhatsApp / SMS")) {
        AppDropdown(label = L("ვის გაეგზავნოს"), value = f, options = filters, optionLabel = { it }, onSelected = { f = it }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(text, { text = it }, label = { Text(L("შეტყობინება")) }, modifier = Modifier.fillMaxWidth())
        Text(Lf("მიმღები: {0} წევრი", list.size), color = CosmicTextMuted, fontSize = 12.sp)
        val body = text.ifBlank { s.shulName() }
        Button(enabled = list.isNotEmpty(), onClick = {
            val nums = list.joinToString(";") { it.phone.filter { c -> c.isDigit() || c == '+' } }
            runCatching { ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$nums")).putExtra("sms_body", body).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                .onFailure { Share.text(ctx, body) }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Sms, null); Spacer(Modifier.width(6.dp)); Text(L("SMS ყველას ერთად")) }
        list.take(30).forEach { m ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m.fullName, color = CosmicTextPrimary, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { Share.whatsapp(ctx, m.phone, body) }) { Text("WhatsApp") }
            }
        }
    }
}

/** Live countdown to sunrise (vatikin) and a spoken reminder of today's times. */
@Composable
fun NetzCountdownTool() {
    val ctx = LocalContext.current
    val city = CalendarPrefs.city
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(1000); now = System.currentTimeMillis() } }
    val today = Calendar.getInstance()
    val tInfo = remember(city, today.get(Calendar.DAY_OF_YEAR)) { JewishCalendar.day(today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1, today.get(Calendar.DAY_OF_MONTH), city) }
    val tm = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
    val mInfo = remember(city, tm.get(Calendar.DAY_OF_YEAR)) { JewishCalendar.day(tm.get(Calendar.YEAR), tm.get(Calendar.MONTH) + 1, tm.get(Calendar.DAY_OF_MONTH), city) }
    val netz = tInfo.sunrise?.takeIf { it > now } ?: mInfo.sunrise
    var tts by remember { mutableStateOf<android.speech.tts.TextToSpeech?>(null) }
    DisposableEffect(Unit) { onDispose { tts?.shutdown() } }
    ToolCard7(Icons.Default.WbTwilight, L("ნეცის (ვათიკინის) წამზომი")) {
        if (netz != null) {
            val left = ((netz - now) / 1000).coerceAtLeast(0)
            Text(String.format(Locale.US, "%02d:%02d:%02d", left / 3600, (left / 60) % 60, left % 60), color = CosmicCelestialGold, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text(Lf("ნეცი: {0} • ალოთ ჰაშახარ: {1}", hm7(netz), hm7(if (netz == tInfo.sunrise) tInfo.alot else mInfo.alot)), color = CosmicTextSecondary, fontSize = 13.sp)
        } else Text(L("ამ ქალაქისთვის მზის ამოსვლა ვერ გამოითვალა"), color = CosmicTextMuted)
        OutlinedButton(onClick = {
            val say = Lf("დღეს მზე ამოდის {0}, ჩადის {1}. მინხა {2}-მდე.", hm7(tInfo.sunrise), hm7(tInfo.sunset), hm7(tInfo.sunset)) +
                (tInfo.candleLighting?.let { " " + Lf("სანთლის ანთება {0}.", hm7(it)) } ?: "")
            tts?.stop()
            if (tts == null) tts = android.speech.tts.TextToSpeech(ctx) { st -> if (st == android.speech.tts.TextToSpeech.SUCCESS) tts?.speak(say, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "z") }
            else tts?.speak(say, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "z")
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.VolumeUp, null); Spacer(Modifier.width(6.dp)); Text(L("დღის დროების ხმოვანი შეხსენება")) }
        TextButton(onClick = { tts?.stop() }) { Text(L("გაჩერება")) }
    }
}

object Dedication {
    val kinds = listOf("לעילוי נשמת", "לרפואה שלמה", "להצלחת", "לזכר")
    fun text(kind: String, name: String, parent: String, sonOf: Boolean, by: String): String = buildString {
        append(kind).append(' ').append(name.trim())
        if (parent.isNotBlank()) append(if (sonOf) " בן " else " בת ").append(parent.trim())
        if (kind == "לעילוי נשמת" || kind == "לזכר") append(" ז״ל")
        append('\n').append(when (kind) { "לעילוי נשמת" -> L("ნეშამის ამაღლებისთვის"); "לרפואה שלמה" -> L("სრული განკურნებისთვის"); "להצלחת" -> L("წარმატებისთვის"); else -> L("ხსოვნისთვის") })
        if (by.isNotBlank()) append('\n').append(Lf("შემომწირველი: {0}", by.trim()))
    }
}

@Composable
fun DedicationTool() {
    val ctx = LocalContext.current
    var kind by remember { mutableStateOf(Dedication.kinds[0]) }
    var name by remember { mutableStateOf("") }
    var parent by remember { mutableStateOf("") }
    var son by remember { mutableStateOf(true) }
    var by by remember { mutableStateOf("") }
    val txt = Dedication.text(kind, name, parent, son, by)
    ToolCard7(Icons.Default.Draw, L("მიძღვნის დაფის ტექსტი")) {
        AppDropdown(label = L("ტიპი"), value = kind, options = Dedication.kinds, optionLabel = { it }, onSelected = { kind = it }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(name, { name = it }, label = { Text(L("ებრაული სახელი")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(parent, { parent = it }, label = { Text(L("მამის / დედის სახელი")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(son, { son = it }); Spacer(Modifier.width(6.dp)); Text(if (son) "בן" else "בת", color = CosmicTextSecondary) }
        OutlinedTextField(by, { by = it }, label = { Text(L("შემომწირველი")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text(txt, color = CosmicCelestialGold, fontWeight = FontWeight.SemiBold)
        Button(onClick = { Share.text(ctx, txt) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text(L("გაზიარება")) }
    }
}

@Composable
fun KashrutGuideTool() {
    val items = listOf(
        L("კიდუში: ღვინო/ყურძნის წვენი მინიმუმ რევიით (≈86 მლ), ჭიქა სავსე. დილით — ბორე პრი ჰაგაფენ."),
        L("ხალა: ორი მთლიანი პური (ლეხემ მიშნე), გადაფარებული ხელების განბანვამდე."),
        L("ხორცი და რძე: ხორცის შემდეგ ლოდინი ჩვეულებისამებრ (1/3/6 საათი), ცალკე ჭურჭელი."),
        L("ჰეხშერი: ყველა პროდუქტზე შეამოწმეთ სანდო კაშრუთის ნიშანი; ღვინო — მხოლოდ კაშერი."),
        L("შაბათს: ცხელი საკვები პლატაზე/ბლეხზე წინასწარ, ცივი წყალი ქვაბიდან არ დაემატოს."),
        L("ჰავდალა: ღვინო, ბესამიმი, მრავალპატრუქიანი სანთელი.")
    )
    ToolCard7(Icons.Default.WineBar, L("კიდუშისა და ქაშრუთის გზამკვლევი")) {
        items.forEach { Text("• $it", color = CosmicTextSecondary, fontSize = 13.sp) }
        Text(L("საეჭვო შემთხვევაში მიმართეთ რავს."), color = CosmicTextMuted, fontSize = 11.sp)
    }
}

object FinanceChart {
    /** Income and expense per month for the last [months] months in one currency, oldest first. */
    fun monthly(txs: List<TransactionEntity>, currency: String, months: Int = 6, now: Long = System.currentTimeMillis()): List<Triple<String, Double, Double>> {
        val c = Calendar.getInstance().apply { timeInMillis = now; set(Calendar.DAY_OF_MONTH, 1) }
        return (months - 1 downTo 0).map { back ->
            val m = (c.clone() as Calendar).apply { add(Calendar.MONTH, -back) }
            val y = m.get(Calendar.YEAR); val mo = m.get(Calendar.MONTH)
            val inMonth = txs.filter { it.currency == currency && it.status == TransactionStatus.PAID && Calendar.getInstance().apply { timeInMillis = it.dateMillis }.let { d -> d.get(Calendar.YEAR) == y && d.get(Calendar.MONTH) == mo } }
            Triple(String.format(Locale.US, "%02d.%02d", mo + 1, y % 100), inMonth.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }, inMonth.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount })
        }
    }
}

@Composable
fun FinanceChartTool(state: GabbaiUiState) {
    val s = LocalAppSettings.current
    val data = remember(state.transactions, s.currency) { FinanceChart.monthly(state.transactions, s.currency) }
    val max = (data.maxOfOrNull { maxOf(it.second, it.third) } ?: 0.0).coerceAtLeast(1.0)
    val inc = CosmicEmeraldSuccess; val exp = CosmicAlertRose; val grid = CosmicBorderGlow
    ToolCard7(Icons.Default.BarChart, L("ფინანსური ანალიტიკა — 6 თვე")) {
        Canvas(Modifier.fillMaxWidth().height(160.dp)) {
            val slot = size.width / data.size
            drawLine(grid, Offset(0f, size.height), Offset(size.width, size.height), 2f)
            data.forEachIndexed { i, d ->
                val bw = slot * 0.3f
                val x = i * slot + slot * 0.15f
                val h1 = (d.second / max * size.height * 0.95).toFloat(); val h2 = (d.third / max * size.height * 0.95).toFloat()
                drawRoundRect(inc, Offset(x, size.height - h1), Size(bw, h1), androidx.compose.ui.geometry.CornerRadius(6f))
                drawRoundRect(exp, Offset(x + bw + 4f, size.height - h2), Size(bw, h2), androidx.compose.ui.geometry.CornerRadius(6f))
            }
        }
        Row { data.forEach { Text(it.first, fontSize = 10.sp, color = CosmicTextMuted, modifier = Modifier.weight(1f)) } }
        Text("■ " + L("შემოსავალი") + "   ", color = inc, fontSize = 12.sp)
        Text("■ " + L("გასავალი"), color = exp, fontSize = 12.sp)
        data.lastOrNull()?.let { Text(Lf("ამ თვეში: +{0} / −{1}", money(it.second, s.currency), money(it.third, s.currency)), color = CosmicTextPrimary, fontSize = 13.sp) }
    }
}

object CertificateCode {
    /** Short tamper-evident code printed on certificates; recomputed from the same data to verify. */
    fun of(member: String, year: Int, total: Double, shul: String): String {
        val raw = "$shul|${member.trim().lowercase()}|$year|${"%.2f".format(Locale.US, total)}"
        return java.security.MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).take(5).joinToString("") { "%02X".format(it) }
    }
}

@Composable
fun CertificateQrTool(state: GabbaiUiState) {
    val s = LocalAppSettings.current
    val ctx = LocalContext.current
    var who by remember { mutableStateOf("") }
    var check by remember { mutableStateOf("") }
    val year = Calendar.getInstance().get(Calendar.YEAR)
    val total = state.transactions.filter { it.memberName.equals(who.trim(), true) && it.type == TransactionType.INCOME && it.status == TransactionStatus.PAID &&
        Calendar.getInstance().apply { timeInMillis = it.dateMillis }.get(Calendar.YEAR) == year }.sumOf { it.amount }
    val code = CertificateCode.of(who, year, total, s.shulName())
    ToolCard7(Icons.Default.Verified, L("ოფიციალური QR დამოწმება")) {
        SuggestField(label = L("წევრი"), value = who, suggestions = state.members.map { it.fullName }, onValueChange = { who = it })
        if (who.isNotBlank()) {
            Text(Lf("{0} წელი: {1} • კოდი {2}", year, money(total, s.currency), code), color = CosmicCelestialGold, fontWeight = FontWeight.Bold)
            Button(onClick = {
                val payload = "GABBAI-CERT:${s.shulName()}|$who|$year|$total|$code"
                Share.image(ctx, MemberQr.bitmap(payload), "cert-$code", Lf("{0} — წლიური ცნობის დამოწმების კოდი: {1}", who, code))
            }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.QrCode, null); Spacer(Modifier.width(6.dp)); Text(L("QR-ის გაზიარება")) }
        }
        OutlinedTextField(check, { check = it.uppercase().trim() }, label = { Text(L("შესამოწმებელი კოდი")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (check.isNotBlank() && who.isNotBlank()) Text(if (check == code) "✔ " + L("ცნობა ნამდვილია") else "✖ " + L("კოდი არ ემთხვევა"),
            color = if (check == code) CosmicEmeraldSuccess else CosmicAlertRose, fontWeight = FontWeight.Bold)
    }
}

/** Photos of receipts attached to expense records (stored privately in app storage). */
@Composable
fun ReceiptPhotosTool(state: GabbaiUiState) {
    val ctx = LocalContext.current
    val dir = remember { java.io.File(ctx.filesDir, "receipts").apply { mkdirs() } }
    var version by remember { mutableStateOf(0) }
    var target by remember { mutableStateOf<TransactionEntity?>(null) }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        val t = target
        if (bmp != null && t != null) { java.io.File(dir, "tx-${t.id}.jpg").outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, it) }; version++ }
    }
    val expenses = state.transactions.filter { it.type == TransactionType.EXPENSE }.sortedByDescending { it.dateMillis }.take(15)
    ToolCard7(Icons.Default.Receipt, L("ქვითრების ფოტოები გასავალზე")) {
        if (expenses.isEmpty()) Text(L("ჩანაწერი არ არის"), color = CosmicTextMuted)
        expenses.forEach { t ->
            val f = java.io.File(dir, "tx-${t.id}.jpg")
            val img = remember(version, t.id) { if (f.exists()) android.graphics.BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (img != null) Image(img, null, Modifier.size(44.dp))
                Spacer(Modifier.width(6.dp))
                Text("${d7(t.dateMillis)} • ${t.title} • ${money(t.amount, t.currency)}", color = CosmicTextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { target = t; runCatching { cam.launch(null) } }) { Icon(Icons.Default.PhotoCamera, L("ფოტო")) }
                if (img != null) IconButton(onClick = {
                    val bmp = android.graphics.BitmapFactory.decodeFile(f.path)
                    if (bmp != null) Share.image(ctx, bmp, "receipt-${t.id}", t.title)
                }) { Icon(Icons.Default.Share, null) }
            }
        }
    }
}
