package com.example.data.service

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Picks the newest usable Gemini models from Google's live list (pure logic, unit-tested). */
object GeminiModelPicker {
    private val num = Regex("""gemini-(\d+(?:\.\d+)?)""")
    private fun version(n: String): Double = num.find(n)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
    private fun stable(n: String) = !n.contains("preview") && !n.contains("exp")
    private val textBan = listOf("tts", "image", "banana", "embedding", "transcribe", "omni", "live", "audio", "customtools", "robotics", "computer", "veo", "imagen", "aqa", "gemma")

    /** names: e.g. "models/gemini-3.5-flash". Returns best-first list of text models. */
    fun textModels(names: List<String>): List<String> = names.map { it.removePrefix("models/") }
        .filter { it.startsWith("gemini-") && it.contains("flash") && textBan.none { b -> it.contains(b) } && !it.contains("latest") }
        .sortedWith(compareByDescending<String> { version(it) }.thenByDescending { stable(it) }.thenBy { if (it.contains("lite")) 1 else 0 })

    fun ttsModels(names: List<String>): List<String> = names.map { it.removePrefix("models/") }
        .filter { it.startsWith("gemini-") && it.contains("tts") }
        .sortedWith(compareByDescending<String> { version(it) }.thenByDescending { stable(it) }.thenBy { if (it.contains("lite")) 1 else 0 }.thenBy { if (it.contains("pro")) 1 else 0 })

    /** Strips a WAV header if present and returns (pcm16 mono bytes, sampleRate). */
    fun pcm(bytes: ByteArray, defaultRate: Int = 24000): Pair<ByteArray, Int> {
        if (bytes.size < 44 || String(bytes, 0, 4, Charsets.US_ASCII) != "RIFF") return bytes to defaultRate
        fun le32(i: Int) = (bytes[i].toInt() and 255) or ((bytes[i + 1].toInt() and 255) shl 8) or ((bytes[i + 2].toInt() and 255) shl 16) or ((bytes[i + 3].toInt() and 255) shl 24)
        var rate = defaultRate
        var p = 12
        while (p + 8 <= bytes.size) {
            val id = String(bytes, p, 4, Charsets.US_ASCII); val len = le32(p + 4)
            if (id == "fmt ") rate = le32(p + 12)
            if (id == "data") return bytes.copyOfRange(p + 8, minOf(bytes.size, p + 8 + len)) to rate
            p += 8 + len + (len and 1)
        }
        return bytes.copyOfRange(44, bytes.size) to rate
    }

    /** Nearest-sample resample of 16-bit mono PCM to 24 kHz. */
    fun to24k(pcm: ByteArray, rate: Int): ByteArray {
        if (rate == 24000 || rate <= 0) return pcm
        val n = pcm.size / 2; val m = (n.toLong() * 24000 / rate).toInt()
        val out = ByteArray(m * 2)
        for (i in 0 until m) { val s = (i.toLong() * rate / 24000).toInt().coerceAtMost(n - 1); out[2 * i] = pcm[2 * s]; out[2 * i + 1] = pcm[2 * s + 1] }
        return out
    }
}

/**
 * The user's own Google AI Studio key, stored only on this phone.
 * Models are discovered from Google's live list, so new Gemini versions are used automatically;
 * if one model is retired/busy the next one is tried.
 */
object GeminiDirect {
    private const val PREFS = "gabbai_settings"
    private const val KEY = "user_gemini_key"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/"
    private val FALLBACK_TEXT = listOf("gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-flash-latest")
    private val FALLBACK_TTS = listOf("gemini-3.1-flash-tts-preview", "gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts")

    @Volatile private var cached: String? = null
    @Volatile private var textList: List<String> = emptyList()
    @Volatile private var ttsList: List<String> = emptyList()
    @Volatile private var listedAt = 0L
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS).readTimeout(180, TimeUnit.SECONDS).build()

    fun init(context: Context) {
        cached = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "")?.trim().orEmpty()
    }
    fun key(): String = cached.orEmpty()
    fun hasKey(): Boolean = key().isNotBlank()
    fun save(context: Context, value: String) {
        val v = value.trim()
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, v).apply()
        cached = v; listedAt = 0L
    }

    private class HttpError(val code: Int) : IllegalStateException("Gemini $code")

    private fun refresh(key: String, force: Boolean = false) {
        if (!force && listedAt != 0L && System.currentTimeMillis() - listedAt < 6 * 3600_000L) return
        runCatching {
            val names = mutableListOf<String>()
            var page = ""
            repeat(5) {
                val req = Request.Builder().url(BASE + "models?pageSize=1000" + (if (page.isNotEmpty()) "&pageToken=$page" else "")).header("x-goog-api-key", key).get().build()
                client.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) throw HttpError(r.code)
                    val j = JSONObject(r.body?.string().orEmpty())
                    val arr = j.optJSONArray("models") ?: JSONArray()
                    for (i in 0 until arr.length()) {
                        val m = arr.optJSONObject(i) ?: continue
                        val methods = m.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                        if (methods.contains("generateContent")) names += m.optString("name")
                    }
                    page = j.optString("nextPageToken")
                }
                if (page.isEmpty()) return@repeat
            }
            textList = GeminiModelPicker.textModels(names).take(6)
            ttsList = GeminiModelPicker.ttsModels(names).take(5)
            listedAt = System.currentTimeMillis()
        }
    }

    private fun post(model: String, body: JSONObject, key: String): JSONObject {
        val req = Request.Builder().url(BASE + "models/" + model + ":generateContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
        client.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw HttpError(r.code)
            return JSONObject(text)
        }
    }

    /** Tries models best-first; skips retired (404), busy (429/5xx) or unsupported (400) ones. */
    private fun <T> withModels(key: String, tts: Boolean, run: (String) -> T): T {
        refresh(key)
        val list = ((if (tts) ttsList else textList) + (if (tts) FALLBACK_TTS else FALLBACK_TEXT)).distinct()
        var last: Throwable = IllegalStateException("no model")
        for (m in list) {
            try { return run(m) } catch (e: HttpError) {
                last = e
                if (e.code == 401 || e.code == 403) throw e // bad key: no point trying others
                if (e.code == 404) listedAt = 0L
            } catch (e: Exception) { last = e }
        }
        throw last
    }

    private fun parts(json: JSONObject): JSONArray? =
        json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")

    private fun textOf(p: JSONArray) = buildString {
        for (i in 0 until p.length()) { val o = p.optJSONObject(i) ?: continue; if (!o.optBoolean("thought")) append(o.optString("text")) }
    }.trim()

    /** Text answer with the user's key; throws on any failure. */
    fun ask(system: String, user: String): String {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", user)))))
        return withModels(key(), false) { m ->
            val out = parts(post(m, body, key()))?.let { textOf(it) }.orEmpty()
            if (out.isEmpty()) throw IllegalStateException("empty"); out
        }
    }

    /** 24 kHz mono 16-bit PCM for one piece of text; throws on any failure. */
    fun speech(text: String): ByteArray {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Read aloud clearly in natural Georgian: $text")))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", "Charon")))))
        return withModels(key(), true) { m ->
            val p = parts(post(m, body, key())) ?: throw IllegalStateException("empty")
            var audio: ByteArray? = null
            for (i in 0 until p.length()) {
                val inline = p.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                val data = inline.optString("data")
                if (data.isEmpty()) continue
                val mime = inline.optString("mimeType")
                val rate = Regex("""rate=(\d+)""").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                val (pcm, r) = GeminiModelPicker.pcm(android.util.Base64.decode(data, android.util.Base64.DEFAULT), rate)
                audio = GeminiModelPicker.to24k(pcm, r); break
            }
            audio ?: throw IllegalStateException("no audio")
        }
    }

    /** Quick check used by the Settings "Check" button. */
    fun test(candidate: String): Boolean = runCatching {
        val k = candidate.trim()
        refresh(k, force = true)
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Say OK")))))
        withModels(k, false) { m -> parts(post(m, body, k)) ?: throw IllegalStateException("empty") }
        true
    }.getOrDefault(false)
}
