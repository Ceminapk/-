package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.calendar.*
import com.example.ui.components.*
import com.example.ui.settings.*
import com.example.ui.share.Share
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiUiState
import java.text.SimpleDateFormat
import java.util.*

private fun hm2(t: Long?) = if (t == null) "—" else SimpleDateFormat("HH:mm", Locale.US).format(Date(t))
private fun d2(t: Long) = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(t))

/** Upcoming Friday (today if Friday) and the Saturday after it. */
fun nextFriday(now: Long = System.currentTimeMillis()): Calendar = Calendar.getInstance().apply {
    timeInMillis = now
    while (get(Calendar.DAY_OF_WEEK) != Calendar.FRIDAY) add(Calendar.DAY_OF_MONTH, 1)
}

object ShabbatMessage {
    fun text(candle: Long?, havdalah: Long?, mincha: Long?, parasha: String, blessing: String, shul: String): String = buildString {
        append(L("შაბათ შალომ! 🕯")).append('\n')
        if (parasha.isNotBlank()) append(Lf("კვირის ფარაშა: {0}", parasha)).append('\n')
        append(Lf("სანთლის ანთება: {0}", hm2(candle))).append('\n')
        if (mincha != null) append(Lf("მინხა: {0}", hm2(mincha))).append('\n')
        append(Lf("შაბათის გასვლა: {0}", hm2(havdalah))).append('\n')
        if (blessing.isNotBlank()) append('\n').append(blessing).append('\n')
        append("— ").append(shul)
    }
}

@Composable
fun ShabbatShalomTool(state: GabbaiUiState) {
    val s = LocalAppSettings.current
    val ctx = LocalContext.current
    val city = CalendarPrefs.city
    val fri = remember { nextFriday() }
    val friInfo = remember(city) { JewishCalendar.day(fri.get(Calendar.YEAR), fri.get(Calendar.MONTH) + 1, fri.get(Calendar.DAY_OF_MONTH), city) }
    val sat = remember { (fri.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) } }
    val satInfo = remember(city) { JewishCalendar.day(sat.get(Calendar.YEAR), sat.get(Calendar.MONTH) + 1, sat.get(Calendar.DAY_OF_MONTH), city) }
    var parasha by remember { mutableStateOf("") }
    var blessing by remember { mutableStateOf(L("გისურვებთ მშვიდობიან და კურთხეულ შაბათს თქვენს ოჯახს!")) }
    val mincha = friInfo.candleLighting?.let { it - 10 * 60_000 }
    val text = ShabbatMessage.text(friInfo.candleLighting, satInfo.havdalah, mincha, parasha, blessing, s.shulName())
    val phones = state.members.filter { it.status != MemberStatus.DECEASED && it.phone.isNotBlank() }
    ToolCard(Icons.Default.Celebration, L("„შაბათ შალომ“ მაცნე")) {
        Text(Lf("პარასკევი {0}: სანთელი {1} • გასვლა {2}", d2(fri.timeInMillis), hm2(friInfo.candleLighting), hm2(satInfo.havdalah)), color = CosmicCelestialGold, fontWeight = FontWeight.SemiBold)
        Text(L("საუკეთესოა გაგზავნა სანთლის ანთებამდე 2 საათით ადრე."), color = CosmicTextMuted, fontSize = 12.sp)
        OutlinedTextField(parasha, { parasha = it }, label = { Text(L("კვირის ფარაშა")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(blessing, { blessing = it }, label = { Text(L("გაბაის დალოცვა")) }, modifier = Modifier.fillMaxWidth())
        Text(text, color = CosmicTextSecondary, fontSize = 13.sp)
        Button(onClick = { Share.text(ctx, text) }, modifier = Modifier.fillMaxWidth().testTag("btn_shabbat_share")) {
            Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text(L("ყველასთვის გაზიარება (WhatsApp ჯგუფი)"))
        }
        Text(Lf("ტელეფონით: {0} წევრი", phones.size), color = CosmicTextMuted, fontSize = 12.sp)
    }
}

@Composable
fun HebrewNameTool(state: GabbaiUiState) {
    var name by remember { mutableStateOf("") }
    var parent by remember { mutableStateOf("") }
    var daughter by remember { mutableStateOf(false) }
    val names = state.members.filter { it.status != MemberStatus.DECEASED }.map { it.fullName }
    ToolCard(Icons.Default.Translate, L("ებრაული სახელების ლექსიკონი")) {
        SuggestField(label = L("სახელი"), value = name, suggestions = names, onValueChange = { name = it })
        OutlinedTextField(parent, { parent = it }, label = { Text(L("დედის / მამის სახელი")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row { Checkbox(daughter, { daughter = it }); Text(L("ქალია (בת)"), color = CosmicTextSecondary, modifier = Modifier.padding(top = 12.dp)) }
        if (name.isNotBlank()) {
            val he = HebrewNames.of(name)
            Text(HebrewNames.callName(name, parent, daughter), color = CosmicCelestialGold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (he == null) Text(L("ეს სახელი ლექსიკონში არ არის — ებრაული სახელი წევრის ბარათში ჩაწერეთ."), color = CosmicTextMuted, fontSize = 12.sp)
        }
    }
}

/** Member's whole history: aliyot, money, journals, yahrzeits. */
@Composable
fun MemberTimelineTool(state: GabbaiUiState) {
    val living = state.members
    var who by remember { mutableStateOf("") }
    ToolCard(Icons.Default.Timeline, L("წევრის სიცოცხლის ხაზი")) {
        SuggestField(label = L("წევრი"), value = who, suggestions = living.map { it.fullName }, onValueChange = { who = it })
        if (who.isNotBlank()) {
            val ev = MemberTimeline.build(who, state)
            if (ev.isEmpty()) Text(L("ჩანაწერი არ არის"), color = CosmicTextMuted)
            Text(Lf("სულ: {0} მოვლენა", ev.size), color = CosmicTextSecondary, fontSize = 12.sp)
            ev.take(60).forEach { e ->
                Row { Text(d2(e.date), color = CosmicTextMuted, fontSize = 12.sp, modifier = Modifier.width(84.dp)); Text(nb(e.text), color = CosmicTextPrimary, fontSize = 13.sp) }
            }
        }
    }
}

data class TimelineEvent(val date: Long, val text: String)

object MemberTimeline {
    fun build(name: String, st: GabbaiUiState): List<TimelineEvent> {
        val n = name.trim()
        val out = mutableListOf<TimelineEvent>()
        st.aliyot.filter { it.winnerName.equals(n, true) }.forEach { out += TimelineEvent(it.dateMillis, "📜 " + it.parashaName + " — " + money(it.amount, it.currency)) }
        st.transactions.filter { it.memberName.equals(n, true) }.forEach { out += TimelineEvent(it.dateMillis, (if (it.type == TransactionType.INCOME) "💰 " else "↘ ") + it.title + " — " + money(it.amount, it.currency)) }
        st.registry.filter { it.memberName.equals(n, true) }.forEach { r ->
            val k = runCatching { RegistryKind.valueOf(r.kind).title }.getOrDefault(r.kind)
            out += TimelineEvent(r.dateMillis, "📒 $k: ${r.title}")
        }
        return out.sortedByDescending { it.date }
    }
}

@Composable
private fun ToolCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    CosmicGlassCard(Modifier.fillMaxWidth()) {
        Row { Icon(icon, null, tint = CosmicCelestialGold); Spacer(Modifier.width(8.dp)); Text(title, fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 16.sp) }
        Spacer(Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
    }
}
