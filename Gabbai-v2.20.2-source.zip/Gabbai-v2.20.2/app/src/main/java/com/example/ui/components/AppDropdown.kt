package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.settings.Currencies
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.settings.nb
import com.example.ui.theme.LocalGabbaiPalette

/* ------------------------------------------------------------------------------------------
 * All pickers open a separate full-width dialog with a search box and a bounded list.
 * (The old in-place menu put a lazy list inside a menu that measures intrinsic sizes,
 * which crashed the app as soon as a dropdown was tapped.)
 * ---------------------------------------------------------------------------------------- */

/** Soft, airy field that shows the current value (with its icon) and opens a picker. */
@Composable
fun DropdownFace(
    label: String,
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    placeholder: Boolean = false,
    trailingIcon: ImageVector = Icons.Default.KeyboardArrowDown,
    compact: Boolean = false,
    leadingIcon: ImageVector? = null,
    leadingGlyph: String? = null
) {
    val palette = LocalGabbaiPalette.current
    val primary = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(if (compact) 14.dp else 16.dp)
    Column(modifier) {
        if (label.isNotEmpty()) {
            Text(
                text = nb(label),
                color = palette.secondaryText,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 4.dp, bottom = 5.dp)
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .shadow(2.dp, shape, ambientColor = primary.copy(alpha = 0.08f), spotColor = primary.copy(alpha = 0.10f))
                .clip(shape)
                .background(Brush.verticalGradient(listOf(palette.glass, palette.surface)))
                .border(1.dp, palette.border.copy(alpha = 0.45f), shape)
                .clickable(onClick = onClick)
                .heightIn(min = if (compact) 46.dp else 52.dp)
                .padding(start = 12.dp, end = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (leadingGlyph != null || leadingIcon != null) {
                OptionBadge(leadingIcon, leadingGlyph, primary, if (compact) 26.dp else 30.dp)
                Spacer(Modifier.width(10.dp))
            }
            Text(
                text = nb(text),
                color = if (placeholder) palette.mutedText else palette.text,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            Icon(trailingIcon, contentDescription = label, tint = primary.copy(alpha = 0.75f), modifier = Modifier.size(22.dp))
        }
    }
}

/** Small soft circle with an icon or a short glyph (currency symbol). */
@Composable
fun OptionBadge(icon: ImageVector?, glyph: String?, tint: Color, size: androidx.compose.ui.unit.Dp = 30.dp) {
    Box(
        Modifier.size(size).clip(androidx.compose.foundation.shape.CircleShape).background(tint.copy(alpha = 0.10f)),
        contentAlignment = Alignment.Center
    ) {
        if (glyph != null) Text(glyph, color = tint, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.5f).sp, maxLines = 1)
        else if (icon != null) Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.58f))
    }
}

private fun glyphOf(item: Any?): String? = (item as? com.example.ui.settings.CurrencyInfo)?.symbol

/** A row shown at the top of the picker list (e.g. "use typed text", "add to members"). */
data class PickerAction(val label: String, val icon: ImageVector, val onClick: (query: String) -> Unit)

/** Searchable picker dialog. Every list in the app goes through here, so every list is filterable. */
@Composable
fun <T> SearchPickerDialog(
    title: String,
    options: List<T>,
    optionLabel: (T) -> String,
    onPick: (T) -> Unit,
    onDismiss: () -> Unit,
    selected: T? = null,
    initialQuery: String = "",
    actions: (query: String) -> List<PickerAction> = { emptyList() },
    optionIcon: ((T) -> ImageVector)? = null
) {
    val palette = LocalGabbaiPalette.current
    val primary = MaterialTheme.colorScheme.primary
    val appear = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, androidx.compose.animation.core.tween(260)) }
    var query by remember { mutableStateOf(initialQuery) }
    val focus = remember { FocusRequester() }
    val visible = remember(query, options) {
        val q = query.trim()
        if (q.isEmpty()) options else options.filter { optionLabel(it).contains(q, ignoreCase = true) }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(26.dp),
            color = palette.surface,
            shadowElevation = 24.dp,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.35f), primary.copy(alpha = 0.7f)))),
            modifier = Modifier.fillMaxWidth(0.94f).heightIn(max = 600.dp).testTag("picker_dialog")
                .graphicsLayer { alpha = appear.value; val sc = 0.94f + 0.06f * appear.value; scaleX = sc; scaleY = sc }
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        nb(title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        color = palette.text, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, L("დახურვა"), tint = palette.secondaryText) }
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(L("ძიება ან აკრეფა…"), maxLines = 1) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = primary) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Clear, null) } },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus).testTag("picker_search")
                )
                Spacer(Modifier.height(10.dp))
                val extra = actions(query.trim())
                LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    itemsIndexed(extra) { _, a ->
                        PickerRow(text = a.label, icon = a.icon, highlighted = true, onClick = { a.onClick(query.trim()) })
                    }
                    itemsIndexed(visible) { _, item ->
                        val lbl = optionLabel(item)
                        PickerRow(
                            text = lbl,
                            icon = optionIcon?.invoke(item) ?: OptionIcons.of(item, lbl),
                            glyph = glyphOf(item),
                            highlighted = item == selected,
                            onClick = { onPick(item) }
                        )
                    }
                    if (visible.isEmpty() && extra.isEmpty()) {
                        itemsIndexed(listOf(0)) { _, _ ->
                            Text(L("ვერაფერი მოიძებნა"), color = palette.mutedText, modifier = Modifier.padding(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PickerRow(text: String, icon: ImageVector?, highlighted: Boolean, onClick: () -> Unit, glyph: String? = null) {
    val palette = LocalGabbaiPalette.current
    val primary = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (highlighted) primary.copy(alpha = 0.16f) else palette.glass)
            .border(1.dp, if (highlighted) primary.copy(alpha = 0.7f) else palette.border.copy(alpha = 0.35f), shape)
            .clickable(onClick = onClick)
            .heightIn(min = 50.dp)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null || glyph != null) {
            OptionBadge(icon, glyph, primary, 30.dp)
            Spacer(Modifier.width(10.dp))
        }
        Text(nb(text), color = palette.text, style = MaterialTheme.typography.bodyLarge, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (highlighted && glyph == null && icon != null) Icon(Icons.Default.CheckCircle, null, tint = primary, modifier = Modifier.size(20.dp))
    }
}

/** Fixed-list dropdown with search. Same call signature as before so every screen keeps working. */
@Composable
fun <T> AppDropdown(
    label: String,
    value: T,
    options: List<T>,
    optionLabel: (T) -> String,
    onSelected: (T) -> Unit,
    modifier: Modifier = Modifier,
    displayText: String? = null,
    optionIcon: ((T) -> ImageVector)? = null
) {
    var open by remember { mutableStateOf(false) }
    val shown = displayText ?: optionLabel(value)
    DropdownFace(
        label = label, text = shown, onClick = { open = true }, modifier = modifier.fillMaxWidth(),
        leadingIcon = optionIcon?.invoke(value) ?: OptionIcons.of(value, shown), leadingGlyph = glyphOf(value),
        trailingIcon = if (open) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown
    )
    if (open) {
        SearchPickerDialog(
            title = label,
            options = options,
            optionLabel = optionLabel,
            selected = if (displayText == null) value else options.firstOrNull { optionLabel(it) == displayText },
            onPick = { onSelected(it); open = false },
            onDismiss = { open = false },
            optionIcon = optionIcon
        )
    }
}

/** Dropdown that also accepts free text: pick from the list or type something new in the same field. */
@Composable
fun SuggestField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    suggestions: List<String>,
    modifier: Modifier = Modifier,
    placeholder: String = L("აირჩიეთ ან აკრიფეთ"),
    onSuggestionPicked: (String) -> Unit = {}
) {
    var open by remember { mutableStateOf(false) }
    DropdownFace(
        label = label,
        text = value.ifEmpty { placeholder },
        placeholder = value.isEmpty(),
        onClick = { open = true },
        modifier = modifier.fillMaxWidth(),
        trailingIcon = Icons.Default.EditNote,
        leadingIcon = if (value.isNotEmpty()) OptionIcons.byLabel(value) else null
    )
    if (open) {
        SearchPickerDialog(
            title = label,
            options = suggestions,
            optionLabel = { it },
            selected = value.takeIf { it in suggestions },
            initialQuery = "",
            onPick = { onValueChange(it); onSuggestionPicked(it); open = false },
            onDismiss = { open = false },
            actions = { q ->
                if (q.isNotEmpty() && suggestions.none { it.equals(q, ignoreCase = true) })
                    listOf(PickerAction(Lf("გამოყენება: «{0}»", q), Icons.Default.Edit) { onValueChange(it); open = false })
                else emptyList()
            }
        )
    }
}

/**
 * Person field bound to the members database: filters as you type; if the name is not found,
 * offers to add it to the members list (with confirmation) or just use it once.
 */
@Composable
fun MemberField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    memberNames: List<String>,
    onAddMember: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var open by remember { mutableStateOf(false) }
    var confirmAdd by remember { mutableStateOf<String?>(null) }
    DropdownFace(
        label = label,
        text = value.ifEmpty { L("აირჩიეთ წევრი ან აკრიფეთ სახელი") },
        placeholder = value.isEmpty(),
        onClick = { open = true },
        modifier = modifier.fillMaxWidth(),
        trailingIcon = Icons.Default.PersonSearch,
        leadingIcon = if (value.isNotEmpty()) Icons.Default.Person else null
    )
    if (open) {
        SearchPickerDialog(
            title = label,
            optionIcon = { Icons.Default.Person },
            options = memberNames.distinct().sorted(),
            optionLabel = { it },
            selected = value.takeIf { it.isNotEmpty() },
            onPick = { onValueChange(it); open = false },
            onDismiss = { open = false },
            actions = { q ->
                if (q.isNotEmpty() && memberNames.none { it.equals(q, ignoreCase = true) }) listOf(
                    PickerAction(Lf("ბაზაში დამატება: «{0}»", q), Icons.Default.PersonAdd) { confirmAdd = it },
                    PickerAction(Lf("მხოლოდ ერთჯერადად: «{0}»", q), Icons.Default.Edit) { onValueChange(it); open = false }
                ) else emptyList()
            }
        )
    }
    confirmAdd?.let { name ->
        com.example.ui.components.FormDialog(
            onDismissRequest = { confirmAdd = null },
            icon = { Icon(Icons.Default.PersonAdd, null) },
            title = { Text(L("ახალი წევრის დამატება")) },
            text = { Text(Lf("«{0}» არ არის წევრების ბაზაში. დავამატო?", name)) },
            confirmButton = {
                Button(onClick = { onAddMember(name); onValueChange(name); confirmAdd = null; open = false }) { Text(L("დიახ, დამატება")) }
            },
            dismissButton = {
                TextButton(onClick = { onValueChange(name); confirmAdd = null; open = false }) { Text(L("არა, მხოლოდ ჩაწერა")) }
            }
        )
    }
}

/** Amount input with a currency selector next to it. */
@Composable
fun AmountCurrencyField(
    label: String,
    amountText: String,
    onAmountChange: (String) -> Unit,
    currency: String,
    onCurrencyChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var open by remember { mutableStateOf(false) }
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        OutlinedTextField(
            value = amountText,
            onValueChange = { t -> onAmountChange(t.filter { it.isDigit() || it == '.' || it == ',' }.replace(',', '.')) },
            label = { Text(nb(label), maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        val c = Currencies.find(currency)
        DropdownFace(
            label = "",
            text = "${c.symbol} ${c.code}",
            onClick = { open = true },
            compact = true,
            modifier = Modifier.width(118.dp)
        )
    }
    if (open) {
        SearchPickerDialog(
            title = L("ვალუტა"),
            options = Currencies.all,
            optionLabel = { "${it.code} — ${L(it.nameKa)}" },
            selected = Currencies.find(currency),
            onPick = { onCurrencyChange(it.code); open = false },
            onDismiss = { open = false }
        )
    }
}
