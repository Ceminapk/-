package com.example.ui.v216

import com.example.data.model.*
import com.example.ui.calendar.DayInfo
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.settings.money
import java.util.Calendar

/** One honour/pledge understood from the gabbai's dictation. */
data class DebriefItem(val memberName: String, val type: AliyahType, val amount: Double, val currency: String, val matchedMember: Boolean, val source: String)

/** Offline parser for the post-Shabbat dictation: "დავითმა ფეთიხა 100 ლარი, იაკობმა შელიში 50 დოლარი". */
object DebriefParser {
    private val honours: List<Pair<List<String>, AliyahType>> = listOf(
        listOf("ფეთიხ", "პეტიხ", "פתיח", "петих", "ark", "petich") to AliyahType.PETICHA,
        listOf("ქოჰენ", "კოენ", "כהן", "коэн", "коhен", "kohen", "cohen") to AliyahType.KOHEN,
        listOf("ლევი", "לוי", "леви", "levi") to AliyahType.LEVI,
        listOf("შელიშ", "שליש", "шлиш", "shlishi") to AliyahType.SHLISHI,
        listOf("რევიყ", "რევიი", "רביע", "реви", "revii") to AliyahType.REVII,
        listOf("ხამიშ", "חמיש", "хамиш", "chamishi") to AliyahType.CHAMISHI,
        listOf("შევიი", "שביע", "швии", "shevii") to AliyahType.SHEVII,
        listOf("შიში", "שישי", "шиши", "shishi") to AliyahType.SHISHI,
        listOf("მაფტირ", "מפטיר", "мафтир", "maftir") to AliyahType.MAFTIR,
        listOf("ჰაგბა", "הגבה", "агба", "hagba") to AliyahType.HAGBAH,
        listOf("გელილ", "גליל", "глил", "gelila") to AliyahType.GELILAH,
        listOf("ფასუკ", "פסוק", "псук", "pasuk") to AliyahType.PESUKIM,
        listOf("მოსიფ", "დამატებით", "מוסיף", "мосиф", "mosif") to AliyahType.MOSIF,
        listOf("ნედერ", "ნედარ", "נדר", "недер", "neder", "pledge") to AliyahType.NEDER,
        listOf("სამსახურ", "כיבוד", "kibud") to AliyahType.SERVICE
    )
    // Longer/more specific words first so "დოლარი" never reads as "ლარი".
    private val currencies = listOf(
        listOf("დოლარ", "доллар", "dollar", "usd", "$", "бакс") to "USD",
        listOf("ევრო", "евро", "euro", "eur", "€") to "EUR",
        listOf("შეკელ", "შექელ", "шекел", "шекел", "shekel", "ils", "₪") to "ILS",
        listOf("რუბლ", "рубл", "rub", "₽") to "RUB",
        listOf("ფუნტ", "фунт", "pound", "gbp", "£") to "GBP",
        listOf("ლარ", "лари", "лар", "gel", "lari", "₾") to "GEL"
    )
    private val numberWords = linkedMapOf(
        "ათასი" to 1000.0, "ხუთასი" to 500.0, "ოთხასი" to 400.0, "სამასი" to 300.0, "ორასი" to 200.0, "ასი" to 100.0,
        "ორმოცდაათი" to 50.0, "ოცდაათი" to 30.0, "ოცი" to 20.0, "თვრამეტი" to 18.0, "ათი" to 10.0,
        "тысяч" to 1000.0, "пятьсот" to 500.0, "четыреста" to 400.0, "триста" to 300.0, "двести" to 200.0, "сто" to 100.0,
        "пятьдесят" to 50.0, "тридцать" to 30.0, "двадцать" to 20.0, "восемнадцать" to 18.0, "десять" to 10.0
    )

    fun currencyOf(low: String, default: String): String {
        val words = low.split(Regex("[^\\p{L}$€₪₽£₾]+")).filter { it.isNotBlank() }
        // a currency must be its own word (or symbol) — never a piece of a name like "ილარიონ"
        for ((keys, code) in currencies) {
            if (words.any { w -> keys.any { k -> if (k.length == 1) w.contains(k) else w.startsWith(k) } }) return code
            if (keys.any { it.length == 1 && low.contains(it) }) return code
        }
        return default
    }

    fun amountOf(seg: String): Double {
        Regex("\\d[\\d ]*(?:[.,]\\d+)?").find(seg)?.value?.replace(" ", "")?.replace(',', '.')?.toDoubleOrNull()?.let { return it }
        val low = seg.lowercase()
        return low.split(Regex("[^\\p{L}]+")).firstNotNullOfOrNull { w -> numberWords.entries.firstOrNull { w.startsWith(it.key) }?.value } ?: 0.0
    }

    fun parse(text: String, members: List<MemberEntity>, defaultCurrency: String = "GEL"): List<DebriefItem> {
        val living = members.filter { it.status != MemberStatus.DECEASED }
        return text.split(Regex("[,;\\n]+|(?<!\\d)\\.(?!\\d)|\\s+და\\s+|\\s+и\\s+|\\s+and\\s+")).mapNotNull { raw ->
            val seg = raw.trim()
            if (seg.isBlank()) return@mapNotNull null
            val low = seg.lowercase()
            val type = honours.firstOrNull { (keys, _) -> keys.any { low.contains(it) } }?.second ?: return@mapNotNull null
            val member = matchMember(low, living)
            val name = member?.fullName ?: seg.split(Regex("\\s+")).firstOrNull()?.let(::stripCase).orEmpty()
            DebriefItem(name, type, amountOf(seg), currencyOf(low, defaultCurrency), member != null, seg)
        }
    }

    /** Georgian/Russian case endings (დავითმა, დავითს, Давиду) are cut so the first name still matches. */
    fun stripCase(w: String): String = w.replace(Regex("(მა|ს|მ|ომ|ем|ом|у|ю)$"), "").ifBlank { w }

    private fun stem(w: String) = w.lowercase().replace(Regex("(ი|ა|ის|ს|მა|მ)$"), "")
    private fun sameWord(spoken: String, name: String): Boolean {
        val a = stem(spoken); val b = stem(name)
        return b.length >= 3 && (a == b || (a.startsWith(b) && a.length - b.length <= 2) || (b.startsWith(a) && a.length >= 4 && b.length - a.length <= 1))
    }

    /** Best-scoring member: full name > first + surname > unique first name. Ambiguous first names stay unmatched. */
    fun matchMember(low: String, members: List<MemberEntity>): MemberEntity? {
        val words = low.split(Regex("[^\\p{L}]+")).filter { it.length >= 2 }
        val scored = members.map { m ->
            val parts = m.fullName.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
            val hits = parts.count { p -> words.any { sameWord(it, p) } }
            val score = when {
                low.contains(m.fullName.lowercase()) -> 100
                parts.isNotEmpty() && hits == parts.size -> 50 + hits
                parts.isNotEmpty() && words.any { sameWord(it, parts[0]) } -> 10
                hits > 0 -> 5
                else -> 0
            }
            m to score
        }.filter { it.second > 0 }.sortedByDescending { it.second }
        if (scored.isEmpty()) return null
        if (scored.size > 1 && scored[0].second == scored[1].second) return null
        return scored[0].first
    }
}

/** Monthly budget alarm: fixed costs vs guaranteed income. */
data class BudgetStatus(val income: Double, val expense: Double, val fixed: Double, val shortfall: Double, val alarm: Boolean)

object BudgetAlarm {
    private fun sameMonth(a: Long, now: Long): Boolean {
        val x = Calendar.getInstance().apply { timeInMillis = a }; val y = Calendar.getInstance().apply { timeInMillis = now }
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.MONTH) == y.get(Calendar.MONTH)
    }

    /** Fixed monthly costs = kollel stipends + utility budget; income/expense counted for the current month. */
    fun status(txs: List<TransactionEntity>, kollel: List<KollelStudentEntity>, utilityBudget: Double, now: Long = System.currentTimeMillis()): BudgetStatus {
        val month = txs.filter { sameMonth(it.dateMillis, now) && it.status == TransactionStatus.PAID }
        val income = month.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val expense = month.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
        val fixed = kollel.sumOf { it.monthlyStipend } + utilityBudget
        val need = maxOf(fixed, expense)
        val shortfall = (need - income).coerceAtLeast(0.0)
        return BudgetStatus(income, expense, fixed, shortfall, shortfall > 0)
    }
}

/** Minyan attendance stars, one MINYAN registry row per member per prayer. */
data class MinyanStar(val name: String, val count: Int, val lastSeen: Long)

object MinyanStars {
    fun ranking(rows: List<RegistryEntity>, sinceMillis: Long): List<MinyanStar> =
        rows.filter { it.kind == RegistryKind.MINYAN.name && it.dateMillis >= sinceMillis && it.memberName.isNotBlank() }
            .groupBy { it.memberName }.map { (n, l) -> MinyanStar(n, l.size, l.maxOf { it.dateMillis }) }
            .sortedWith(compareByDescending<MinyanStar> { it.count }.thenBy { it.name })

    fun stars(count: Int): Int = when { count >= 20 -> 5; count >= 12 -> 4; count >= 8 -> 3; count >= 4 -> 2; count >= 1 -> 1; else -> 0 }

    /** Living members not seen for [days] days (or never). */
    fun missing(rows: List<RegistryEntity>, members: List<MemberEntity>, days: Int, now: Long = System.currentTimeMillis()): List<MemberEntity> {
        val cut = now - days * 86_400_000L
        val last = rows.filter { it.kind == RegistryKind.MINYAN.name }.groupBy { it.memberName }.mapValues { e -> e.value.maxOf { it.dateMillis } }
        return members.filter { it.status == MemberStatus.ACTIVE }.filter { (last[it.fullName] ?: 0L) < cut }
    }
}

/** Shabbat / Yom Tov quiet window: from candle lighting until havdalah. */
object QuietMode {
    fun isQuiet(now: Long, today: DayInfo): Boolean {
        val c = today.candleLighting
        if (c != null && now >= c) return true
        val restToday = today.isShabbat || today.isYomTov
        if (restToday) {
            val h = today.havdalah
            // started yesterday evening; ends at havdalah (or continues if tomorrow is also rest)
            if (h == null) return true
            return now < h
        }
        return false
    }
}

/** Texts for the bimah: Mi Shebeirach for the sick and Hazkara (El Male Rachamim). */
object BimahTexts {
    fun miShebeirachSick(hebName: String, motherHe: String, female: Boolean): String {
        val bn = if (female) "בת" else "בן"
        val who = "$hebName $bn $motherHe".trim()
        return if (female)
            "מִי שֶׁבֵּרַךְ אֲבוֹתֵינוּ אַבְרָהָם יִצְחָק וְיַעֲקֹב, הוּא יְבָרֵךְ וִירַפֵּא אֶת הַחוֹלָה $who, הַקָּדוֹשׁ בָּרוּךְ הוּא יִמָּלֵא רַחֲמִים עָלֶיהָ לְהַחֲלִימָהּ וּלְרַפֹּאתָהּ, וְיִשְׁלַח לָהּ מְהֵרָה רְפוּאָה שְׁלֵמָה מִן הַשָּׁמַיִם, וְנֹאמַר אָמֵן."
        else
            "מִי שֶׁבֵּרַךְ אֲבוֹתֵינוּ אַבְרָהָם יִצְחָק וְיַעֲקֹב, הוּא יְבָרֵךְ וִירַפֵּא אֶת הַחוֹלֶה $who, הַקָּדוֹשׁ בָּרוּךְ הוּא יִמָּלֵא רַחֲמִים עָלָיו לְהַחֲלִימוֹ וּלְרַפֹּאתוֹ, וְיִשְׁלַח לוֹ מְהֵרָה רְפוּאָה שְׁלֵמָה מִן הַשָּׁמַיִם, וְנֹאמַר אָמֵן."
    }

    fun miShebeirachOleh(hebName: String, fatherHe: String, amount: String): String =
        "מִי שֶׁבֵּרַךְ אֲבוֹתֵינוּ אַבְרָהָם יִצְחָק וְיַעֲקֹב, הוּא יְבָרֵךְ אֶת $hebName בֶּן $fatherHe, בַּעֲבוּר שֶׁעָלָה לִכְבוֹד הַמָּקוֹם וְלִכְבוֹד הַתּוֹרָה" +
            (if (amount.isNotBlank()) " וְנָדַר $amount לִצְדָקָה" else "") + ", וְנֹאמַר אָמֵן."

    fun hazkara(hebName: String, parentHe: String, female: Boolean): String {
        val bn = if (female) "בַּת" else "בֶּן"
        val suffix = if (female) "שֶׁהָלְכָה לְעוֹלָמָהּ" else "שֶׁהָלַךְ לְעוֹלָמוֹ"
        val rest = if (female) "נִשְׁמָתָהּ" else "נִשְׁמָתוֹ"
        return "אֵל מָלֵא רַחֲמִים שׁוֹכֵן בַּמְּרוֹמִים, הַמְצֵא מְנוּחָה נְכוֹנָה תַּחַת כַּנְפֵי הַשְּׁכִינָה, אֶת נִשְׁמַת $hebName $bn $parentHe $suffix, " +
            "בַּגַּן עֵדֶן תְּהֵא מְנוּחָתוֹ, לָכֵן בַּעַל הָרַחֲמִים יַסְתִּירֵהוּ בְּסֵתֶר כְּנָפָיו לְעוֹלָמִים, וְיִצְרוֹר בִּצְרוֹר הַחַיִּים אֶת $rest, וְנֹאמַר אָמֵן."
    }
}

/** Friday sheet for the bimah: honours, readers, yahrzeits, kiddush and announcements. */
object BimahPlan {
    fun text(shul: String, dateText: String, parasha: String, honours: List<Pair<String, String>>, yahrzeits: List<String>, kiddush: List<String>, notes: String): String = buildString {
        append(shul).append('\n')
        append(Lf("ბიმას გეგმა — შაბათი {0}", dateText)).append('\n')
        if (parasha.isNotBlank()) append(Lf("ფარაშა: {0}", parasha)).append('\n')
        append('\n').append(L("ალიები და პატივი:")).append('\n')
        if (honours.isEmpty()) append("• —\n") else honours.forEach { (h, who) -> append("• ").append(h).append(": ").append(who.ifBlank { "________" }).append('\n') }
        if (yahrzeits.isNotEmpty()) { append('\n').append(L("ამ კვირის იორცაიტები:")).append('\n'); yahrzeits.forEach { append("• ").append(it).append('\n') } }
        if (kiddush.isNotEmpty()) { append('\n').append(L("კიდუშის სპონსორი:")).append('\n'); kiddush.forEach { append("• ").append(it).append('\n') } }
        if (notes.isNotBlank()) { append('\n').append(L("განცხადებები:")).append('\n').append(notes).append('\n') }
    }

    val standardHonours = listOf(AliyahType.PETICHA, AliyahType.KOHEN, AliyahType.LEVI, AliyahType.SHLISHI, AliyahType.REVII,
        AliyahType.CHAMISHI, AliyahType.SHISHI, AliyahType.SHEVII, AliyahType.MAFTIR, AliyahType.HAGBAH, AliyahType.GELILAH)
}

/** Annual meeting figures for one year, with the previous year for comparison. */
data class YearFigures(val year: Int, val income: Double, val expense: Double, val aliyot: Int, val events: Int, val topDonors: List<Pair<String, Double>>)

object AnnualReport {
    private fun yearOf(t: Long) = Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.YEAR)
    fun figures(year: Int, txs: List<TransactionEntity>, aliyot: List<AliyahEntity>, events: List<SynagogueEventEntity>): YearFigures {
        val y = txs.filter { yearOf(it.dateMillis) == year && it.status == TransactionStatus.PAID }
        val inc = y.filter { it.type == TransactionType.INCOME }
        return YearFigures(year, inc.sumOf { it.amount }, y.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount },
            aliyot.count { yearOf(it.dateMillis) == year }, events.count { yearOf(it.dateMillis) == year },
            inc.filter { it.memberName.isNotBlank() }.groupBy { it.memberName }.map { it.key to it.value.sumOf { t -> t.amount } }.sortedByDescending { it.second }.take(10))
    }

    fun lines(shul: String, now: YearFigures, prev: YearFigures, currency: String): List<String> {
        fun diff(a: Double, b: Double) = if (b <= 0) "" else " (" + (if (a >= b) "+" else "") + "%.0f".format((a - b) / b * 100) + "%)"
        val out = mutableListOf(shul, Lf("კრების წლიური ანგარიში — {0}", now.year), "")
        out += Lf("შემოსავალი: {0}", money(now.income, currency)) + diff(now.income, prev.income)
        out += Lf("გასავალი: {0}", money(now.expense, currency)) + diff(now.expense, prev.expense)
        out += Lf("ნაშთი: {0}", money(now.income - now.expense, currency))
        out += Lf("ალიები და ნედერები: {0} (შარშან {1})", now.aliyot, prev.aliyot)
        out += Lf("ღონისძიებები: {0} (შარშან {1})", now.events, prev.events)
        out += ""
        out += L("ყველაზე დიდი შემწირველები:")
        if (now.topDonors.isEmpty()) out += "—"
        now.topDonors.forEachIndexed { i, (n, a) -> out += "${i + 1}. $n — ${money(a, currency)}" }
        out += ""; out += L("ხაზაკ უვარუხ ყველა მრევლს!")
        return out
    }
}
