package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.export.XlsxExporter
import com.example.data.model.FinanceCategory
import com.example.data.model.TransactionType
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.viewmodel.GabbaiUiState

/** Export chosen data categories as one Excel workbook or as CSV files. */
@Composable
fun CategoryExportDialog(state: GabbaiUiState, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var modules by remember { mutableStateOf(XlsxExporter.Module.values().toSet()) }
    var type by remember { mutableStateOf<TransactionType?>(null) }
    var category by remember { mutableStateOf<FinanceCategory?>(null) }
    var csv by remember { mutableStateOf(false) }
    val sheets = remember(state, modules, type, category) { XlsxExporter.sheetsFor(state, modules, type, category) }
    val rowCount = sheets.sumOf { maxOf(0, it.second.size - 1) }

    FormDialog(
        onDismissRequest = onDismiss,
        title = { Text(L("ექსპორტი კატეგორიების მიხედვით"), fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val allOn = modules.size == XlsxExporter.Module.values().size
                CheckRow(L("ყველა განყოფილება"), allOn, "export_all") { modules = if (allOn) emptySet() else XlsxExporter.Module.values().toSet() }
                HorizontalDivider()
                XlsxExporter.Module.values().forEach { m ->
                    CheckRow(L(m.ka), m in modules, "export_${m.name}") { modules = if (m in modules) modules - m else modules + m }
                }
                if (XlsxExporter.Module.FINANCES in modules) {
                    HorizontalDivider()
                    AppDropdown(
                        label = L("ფინანსების ტიპი"),
                        value = type,
                        options = listOf(null, TransactionType.INCOME, TransactionType.EXPENSE),
                        optionLabel = { when (it) { null -> L("ყველა"); TransactionType.INCOME -> L("შემოსავალი"); TransactionType.EXPENSE -> L("გასავალი") } },
                        onSelected = { type = it }
                    )
                    AppDropdown(
                        label = L("ფინანსების კატეგორია"),
                        value = category,
                        options = listOf<FinanceCategory?>(null) + FinanceCategory.values().toList(),
                        optionLabel = { it?.titleKa ?: L("ყველა") },
                        onSelected = { category = it }
                    )
                }
                HorizontalDivider()
                Text(L("ფორმატი"), fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !csv, onClick = { csv = false }, label = { Text("Excel (.xlsx)") }, modifier = Modifier.weight(1f))
                    FilterChip(selected = csv, onClick = { csv = true }, label = { Text("CSV") }, modifier = Modifier.weight(1f))
                }
                Text(Lf("სულ ჩანაწერი: {0}", rowCount), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(
                enabled = sheets.isNotEmpty(),
                onClick = { XlsxExporter.shareSheets(context, sheets, csv, L("Gabbai Cosmos — ექსპორტი")); onDismiss() },
                modifier = Modifier.testTag("export_go")
            ) { Text(L("ექსპორტი"), maxLines = 1) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L("გაუქმება"), maxLines = 1) } }
    )
}

@Composable
private fun CheckRow(text: String, checked: Boolean, tag: String, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onToggle).testTag(tag).heightIn(min = 44.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
        Text(text, modifier = Modifier.weight(1f))
    }
}
