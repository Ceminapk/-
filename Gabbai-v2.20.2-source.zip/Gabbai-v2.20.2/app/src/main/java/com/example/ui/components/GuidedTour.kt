package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiScreen
import kotlinx.coroutines.delay

data class TourStep(val screen: GabbaiScreen, private val textKa: String) {
    val text: String get() = L(textKa)
}

/** Animated walkthrough of every section, started from the AI navigator. */
object GuidedTour {
    const val STEP_MILLIS = 8000L
    val steps = listOf(
        TourStep(GabbaiScreen.DASHBOARD, "მთავარი ეკრანი: აქ ხედავთ დღის და ლოცვის დროებს, ბალანსს, მოახლოებულ იორცაიტებსა და დაბადების დღეებს. დროების მორბენალ ზოლზე დაჭერით კალენდარში დღის დროებზე გადახვალთ."),
        TourStep(GabbaiScreen.DASHBOARD, "სწრაფი წვდომის მოდულები: ისრით გაშალეთ ან ჩაკეცეთ, „მართვის“ ღილაკით კი დაამატეთ ან ამოიღეთ ნებისმიერი განყოფილება და სინაგოგის ნებისმიერი ჟურნალი. ქვედა პანელზე მიკროფონით ხმოვანი მართვა ჩაირთვება — იგივე ჭკვიანი ასისტენტი, რომელიც ბრძანებას შეასრულებს ან კითხვას უპასუხებს."),
        TourStep(GabbaiScreen.FINANCES, "ფინანსები: შუა მრგვალი „+“ ღილაკით ამატებთ ოპერაციას. აირჩიეთ დასახელება, თანხა და ვალუტა, წევრი და გადახდის მეთოდი. ჩანაწერზე დაჭერით ასწორებთ ან შლით."),
        TourStep(GabbaiScreen.ALIYOT, "ალიები და ფასუკები: ჩაწერეთ ვინ მიიღო ალია, რომელი და რა თანხით. სწრაფი ნედერიც აქედან ემატება."),
        TourStep(GabbaiScreen.MEMBERS, "წევრები: დაამატეთ წევრი ფოტოთი, როლით, სტატუსით და დაბადების დღით. ვალები და წითელი/შავი სია აქ ჩანს."),
        TourStep(GabbaiScreen.YAHRZEITS, "გარდაცვლილები და იორცაიტი: შეიყვანეთ გარდაცვალების თარიღი ებრაული ან გრიგორიანული კალენდრით და მიაბით ახლობელი — აპი წინასწარ შეგახსენებთ."),
        TourStep(GabbaiScreen.KOLLEL, "ქოლელი: ავრეხების სია, დასწრება და სტიპენდიები."),
        TourStep(GabbaiScreen.TZEDAKAH, "ცედაკა: გაჭირვებულთა ბაზა და დახმარების გაცემა მიმართულებების მიხედვით."),
        TourStep(GabbaiScreen.EVENTS, "ღონისძიებები: კიდუშები, ბარ-მიცვები, ქორწილები და დღესასწაულები სპონსორებით."),
        TourStep(GabbaiScreen.CALENDAR, "კალენდარი და ზმანიმი: ებრაული თარიღი, სანთლის ანთებისა და შაბათის გასვლის დრო. ქალაქი აირჩიეთ ან GPS-ით დაადგინეთ."),
        TourStep(GabbaiScreen.REGISTERS, "სინაგოგის ჟურნალები: მიკვეს შემოსავალი, გემახის სესხები, ნედერის განვადება, მიცვების აუქციონი, კომუნალური ბიუჯეტით, შეკვეთები, სტუმრები, ხანუქა, ქაფაროთი, ხამეცი, თეჰილიმი, საგანგებო კონტაქტები, სეფერ თორის დეფექტები, დაკარგული ნივთები, ბიბლიოთეკა, გასაღებები, მატიანე და ხმოვანი ჩანიშვნები. ზემოთ აირჩიეთ ჟურნალი, „+“-ით დაამატეთ."),
        TourStep(GabbaiScreen.REGISTERS, "ახალი ჟურნალები: ალიების წინასწარი დარიგება (WhatsApp/SMS შეტყობინებით და ბიმაზე ერთი ღილაკით), ადგილების რუკა, სწრაფი ბლოკნოტი, ბარ-მიცვას გეგმა, საპატიო სტუმრები, აუდიოსისტემა, ჰავდალას მარაგები, შაბათის ტაიმერები, მეზუზები, მაასერი, ზარების ჯაჭვი, მიზნები და ფონდები. ყოველ ჩანაწერზე შესწორება ბარათის შიგნითაა."),
        TourStep(GabbaiScreen.TOOLS, "ჰალახური ხელსაწყოები: ომერი, ქიდუშ ლევანა, მარხვები, ერუვ თავშილინი, იზქორი, ბრით-მილა, პიდიონ ჰაბენი, ბარ-მიცვა, მიშებერახი, მინიანის SOS, შაბათის დაიჯესტი, როშ ჰაშანას სედერი და QR სკანერი."),
        TourStep(GabbaiScreen.SECURITY, "უსაფრთხოება: მონაცემების დაშიფვრა და დაცვა."),
        TourStep(GabbaiScreen.TOOLS, "ახალი ხელსაწყოები: შაბათის PDF ბიულეტენი, ჯგუფური WhatsApp/SMS, ბარ-მიცვას კალკულატორი, ნეცის წამზომი და დღის დროების ხმოვანი შეხსენება, მიძღვნის ტექსტის გენერატორი, კიდუშისა და ქაშრუთის გზამკვლევი, 6 თვის ფინანსური გრაფიკი და QR დამოწმება წლიურ ცნობაზე."),
        TourStep(GabbaiScreen.SETTINGS, "პარამეტრები: ენა და განათება, 5 ფერთა თემა, შრიფტის ზომა, გუმბათის სტილი, სინაგოგის სახელი და ემბლემა, ვალუტა, შეხსენებები, ნაზი ვიბრაცია, ავტომატური ბექაფი (ბოლო 7 ასლი), Excel ექსპორტი და ბაზის გასუფთავება."),
        TourStep(GabbaiScreen.DASHBOARD, "გზამკვლევი დასრულდა. ნებისმიერ დროს დააჭირეთ მბრუნავ სფეროს — დაგეხმარებით კითხვებში და გადაგიყვანთ სასურველ განყოფილებაში.")
    )
    var step by mutableStateOf(-1)
    val running: Boolean get() = step >= 0
    fun start() { step = 0 }
    fun stop() { step = -1 }
    fun next() { step = if (step + 1 >= steps.size) -1 else step + 1 }
    fun prev() { if (step > 0) step-- }
}

@Composable
fun GuidedTourOverlay(onNavigate: (GabbaiScreen) -> Unit, modifier: Modifier = Modifier) {
    val idx = GuidedTour.step
    if (idx < 0) return
    val step = GuidedTour.steps[idx]
    val progress = remember { Animatable(0f) }
    LaunchedEffect(idx) {
        onNavigate(step.screen)
        progress.snapTo(0f)
        progress.animateTo(1f, tween(GuidedTour.STEP_MILLIS.toInt(), easing = LinearEasing))
        delay(150)
        GuidedTour.next()
    }
    Box(modifier.fillMaxSize().padding(horizontal = 14.dp).padding(bottom = 120.dp), contentAlignment = Alignment.BottomCenter) {
        AnimatedContent(
            targetState = idx,
            transitionSpec = {
                (slideInHorizontally { it } + fadeIn() + scaleIn(initialScale = 0.85f)) togetherWith
                    (slideOutHorizontally { -it } + fadeOut())
            },
            label = "tour"
        ) { i ->
            val s = GuidedTour.steps[i]
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = CosmicSurfaceCard.copy(alpha = 0.97f),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, CosmicStardustCyan),
                shadowElevation = 12.dp,
                modifier = Modifier.fillMaxWidth().testTag("guided_tour_card")
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CrystalAiSphere(size = 40.dp, tint = CosmicStardustCyan, onClick = {})
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.screen.title, fontWeight = FontWeight.Bold, color = CosmicCelestialGold, fontSize = 15.sp)
                            Text(Lf("ნაბიჯი {0} / {1}", i + 1, GuidedTour.steps.size), fontSize = 11.sp, color = CosmicTextSecondary)
                        }
                    }
                    Text(s.text, color = CosmicTextPrimary, fontSize = 14.sp, lineHeight = 20.sp)
                    LinearProgressIndicator(progress = { progress.value }, modifier = Modifier.fillMaxWidth(), color = CosmicStardustCyan)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { GuidedTour.prev() }, enabled = i > 0) { Text(L("უკან")) }
                        TextButton(onClick = { GuidedTour.stop() }, modifier = Modifier.testTag("tour_stop")) { Text(L("შეწყვეტა")) }
                        TextButton(onClick = { GuidedTour.next() }) { Text(L("შემდეგი")) }
                    }
                }
            }
        }
    }
}
