package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.cos

/** Transparent crystal ball glass: tinted body, rim light, specular highlight. */
private fun DrawScope.crystalGlass(tint: Color, spin: Float) {
    val r = size.minDimension / 2f
    val c = Offset(size.width / 2f, size.height / 2f)
    drawCircle(
        Brush.radialGradient(
            listOf(Color.White.copy(alpha = 0.10f), tint.copy(alpha = 0.22f), tint.copy(alpha = 0.55f)),
            center = c + Offset(-r * 0.25f, -r * 0.3f), radius = r * 1.25f
        ), r, c
    )
    // Rotating refraction band (the sphere's own spin)
    rotate(spin, c) {
        drawArc(
            Brush.sweepGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.35f), Color.Transparent), c),
            startAngle = 0f, sweepAngle = 120f, useCenter = false,
            topLeft = c - Offset(r * 0.82f, r * 0.82f), size = Size(r * 1.64f, r * 1.64f),
            style = Stroke(width = r * 0.08f, cap = StrokeCap.Round)
        )
    }
    drawCircle(Color.White.copy(alpha = 0.55f), r * 0.98f, c, style = Stroke(width = r * 0.06f))
    drawCircle(tint.copy(alpha = 0.8f), r, c, style = Stroke(width = r * 0.03f))
    drawOval(
        Brush.radialGradient(listOf(Color.White.copy(alpha = 0.85f), Color.Transparent),
            center = c + Offset(-r * 0.35f, -r * 0.5f), radius = r * 0.4f),
        topLeft = c + Offset(-r * 0.62f, -r * 0.72f), size = Size(r * 0.55f, r * 0.32f)
    )
}

/** A stylised observant Jewish man's head (black hat, beard, peyot), drawn facing forward; [turn] in -1..1 squeezes it to fake a 3D turn. */
private fun DrawScope.rabbiHead(turn: Float) {
    val r = size.minDimension / 2f
    val c = Offset(size.width / 2f, size.height / 2f + r * 0.08f)
    val sx = 0.35f + 0.65f * abs(turn)
    val face = Color(0xFFF1C9A5); val black = Color(0xFF15151C); val beard = Color(0xFF3A2C24)
    fun ox(x: Float) = c.x + x * r * sx
    // beard
    drawOval(beard, Offset(ox(-0.34f), c.y - r * 0.02f), Size(0.68f * r * sx, r * 0.55f))
    // face
    drawOval(face, Offset(ox(-0.3f), c.y - r * 0.38f), Size(0.6f * r * sx, r * 0.62f))
    // peyot
    drawOval(beard, Offset(ox(-0.36f), c.y - r * 0.15f), Size(0.09f * r * sx, r * 0.42f))
    drawOval(beard, Offset(ox(0.27f), c.y - r * 0.15f), Size(0.09f * r * sx, r * 0.42f))
    // eyes, only when facing towards the viewer
    if (turn > 0f) {
        drawCircle(black, r * 0.035f, Offset(ox(-0.11f), c.y - r * 0.12f))
        drawCircle(black, r * 0.035f, Offset(ox(0.11f), c.y - r * 0.12f))
    }
    // hat brim + crown
    drawOval(black, Offset(ox(-0.48f), c.y - r * 0.45f), Size(0.96f * r * sx, r * 0.14f))
    drawRoundRect(black, Offset(ox(-0.3f), c.y - r * 0.78f), Size(0.6f * r * sx, r * 0.38f), androidx.compose.ui.geometry.CornerRadius(r * 0.08f))
}

/** Animated AI navigator: crystal sphere and the head inside both rotate on their own axes. */
@Composable
fun CrystalAiSphere(size: Dp, tint: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "sphere")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "spin")
    val head by t.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "head")
    Canvas(
        modifier
            .size(size)
            .shadow(10.dp, CircleShape, ambientColor = tint, spotColor = tint)
            .clip(CircleShape)
            .clickable(onClick = onClick)
    ) {
        rabbiHead(cos(Math.toRadians(head.toDouble())).toFloat())
        crystalGlass(tint, spin)
    }
}

/** Static crystal sphere button with an icon inside (does not move). */
@Composable
fun CrystalIconSphere(size: Dp, tint: Color, icon: ImageVector, contentDescription: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .shadow(10.dp, CircleShape, ambientColor = tint, spotColor = tint)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.matchParentSize()) { crystalGlass(tint, 300f) }
        Icon(icon, contentDescription, tint = Color.White, modifier = Modifier.size(size * 0.46f))
    }
}
