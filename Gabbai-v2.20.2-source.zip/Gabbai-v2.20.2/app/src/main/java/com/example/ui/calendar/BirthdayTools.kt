package com.example.ui.calendar

import com.example.data.model.MemberEntity
import com.example.data.model.MemberStatus
import java.util.Calendar

data class UpcomingBirthday(val member: MemberEntity, val dateMillis: Long, val daysUntil: Int, val turningAge: Int)

object BirthdayTools {
    private fun midnight(c: Calendar) = c.apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }

    /** Next Gregorian birthday on/after today. Feb 29 falls on Feb 28 in non-leap years. */
    fun upcoming(member: MemberEntity, now: Long = System.currentTimeMillis()): UpcomingBirthday? {
        if (member.birthDateMillis <= 0L || member.status == MemberStatus.DECEASED) return null
        val birth = Calendar.getInstance().apply { timeInMillis = member.birthDateMillis }
        val today = midnight(Calendar.getInstance().apply { timeInMillis = now })
        fun onYear(y: Int): Calendar = midnight(Calendar.getInstance().apply {
            clear(); set(Calendar.YEAR, y); set(Calendar.MONTH, birth.get(Calendar.MONTH)); set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.DAY_OF_MONTH, minOf(birth.get(Calendar.DAY_OF_MONTH), getActualMaximum(Calendar.DAY_OF_MONTH)))
        })
        var next = onYear(today.get(Calendar.YEAR))
        if (next.before(today)) next = onYear(today.get(Calendar.YEAR) + 1)
        val days = Math.round((next.timeInMillis - today.timeInMillis) / 86_400_000.0).toInt()
        return UpcomingBirthday(member, next.timeInMillis, days, next.get(Calendar.YEAR) - birth.get(Calendar.YEAR))
    }

    fun within(members: List<MemberEntity>, days: Int, now: Long = System.currentTimeMillis()) =
        members.mapNotNull { upcoming(it, now) }.filter { it.daysUntil in 0..days }.sortedBy { it.daysUntil }
}
