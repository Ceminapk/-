package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RegistryKind
import com.example.ui.components.CosmicGlassCard
import com.example.ui.components.FormDialog
import com.example.ui.components.OptionIcons
import com.example.ui.settings.L
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiScreen

/** A module that can sit in the quick-access panel: a main screen or a single journal. */
data class QuickItem(val key: String, val label: String, val icon: ImageVector, val color: Color, val screen: GabbaiScreen, val kind: RegistryKind? = null)

/** Splits quick-access cells evenly above and below the central Quick Neder button. */
object QuickLayout {
    fun split(n: Int): Int = (n + 1) / 2
}

object QuickAccess {
    val defaults = listOf("S:ALIYOT", "S:FINANCES", "S:MEMBERS", "S:KOLLEL", "S:TZEDAKAH", "S:CALENDAR")

    @androidx.compose.runtime.Composable
    fun catalog(): List<QuickItem> {
        val screens = listOf(
            QuickItem("S:ALIYOT", L("ალიები"), Icons.Default.MenuBook, CosmicCelestialGold, GabbaiScreen.ALIYOT),
            QuickItem("S:FINANCES", L("ფინანსები"), Icons.Default.Payments, CosmicStardustCyan, GabbaiScreen.FINANCES),
            QuickItem("S:MEMBERS", L("წევრები"), Icons.Default.People, CosmicAuroraBlue, GabbaiScreen.MEMBERS),
            QuickItem("S:KOLLEL", L("ქოლელი"), Icons.Default.School, CosmicNebulaPurple, GabbaiScreen.KOLLEL),
            QuickItem("S:TZEDAKAH", L("ცედაკა"), Icons.Default.VolunteerActivism, CosmicAlertRose, GabbaiScreen.TZEDAKAH),
            QuickItem("S:EVENTS", L("ღონისძიებები"), Icons.Default.Celebration, CosmicEmeraldSuccess, GabbaiScreen.EVENTS),
            QuickItem("S:YAHRZEITS", L("გარდაცვლილები"), Icons.Default.LocalFireDepartment, CosmicCelestialGold, GabbaiScreen.YAHRZEITS),
            QuickItem("S:REGISTERS", L("ჟურნალები"), Icons.Default.LibraryBooks, CosmicEmeraldSuccess, GabbaiScreen.REGISTERS),
            QuickItem("S:TOOLS", L("ხელსაწყოები"), Icons.Default.AutoStories, CosmicCelestialGold, GabbaiScreen.TOOLS),
            QuickItem("S:CALENDAR", L("კალენდარი"), Icons.Default.CalendarMonth, CosmicStardustCyan, GabbaiScreen.CALENDAR),
            QuickItem("S:SECURITY", L("უსაფრთხოება"), Icons.Default.Security, CosmicNebulaPurple, GabbaiScreen.SECURITY),
            QuickItem("S:SETTINGS", L("პარამეტრები"), Icons.Default.Settings, CosmicTextSecondary, GabbaiScreen.SETTINGS)
        )
        val journals = RegistryKind.values().map { k ->
            QuickItem("R:" + k.name, k.title, OptionIcons.registry(k.name), CosmicEmeraldSuccess, GabbaiScreen.REGISTERS, k)
        }
        return screens + journals
    }

    /** Keeps only known keys, in order, without duplicates. */
    fun sanitize(keys: List<String>, known: Set<String>): List<String> = keys.filter { it in known }.distinct()

    private fun prefs(c: Context) = c.getSharedPreferences("gabbai_quick", Context.MODE_PRIVATE)
    fun load(c: Context): List<String> = prefs(c).getString("items", null)?.split(",")?.filter { it.isNotBlank() } ?: defaults
    fun save(c: Context, keys: List<String>) = prefs(c).edit().putString("items", keys.joinToString(",")).apply()
    fun expanded(c: Context) = prefs(c).getBoolean("expanded", true)
    fun setExpanded(c: Context, v: Boolean) = prefs(c).edit().putBoolean("expanded", v).apply()
}

/** Collapsible, user-customizable quick-access panel for the main screen. */
@Composable
fun QuickAccessPanel(onNavigate: (GabbaiScreen) -> Unit, onQuickNeder: () -> Unit = {}) {
    val context = LocalContext.current
    val catalog = QuickAccess.catalog()
    val byKey = remember(catalog) { catalog.associateBy { it.key } }
    var keys by remember { mutableStateOf(QuickAccess.sanitize(QuickAccess.load(context), byKey.keys)) }
    var expanded by remember { mutableStateOf(QuickAccess.expanded(context)) }
    var managing by remember { mutableStateOf(false) }
    val arrow by animateFloatAsState(if (expanded) 180f else 0f, tween(300), label = "qa_arrow")

    CosmicGlassCard(Modifier.fillMaxWidth().testTag("quick_access_panel")) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                .clickable { expanded = !expanded; QuickAccess.setExpanded(context, expanded) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(L("სწრაფი წვდომის მოდულები"), style = MaterialTheme.typography.titleSmall, color = CosmicTextPrimary, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            IconButton(onClick = { managing = true }, modifier = Modifier.size(36.dp).testTag("quick_access_manage")) {
                Icon(Icons.Default.Tune, L("მართვა"), tint = CosmicCelestialGold)
            }
            Icon(Icons.Default.KeyboardArrowDown, null, tint = CosmicTextSecondary, modifier = Modifier.rotate(arrow))
        }
        val items = keys.mapNotNull { byKey[it] }
        val cells: List<QuickItem?> = items + listOf(null)
        val sides = cells.take(2)
        val rest = cells.drop(2)
        val (top, bottom) = QuickLayout.split(rest.size).let { rest.take(it) to rest.drop(it) }
        @Composable fun Cell(q: QuickItem?) {
            if (q == null) QuickActionIcon(Icons.Default.Add, L("დამატება"), CosmicTextSecondary, { managing = true }, Modifier.width(78.dp))
            else QuickActionIcon(q.icon, q.label, q.color, {
                if (q.kind != null) RegistryInbox.kind = q.kind
                onNavigate(q.screen)
            }, Modifier.width(78.dp))
        }
        @Composable fun Rows(list: List<QuickItem?>) {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                list.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { row.forEach { Cell(it) } }
                }
            }
        }
        val enter = fadeIn(tween(300)) + expandVertically(tween(300))
        val exit = fadeOut(tween(220)) + shrinkVertically(tween(260))
        AnimatedVisibility(expanded && top.isNotEmpty(), enter = enter, exit = exit) { Box(Modifier.padding(top = 10.dp)) { Rows(top) } }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(78.dp)) { if (expanded && sides.isNotEmpty()) Cell(sides[0]) }
            QuickNederRound(onQuickNeder)
            Box(Modifier.width(78.dp)) { if (expanded && sides.size > 1) Cell(sides[1]) }
        }
        AnimatedVisibility(expanded && bottom.isNotEmpty(), enter = enter, exit = exit) { Rows(bottom) }
    }

    if (managing) {
        var draft by remember { mutableStateOf(keys) }
        FormDialog(
            onDismissRequest = { managing = false },
            icon = { Icon(Icons.Default.Tune, null) },
            title = { Text(L("სწრაფი წვდომის მართვა"), fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(catalog, key = { it.key }) { q ->
                        val on = q.key in draft
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .clickable { draft = if (on) draft - q.key else draft + q.key }
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            com.example.ui.components.OptionBadge(q.icon, null, q.color, 30.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(q.label, color = CosmicTextPrimary, modifier = Modifier.weight(1f), maxLines = 2)
                            Checkbox(checked = on, onCheckedChange = { draft = if (on) draft - q.key else draft + q.key })
                        }
                    }
                }
            },
            confirmButton = { Button(onClick = { keys = draft; QuickAccess.save(context, draft); managing = false }, modifier = Modifier.testTag("quick_access_save")) { Text(L("შენახვა")) } },
            dismissButton = { TextButton(onClick = { draft = QuickAccess.defaults }) { Text(L("საწყისი")) } }
        )
    }
}

/** Central Quick Neder: a larger round button with its title below, in the soft dashboard palette. */
@Composable
private fun QuickNederRound(onClick: () -> Unit) {
    val accent = CosmicCelestialGold
    Column(horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(104.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 4.dp).testTag("quick_neder_button")) {
        Box(Modifier.size(68.dp).clip(androidx.compose.foundation.shape.CircleShape)
            .background(androidx.compose.ui.graphics.Brush.radialGradient(listOf(accent.copy(alpha = .26f), CosmicAuroraBlue.copy(alpha = .10f))))
            .border(1.2.dp, accent.copy(alpha = .45f), androidx.compose.foundation.shape.CircleShape),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Default.VolunteerActivism, L("სწრაფი ნედერი"), tint = accent.copy(alpha = .9f), modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(5.dp))
        Text(L("სწრაფი ნედერი"), color = CosmicTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1)
        Text("נדר", color = CosmicTextSecondary, fontSize = 10.sp, maxLines = 1)
    }
}
