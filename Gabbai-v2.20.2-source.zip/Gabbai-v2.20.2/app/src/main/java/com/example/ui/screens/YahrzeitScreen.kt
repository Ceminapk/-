package com.example.ui.screens

import com.example.ui.settings.shulName
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemberEntity
import com.example.data.model.MemberStatus
import com.example.data.model.YahrzeitEntity
import com.example.ui.calendar.HebDate
import com.example.ui.calendar.JewishCalendar
import com.example.ui.calendar.YahrzeitTools
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.CosmicGlassCard
import com.example.ui.components.DualDateField
import com.example.ui.components.DualDates
import com.example.ui.components.FormDialog
import com.example.ui.components.MemberField
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiViewModel

/** Deceased registry (database of the departed) + upcoming yahrzeit organizer. */
@Composable
fun YahrzeitScreen(viewModel: GabbaiViewModel, reminderDays: Int, modifier: Modifier = Modifier) {
    val state by viewModel.uiState.collectAsState()
    var editing by remember { mutableStateOf<YahrzeitEntity?>(null) }
    var addOpen by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<YahrzeitEntity?>(null) }
    var query by remember { mutableStateOf("") }
    val upcoming = remember(state.yahrzeits, reminderDays) { YahrzeitTools.within(state.yahrzeits, reminderDays) }
    val registry = remember(state.yahrzeits, query) {
        state.yahrzeits.filter { query.isBlank() || it.deceasedName.contains(query, true) || it.hebrewName.contains(query, true) || it.relatedMemberName.contains(query, true) }
            .sortedBy { it.deceasedName.lowercase() }
    }
    Box(modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp).testTag("deceased_screen"), contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                CosmicGlassCard(Modifier.fillMaxWidth()) {
                    Text(L("მოახლოებული იორცაიტები"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                    Text(Lf("ნაჩვენებია მომდევნო {0} დღე", reminderDays), color = CosmicTextSecondary)
                }
            }
            if (upcoming.isEmpty()) item { Text(L("ამ პერიოდში იორცაიტი არ არის"), color = CosmicTextSecondary) }
            items(upcoming, key = { "u" + it.item.id }) { u ->
                CosmicGlassCard(Modifier.fillMaxWidth(), borderColor = CosmicCelestialGold.copy(alpha = .5f)) {
                    Text(u.item.deceasedName, fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                    if (u.item.relatedMemberName.isNotBlank()) Text(listOf(u.item.relationship, u.item.relatedMemberName).filter { it.isNotBlank() }.joinToString(" • "), color = CosmicTextSecondary)
                    Text(DualDates.gregorianText(u.dateMillis) + " • " + Lf("{0} დღეში", u.daysUntil), color = CosmicCelestialGold)
                    val phone = state.members.firstOrNull { it.id == u.item.relatedMemberId || it.fullName.equals(u.item.relatedMemberName, true) }?.phone.orEmpty()
                    if (phone.isNotBlank()) Row {
                        val ctx = androidx.compose.ui.platform.LocalContext.current
                        val shul = com.example.ui.settings.LocalAppSettings.current.shulName()
                        val msg = com.example.ui.share.Messages.yahrzeit(u.item, u.dateMillis, u.daysUntil, shul)
                        OutlinedButton(onClick = { com.example.ui.share.Share.whatsapp(ctx, phone, msg) }) { Text("WhatsApp") }
                        Spacer(Modifier.width(6.dp))
                        OutlinedButton(onClick = { com.example.ui.share.Share.sms(ctx, phone, msg) }) { Text("SMS") }
                    }
                }
            }
            item {
                Spacer(Modifier.height(6.dp))
                Text(Lf("გარდაცვლილთა ბაზა ({0})", state.yahrzeits.size), fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 17.sp)
                OutlinedTextField(query, { query = it }, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text(L("ძებნა სახელით")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            if (registry.isEmpty()) item { Text(L("ჩანაწერი არ მოიძებნა"), color = CosmicTextSecondary) }
            items(registry, key = { it.id }) { item ->
                CosmicGlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(item.deceasedName + " ז״ל", fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                            if (item.hebrewName.isNotBlank()) Text(item.hebrewName, color = CosmicTextSecondary)
                            Text(L("გარდაცვალება: ") + DualDates.gregorianText(item.deathDateMillis), color = CosmicTextSecondary, fontSize = 13.sp)
                            val hd = HebDate(0, item.hebrewMonth, item.hebrewDay, false)
                            Text("${item.hebrewDay} ${JewishCalendar.monthNameKa(hd)} • ${JewishCalendar.gematria(item.hebrewDay)} ${JewishCalendar.monthNameHe(hd)}", color = CosmicCelestialGold, fontSize = 13.sp)
                            if (item.relatedMemberName.isNotBlank()) Text(listOf(item.relationship, item.relatedMemberName).filter { it.isNotBlank() }.joinToString(" • "), color = CosmicTextSecondary, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (item.cemetery.isNotBlank()) Text(L("სასაფლაო: ") + item.cemetery + if (item.plot.isNotBlank()) " • " + L("ნაკვეთი: ") + item.plot else "", color = CosmicTextSecondary, fontSize = 13.sp)
                            if (item.notes.isNotBlank()) Text(item.notes, color = CosmicTextMuted, fontSize = 12.sp)
                        }
                        IconButton(onClick = { editing = item }) { Icon(Icons.Default.Edit, L("რედაქტირება"), tint = CosmicAuroraBlue) }
                        IconButton(onClick = { toDelete = item }) { Icon(Icons.Default.DeleteOutline, L("წაშლა"), tint = CosmicAlertRose) }
                    }
                }
            }
        }
        com.example.ui.components.DockedAddButton(tag = "fab_add_deceased", onClick = { addOpen = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 84.dp, end = 20.dp).testTag("fab_add_deceased"), containerColor = CosmicCelestialGold, contentColor = CosmicOnAccent) { Icon(Icons.Default.Add, L("გარდაცვლილის დამატება")) }
    }
    if (addOpen || editing != null) DeceasedDialog(
        initial = editing,
        members = state.members.filter { it.status != MemberStatus.DECEASED },
        onAddMember = viewModel::quickAddMember,
        onDismiss = { addOpen = false; editing = null },
        onSave = { viewModel.saveYahrzeit(it); addOpen = false; editing = null }
    )
    toDelete?.let { d -> ConfirmDeleteDialog(d.deceasedName, onDismiss = { toDelete = null }, onConfirm = { viewModel.deleteYahrzeit(d.id); toDelete = null }) }
}

@Composable
private fun DeceasedDialog(initial: YahrzeitEntity?, members: List<MemberEntity>, onAddMember: (String) -> Unit, onDismiss: () -> Unit, onSave: (YahrzeitEntity) -> Unit) {
    var deceased by remember { mutableStateOf(initial?.deceasedName ?: "") }
    var hebrew by remember { mutableStateOf(initial?.hebrewName ?: "") }
    var member by remember { mutableStateOf(initial?.relatedMemberName ?: "") }
    var relationship by remember { mutableStateOf(initial?.relationship ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var cemetery by remember { mutableStateOf(initial?.cemetery ?: "") }
    var plot by remember { mutableStateOf(initial?.plot ?: "") }
    var date by remember { mutableStateOf(initial?.deathDateMillis ?: System.currentTimeMillis()) }
    var afterSunset by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }
    FormDialog(
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false), modifier = Modifier.fillMaxWidth(.94f),
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) L("გარდაცვლილის დამატება") else L("გარდაცვლილის რედაქტირება"), fontWeight = FontWeight.Bold) },
        text = { LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            item {
                OutlinedTextField(deceased, { deceased = it }, label = { Text(L("გარდაცვლილის სრული სახელი")) }, singleLine = true, isError = error && deceased.isBlank(), modifier = Modifier.fillMaxWidth().testTag("field_deceased_name"))
            }
            item { OutlinedTextField(hebrew, { hebrew = it }, label = { Text(L("ებრაული სახელი")) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { DualDateField(L("გარდაცვალების თარიღი"), date, { date = it }) }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(afterSunset, { afterSunset = it })
                    Text(L("გარდაიცვალა მზის ჩასვლის შემდეგ (ებრაული თარიღი +1 დღე)"), color = CosmicTextSecondary, fontSize = 13.sp)
                }
            }
            item { MemberField(L("ახლობელი / შეტყობინების მიმღები"), member, { member = it }, members.map { it.fullName }, onAddMember) }
            item { OutlinedTextField(relationship, { relationship = it }, label = { Text(L("ნათესაობა")) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(cemetery, { cemetery = it }, label = { Text(L("სასაფლაო")) }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("field_cemetery")) }
            item { OutlinedTextField(plot, { plot = it }, label = { Text(L("ნაკვეთი / რიგი / საფლავის ნომერი")) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(notes, { notes = it }, label = { Text(L("შენიშვნა")) }, modifier = Modifier.fillMaxWidth()) }
        } },
        confirmButton = { Button(onClick = {
            if (deceased.isBlank()) { error = true; return@Button }
            val h = DualDates.hebrewOf(if (afterSunset) date + 86_400_000L else date)
            val related = members.firstOrNull { it.fullName.equals(member.trim(), ignoreCase = true) }
            val base = initial ?: YahrzeitEntity(deceasedName = "", relatedMemberId = 0, relatedMemberName = "", deathDateMillis = date, hebrewMonth = h.month, hebrewDay = h.day)
            onSave(base.copy(deceasedName = deceased.trim(), hebrewName = hebrew.trim(), relatedMemberId = related?.id ?: 0L, relatedMemberName = member.trim(),
                relationship = relationship.trim(), deathDateMillis = date, hebrewMonth = h.month, hebrewDay = h.day, notes = notes.trim(), cemetery = cemetery.trim(), plot = plot.trim()))
        }, modifier = Modifier.testTag("btn_save_deceased")) { Text(L("შენახვა")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L("გაუქმება")) } }
    )
}
