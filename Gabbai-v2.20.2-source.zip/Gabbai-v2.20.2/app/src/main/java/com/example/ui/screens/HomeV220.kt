package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.calendar.CalendarPrefs
import com.example.ui.calendar.Holiday
import com.example.ui.calendar.JewishCalendar
import com.example.ui.settings.L
import com.example.ui.theme.*
import java.util.Calendar
import java.util.GregorianCalendar

/** Pure rules for the v2.20 home screen. */
object HomeRules {
    /** Emoji for a holiday, chosen by its Georgian key. */
    fun holidayEmoji(ka: String): String = when {
        ka.contains("ხანუქა") -> "🕎"
        ka.contains("ფურიმ") || ka.contains("პურიმ") || ka.contains("ესთერი") -> "🎭"
        ka.contains("პესახ") -> "🍷"
        ka.contains("შავუყოთ") || ka.contains("სიმხათ თორა") -> "📜"
        ka.contains("როშ ჰაშანა") -> "📯"
        ka.contains("კიპური") || ka.contains("ჰაშოა") -> "🕯️"
        ka.contains("სუქოთ") || ka.contains("ჰოშანა") -> "🌿"
        ka.contains("ტუ ბიშვატი") -> "🌳"
        ka.contains("ლაგ ბაომერი") -> "🔥"
        ka.contains("ჰააცმაუთი") || ka.contains("იერუშალაიმი") -> "🇮🇱"
        ka.contains("ტუ ბეავი") -> "💞"
        ka.contains("თიშა ბეავი") || ka.contains("ცომ") || ka.contains("ასარა") || ka.contains("შივა ასარ") -> "🕍"
        ka.contains("როშ ხოდეში") -> "🌙"
        else -> "✡️"
    }

    /** Shabbat times on the dome: every day, or only Wednesday–Saturday. */
    fun showShabbatTimes(daily: Boolean, weekday: Int): Boolean =
        daily || weekday == Calendar.WEDNESDAY || weekday == Calendar.THURSDAY || weekday == Calendar.FRIDAY || weekday == Calendar.SATURDAY
}

/** The next upcoming holiday (Rosh Chodesh only if nothing else is near). */
@Composable
fun rememberNextHoliday(): Holiday? {
    val city = CalendarPrefs.city
    val c = Calendar.getInstance()
    val key = c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    return remember(city, key) {
        runCatching {
            val g = GregorianCalendar(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
            var monthly: Holiday? = null
            repeat(90) {
                val di = JewishCalendar.day(g.get(Calendar.YEAR), g.get(Calendar.MONTH) + 1, g.get(Calendar.DAY_OF_MONTH), city)
                di.holidays.firstOrNull { it.ka != "როშ ხოდეში" }?.let { return@runCatching it }
                if (monthly == null) monthly = di.holidays.firstOrNull()
                g.add(Calendar.DAY_OF_MONTH, 1)
            }
            monthly
        }.getOrNull()
    }
}

/** Ticker: holiday icon (left) · zmanim marquee (centre) · wall screen (right). */
@Composable
fun ZmanimTickerBar(text: String, onHolidays: () -> Unit, onZmanim: () -> Unit, onKiosk: () -> Unit) {
    val next = rememberNextHoliday()
    Surface(color = CosmicCelestialGold.copy(alpha = .14f), shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CosmicCelestialGold.copy(alpha = .4f)), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            TickerSideButton(onHolidays, "ticker_holidays") {
                Text(next?.let { HomeRules.holidayEmoji(it.ka) } ?: "✡️", fontSize = 18.sp)
            }
            Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).clickable(onClick = onZmanim).testTag("zmanim_ticker")) {
                Text(text, color = CosmicTextPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1,
                    modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE).padding(horizontal = 8.dp, vertical = 7.dp))
            }
            TickerSideButton(onKiosk, "ticker_kiosk") {
                Icon(Icons.Default.Tv, L("კედლის ეკრანი"), tint = CosmicCelestialGold, modifier = Modifier.size(19.dp))
            }
        }
    }
}

@Composable
private fun TickerSideButton(onClick: () -> Unit, tag: String, content: @Composable () -> Unit) {
    Box(Modifier.size(36.dp).clip(CircleShape).background(CosmicCelestialGold.copy(alpha = .18f))
        .border(1.dp, CosmicCelestialGold.copy(alpha = .45f), CircleShape).clickable(onClick = onClick).testTag(tag),
        contentAlignment = Alignment.Center) { content() }
}

/** Candle lighting and Shabbat/holiday end, shown inside the dome banner. */
@Composable
fun HeroShabbatTimes(daily: Boolean) {
    val c = Calendar.getInstance()
    if (!HomeRules.showShabbatTimes(daily, c.get(Calendar.DAY_OF_WEEK))) return
    val city = CalendarPrefs.city
    val y = c.get(Calendar.YEAR); val m = c.get(Calendar.MONTH) + 1; val d = c.get(Calendar.DAY_OF_MONTH)
    val period = remember(city, y, m, d) { runCatching { JewishCalendar.nextRestPeriod(y, m, d, city) }.getOrNull() } ?: return
    val (start, end) = period
    val wd = listOf("კვირა", "ორშაბათი", "სამშაბათი", "ოთხშაბათი", "ხუთშაბათი", "პარასკევი", "შაბათი")
    val light = if (start === end) L("ახლა მიმდინარეობს") else "${L(wd[start.weekday - 1])} ${formatTime(start.candleLighting ?: start.tzeit, city)}"
    val out = end?.let { "${L(wd[it.weekday - 1])} ${formatTime(it.havdalah, city)}" } ?: "—"
    Row(Modifier.fillMaxWidth().testTag("hero_shabbat_times"), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        HeroTime("🕯️", light)
        Box(Modifier.padding(horizontal = 10.dp).size(3.dp).clip(CircleShape).background(CosmicCelestialGold.copy(alpha = .6f)))
        HeroTime("✨", out)
    }
}

@Composable
private fun HeroTime(mark: String, value: String) {
    Row(Modifier.clip(RoundedCornerShape(50)).background(CosmicDeepSpace.copy(alpha = .35f))
        .border(0.6.dp, CosmicCelestialGold.copy(alpha = .3f), RoundedCornerShape(50)).padding(horizontal = 9.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(mark, fontSize = 10.sp)
        Spacer(Modifier.width(4.dp))
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = CosmicTextSecondary, letterSpacing = 0.3.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
