package com.example.data.sync

import android.content.Context
import androidx.room.withTransaction
import com.example.data.db.AppDatabase
import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Roles decide which sections a gabbai may read and write (mirrors the server rules). */
object SyncRoles {
    val all = listOf("owner", "gabbai", "deputy", "treasurer")
    fun canRead(role: String?, section: String) = when (role) {
        "owner", "gabbai" -> section in sections
        "treasurer" -> section in setOf("finance", "members")
        "deputy" -> section in setOf("aliyot", "members")
        else -> false
    }
    fun canWrite(role: String?, section: String) = when (role) {
        "owner", "gabbai" -> section in sections
        "treasurer" -> section == "finance"
        "deputy" -> section == "aliyot"
        else -> false
    }
    val sections = listOf("members", "finance", "aliyot", "registry")
}

data class MembersSection(val members: List<MemberEntity> = emptyList(), val yahrzeits: List<YahrzeitEntity> = emptyList())
data class FinanceSection(val transactions: List<TransactionEntity> = emptyList(), val tzedakah: List<TzedakahEntity> = emptyList(),
                          val needy: List<NeedyBeneficiaryEntity> = emptyList(), val kollelStudents: List<KollelStudentEntity> = emptyList(),
                          val kollelAttendance: List<KollelAttendanceEntity> = emptyList())
data class AliyotSection(val aliyot: List<AliyahEntity> = emptyList(), val events: List<SynagogueEventEntity> = emptyList())
data class RegistrySection(val registry: List<RegistryEntity> = emptyList())

data class TeamMember(val userId: String, val email: String, val role: String)
data class Shul(val id: String, val name: String, val role: String)

class SyncException(message: String) : Exception(message)

/** Talks to the online server: password sign-in, synagogue team with roles, versioned section sync. */
class CloudSync(private val context: Context) {
    companion object {
        const val URL_BASE = "https://pgrsfaxkiualnsikzwme.supabase.co"
        const val KEY = "sb_publishable_tyKGwYVImKO9OnCrubpJiw_FZtVLcB8"
    }
    private val prefs = context.getSharedPreferences("gabbai_sync", Context.MODE_PRIVATE)
    init {
        val oldShul = prefs.getString("shul", "").orEmpty()
        if (!prefs.contains("local_shul") && oldShul.isNotBlank()) prefs.edit().putString("local_shul", oldShul).commit()
    }
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    val email: String get() = prefs.getString("email", "") ?: ""
    val signedIn: Boolean get() = !prefs.getString("refresh", "").isNullOrBlank()
    var shulId: String
        get() = prefs.getString("shul", "") ?: ""
        set(v) { prefs.edit().putString("shul", v).apply() }
    fun localVersion(section: String) = prefs.getInt("v_${shulId}_$section", 0)
    private fun setLocalVersion(section: String, v: Int) = prefs.edit().putInt("v_${shulId}_$section", v).apply()
    val lastSync: Long get() = prefs.getLong("last_sync", 0L)

    private fun http(method: String, path: String, body: String?, auth: Boolean = true): String {
        val c = URL(URL_BASE + path).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("apikey", KEY)
        c.setRequestProperty("Content-Type", "application/json")
        if (auth) c.setRequestProperty("Authorization", "Bearer " + token())
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) } }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(text).let { it.optString("message").ifBlank { it.optString("msg") }.ifBlank { it.optString("error_description") } } }.getOrNull()
            throw SyncException(msg?.ifBlank { null } ?: "HTTP $code")
        }
        return text
    }

    private fun saveSession(j: JSONObject) {
        prefs.edit().putString("access", j.getString("access_token")).putString("refresh", j.getString("refresh_token"))
            .putLong("expires", System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000 - 60_000)
            .putString("email", j.optJSONObject("user")?.optString("email") ?: email).apply()
    }

    private fun token(): String {
        if (System.currentTimeMillis() > prefs.getLong("expires", 0)) {
            val r = prefs.getString("refresh", "") ?: ""
            if (r.isBlank()) throw SyncException("not signed in")
            saveSession(JSONObject(http("POST", "/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", r).toString(), auth = false)))
        }
        return prefs.getString("access", "") ?: ""
    }

    /** Returns true when signed in, false when the email must be confirmed first. */
    suspend fun signUp(email: String, password: String): Boolean = withContext(Dispatchers.IO) {
        val j = JSONObject(http("POST", "/auth/v1/signup", JSONObject().put("email", email.trim()).put("password", password).toString(), auth = false))
        if (j.has("access_token")) { saveSession(j); true } else false
    }

    suspend fun signIn(email: String, password: String) = withContext(Dispatchers.IO) {
        saveSession(JSONObject(http("POST", "/auth/v1/token?grant_type=password", JSONObject().put("email", email.trim()).put("password", password).toString(), auth = false)))
    }

    suspend fun resetPassword(email: String) = withContext(Dispatchers.IO) {
        http("POST", "/auth/v1/recover", JSONObject().put("email", email.trim()).toString(), auth = false)
    }

    fun signOut() {
        prefs.edit().remove("access").remove("refresh").remove("expires").remove("email").apply()
    }
    fun speechToken(): String = token()
    private fun digest(body: String) = java.security.MessageDigest.getInstance("SHA-256").digest(body.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun empty(section: String, body: String): Boolean {
        val json = JSONObject(body)
        return json.keys().asSequence().all { key -> json.optJSONArray(key)?.length() == 0 }
    }
    private fun rememberBaseline(section: String, body: String, version: Int) {
        prefs.edit().putInt("v_${shulId}_$section", version).putString("sha_${shulId}_$section", digest(body))
            .remove("h_${shulId}_$section").putString("local_shul", shulId).commit()
    }

    private fun rpc(name: String, args: JSONObject) = http("POST", "/rest/v1/rpc/$name", args.toString())

    suspend fun myShuls(): List<Shul> = withContext(Dispatchers.IO) {
        val uid = JSONObject(http("GET", "/auth/v1/user", null)).getString("id")
        val a = JSONArray(http("GET", "/rest/v1/synagogue_users?select=role,synagogue_id,synagogues(name)&user_id=eq.$uid", null))
        (0 until a.length()).map { a.getJSONObject(it) }.map { Shul(it.getString("synagogue_id"), it.optJSONObject("synagogues")?.optString("name") ?: "", it.getString("role")) }
    }

    suspend fun createShul(name: String): String = withContext(Dispatchers.IO) { rpc("create_synagogue", JSONObject().put("_name", name)).trim('"') }
    suspend fun createInvite(role: String): String = withContext(Dispatchers.IO) { rpc("create_invite", JSONObject().put("_sid", shulId).put("_role", role)).trim('"') }
    suspend fun join(code: String): String = withContext(Dispatchers.IO) { rpc("join_synagogue", JSONObject().put("_code", code)).trim('"') }
    suspend fun setRole(userId: String, role: String) = withContext(Dispatchers.IO) { rpc("set_member_role", JSONObject().put("_sid", shulId).put("_user", userId).put("_role", role)) }

    suspend fun team(): List<TeamMember> = withContext(Dispatchers.IO) {
        val a = JSONArray(http("GET", "/rest/v1/synagogue_users?select=user_id,email,role&synagogue_id=eq.$shulId&order=joined_at", null))
        (0 until a.length()).map { a.getJSONObject(it) }.map { TeamMember(it.getString("user_id"), it.optString("email"), it.getString("role")) }
    }

    private suspend fun local(section: String): String {
        val dao = AppDatabase.getDatabase(context).gabbaiDao()
        return when (section) {
            "members" -> moshi.adapter(MembersSection::class.java).toJson(MembersSection(dao.getAllMembers().first(), dao.getAllYahrzeits().first()))
            "finance" -> moshi.adapter(FinanceSection::class.java).toJson(FinanceSection(dao.getAllTransactions().first(), dao.getAllTzedakah().first(),
                dao.getAllNeedyBeneficiaries().first(), dao.getAllKollelStudents().first(), dao.getAllAttendance().first()))
            "aliyot" -> moshi.adapter(AliyotSection::class.java).toJson(AliyotSection(dao.getAllAliyot().first(), dao.getAllEvents().first()))
            else -> moshi.adapter(RegistrySection::class.java).toJson(RegistrySection(dao.getAllRegistry().first()))
        }
    }

    private suspend fun apply(section: String, json: String, expected: String): String? {
        val db = AppDatabase.getDatabase(context); val dao = db.gabbaiDao()
        return db.withTransaction {
            if (digest(local(section)) != expected) return@withTransaction null
            when (section) {
                "members" -> moshi.adapter(MembersSection::class.java).fromJson(json)?.let { s ->
                    dao.clearMembers(); dao.clearYahrzeits()
                    s.members.forEach { dao.insertMember(it) }; s.yahrzeits.forEach { dao.insertYahrzeit(it) } }
                "finance" -> moshi.adapter(FinanceSection::class.java).fromJson(json)?.let { s ->
                    dao.clearTransactions(); dao.clearTzedakah()
                    dao.clearNeedy(); dao.clearKollelStudents()
                    dao.clearAttendance()
                    s.transactions.forEach { dao.insertTransaction(it) }; s.tzedakah.forEach { dao.insertTzedakah(it) }; s.needy.forEach { dao.insertNeedyBeneficiary(it) }
                    s.kollelStudents.forEach { dao.insertKollelStudent(it) }; s.kollelAttendance.forEach { dao.insertAttendance(it) } }
                "aliyot" -> moshi.adapter(AliyotSection::class.java).fromJson(json)?.let { s ->
                    dao.clearAliyot(); dao.clearEvents()
                    s.aliyot.forEach { dao.insertAliyah(it) }; s.events.forEach { dao.insertEvent(it) } }
                else -> moshi.adapter(RegistrySection::class.java).fromJson(json)?.let { s ->
                    dao.clearRegistry(); s.registry.forEach { dao.insertRegistry(it) } }
            }
            local(section)
        }
    }

    data class Report(val pulled: List<String>, val pushed: List<String>, val conflicts: List<String>)

    /**
     * Two-way sync. Newer server sections replace local ones; sections changed only here are uploaded
     * when the role may write them. Server versions guard against overwriting a colleague's work.
     */
    suspend fun sync(role: String, pushLocal: Boolean): Report = withContext(Dispatchers.IO) {
        if (shulId.isBlank()) throw SyncException("ჯერ აირჩიეთ სინაგოგა.")
        val actualRole = myShuls().firstOrNull { it.id == shulId }?.role ?: throw SyncException("ამ სინაგოგაზე წვდომა აღარ გაქვთ.")
        val bound = prefs.getString("local_shul", "").orEmpty()
        if (bound.isNotBlank() && bound != shulId && SyncRoles.sections.any { !empty(it, local(it)) })
            throw SyncException("ჯერ შეინახეთ სხვა სინაგოგის მონაცემების სარეზერვო ასლი და გაასუფთავეთ ადგილობრივი ბაზა.")
        val a = JSONArray(http("GET", "/rest/v1/synagogue_data?select=section,version,data&synagogue_id=eq.$shulId", null))
        val server = (0 until a.length()).map { a.getJSONObject(it) }.associateBy { it.getString("section") }
        val pulled = mutableListOf<String>(); val pushed = mutableListOf<String>(); val conflicts = mutableListOf<String>()
        for (s in SyncRoles.sections) {
            if (!SyncRoles.canRead(actualRole, s)) continue
            val row = server[s]
            val sv = row?.optInt("version") ?: 0
            val body = local(s); val hash = digest(body)
            val sha = prefs.getString("sha_${shulId}_$s", null)
            val legacyKey = "h_${shulId}_$s"
            val baselineMatches = when {
                sha != null -> sha == hash
                prefs.contains(legacyKey) -> prefs.getInt(legacyKey, 0) == body.hashCode()
                else -> empty(s, body)
            }
            when (SyncDecision.action(sv, localVersion(s), row != null, !baselineMatches, pushLocal && SyncRoles.canWrite(actualRole, s))) {
                "conflict" -> conflicts += s
                "pull" -> {
                    val applied = row?.let { apply(s, it.get("data").toString(), hash) }
                    if (applied != null) {
                        rememberBaseline(s, applied, sv); pulled += s
                    } else conflicts += s
                }
                "push" -> try {
                    val nv = rpc("push_section", JSONObject().put("_sid", shulId).put("_section", s).put("_data", JSONObject(body)).put("_base_version", localVersion(s))).trim().toInt()
                    rememberBaseline(s, body, nv); pushed += s
                } catch (e: SyncException) {
                    if (e.message?.contains("conflict", true) == true) conflicts += s else throw e
                }
            }
        }
        prefs.edit().putLong("last_sync", System.currentTimeMillis()).apply()
        Report(pulled, pushed, conflicts)
    }
}

object SyncDecision {
    fun action(server: Int, local: Int, exists: Boolean, dirty: Boolean, mayPush: Boolean): String = when {
        exists && server != local && dirty -> "conflict"
        exists && server > local -> "pull"
        exists && server < local -> "conflict"
        mayPush && (!exists || dirty) -> "push"
        else -> "none"
    }
}
