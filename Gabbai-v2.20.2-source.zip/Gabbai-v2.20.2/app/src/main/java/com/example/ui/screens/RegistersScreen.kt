package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.settings.*
import com.example.ui.share.Messages
import com.example.ui.share.Share
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiViewModel
import com.example.ui.voice.rememberSpeechInput

/** Every smaller synagogue register in one place: pick a journal on top, its records below. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RegistersScreen(viewModel: GabbaiViewModel, initialKind: RegistryKind = RegistryKind.MIKVEH, modifier: Modifier = Modifier) {
    val state by viewModel.uiState.collectAsState()
    val settings = LocalAppSettings.current
    val context = LocalContext.current
    var kind by remember { mutableStateOf(RegistryInbox.kind ?: initialKind) }
    LaunchedEffect(RegistryInbox.kind) { RegistryInbox.kind?.let { kind = it; RegistryInbox.kind = null } }
    var editing by remember { mutableStateOf<RegistryEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    var paying by remember { mutableStateOf<RegistryEntity?>(null) }
    var toDelete by remember { mutableStateOf<RegistryEntity?>(null) }
    var tehillim by remember { mutableStateOf<RegistryEntity?>(null) }
    var query by remember { mutableStateOf("") }
    var showDone by remember { mutableStateOf(true) }
    var prayers by remember { mutableStateOf(false) }
    val conflicts = remember(state.registry) { V219Rules.hallConflicts(state.registry.filter { it.status == RegistryStatus.OPEN }) }
    val list = remember(state.registry, kind, query, showDone) {
        state.registry.filter { it.kind == kind.name && (showDone || it.status == RegistryStatus.OPEN) &&
            (query.isBlank() || listOf(it.title, it.memberName, it.details, it.extra, it.phone).any { f -> f.contains(query, true) }) }
    }
    val livingMembers = state.members.filter { it.status != MemberStatus.DECEASED }
    Box(modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp).testTag("registers_screen"), contentPadding = PaddingValues(top = 10.dp, bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                AppDropdown(label = L("ჟურნალი"), value = kind, options = RegistryKind.values().toList(), optionLabel = { it.title },
                    onSelected = { kind = it }, modifier = Modifier.testTag("registry_kinds"))
            }
            item { RegistrySummary(kind, state.registry.filter { it.kind == kind.name }, settings) }
            item {
                OutlinedTextField(query, { query = it }, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text(L("ძებნა")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(showDone, { showDone = it }); Text(Lf("აჩვენე „{0}“ ჩანაწერებიც", L(kind.doneLabel)), color = CosmicTextSecondary, fontSize = 13.sp)
                }
            }
            if (list.isEmpty()) item { Text(L("ჩანაწერი ჯერ არ არის. დააჭირეთ „+“ ღილაკს."), color = CosmicTextSecondary) }
            items(list, key = { it.id }) { e ->
                RegistryCard(e, kind, settings,
                    onEdit = { editing = e }, onDelete = { toDelete = e }, onPay = { paying = e },
                    onToggle = { viewModel.saveRegistry(e.copy(status = if (e.status == RegistryStatus.OPEN) RegistryStatus.DONE else RegistryStatus.OPEN), postToFinance = e.status == RegistryStatus.OPEN) },
                    onCall = { Share.call(context, e.phone) },
                    onWhatsapp = { Share.whatsapp(context, e.phone, reminderText(e, kind, settings)) },
                    onSms = { Share.sms(context, e.phone, reminderText(e, kind, settings)) },
                    onCard = { Share.image(context, Messages.thankYouCard(e.memberName.ifBlank { e.title }, RegistryRules.total(e), e.currency, e.title, e.dateMillis, settings.shulName()), "thanks-${e.id}",
                        Messages.thankYou(e.memberName.ifBlank { e.title }, RegistryRules.total(e), e.currency, e.title, e.dateMillis, settings.shulName())) },
                    onTehillim = { tehillim = e },
                    conflict = e.id in conflicts,
                    onMaps = if (kind == RegistryKind.CEMETERY) V219Rules.parseGps(e.extra)?.let { (la, ln) -> { Share.url(context, V219Rules.mapsUrl(la, ln)) } } else null,
                    onPrayers = if (kind == RegistryKind.CEMETERY) ({ prayers = true }) else null,
                    onGroup = if (kind == RegistryKind.LOST_FOUND && e.status == RegistryStatus.OPEN) ({
                        val caption = Lf("სინაგოგაში ნაპოვნია: {0}. {1} პატრონმა მიმართოს გაბაის. {2}", e.title, if (e.extra.isNotBlank()) "(" + e.extra + ")" else "", settings.shulName())
                        val bmp = MemberPhotos.decode(e.photoBase64)
                        if (bmp != null) Share.image(context, bmp, "lost-${e.id}", caption) else Share.text(context, caption)
                    }) else null)
            }
        }
        DockedAddButton(tag = "fab_add_registry", onClick = { adding = true }, containerColor = CosmicCelestialGold, contentColor = CosmicOnAccent) { Icon(Icons.Default.Add, L("დამატება")) }
    }
    if (adding || editing != null) RegistryDialog(kind, editing, livingMembers.map { it.fullName }, viewModel::quickAddMember,
        phoneOf = { n -> livingMembers.firstOrNull { it.fullName.equals(n, true) }?.phone.orEmpty() },
        onDismiss = { adding = false; editing = null }, onSave = { viewModel.saveRegistry(it); adding = false; editing = null })
    paying?.let { e -> PaymentDialog(e, onDismiss = { paying = null }, onPay = { viewModel.payRegistry(e, it); paying = null }) }
    toDelete?.let { e -> ConfirmDeleteDialog(e.title, onDismiss = { toDelete = null }, onConfirm = { viewModel.deleteRegistry(e.id); toDelete = null }) }
    if (prayers) MemorialPrayersDialog { prayers = false }
    tehillim?.let { e -> TehillimDialog(e, livingMembers, settings, onDismiss = { tehillim = null }) }
}

/** Lets other screens (dashboard, assistant) open a specific journal. */
object RegistryInbox { var kind by mutableStateOf<RegistryKind?>(null) }

fun iconOf(k: RegistryKind) = when (k) {
    RegistryKind.MIKVEH -> Icons.Default.Water
    RegistryKind.GEMACH -> Icons.Default.Handshake
    RegistryKind.INSTALLMENT -> Icons.Default.CalendarViewMonth
    RegistryKind.AUCTION -> Icons.Default.Gavel
    RegistryKind.UTILITY -> Icons.Default.Bolt
    RegistryKind.ORDER -> Icons.Default.ShoppingBasket
    RegistryKind.HANUKKAH -> Icons.Default.LocalFireDepartment
    RegistryKind.KAPAROT -> Icons.Default.VolunteerActivism
    RegistryKind.CHAMETZ -> Icons.Default.BakeryDining
    RegistryKind.GUESTS -> Icons.Default.Hotel
    RegistryKind.TEHILLIM -> Icons.Default.MenuBook
    RegistryKind.EMERGENCY -> Icons.Default.LocalHospital
    RegistryKind.TORAH_DEFECT -> Icons.Default.ReportProblem
    RegistryKind.LOST_FOUND -> Icons.Default.Inventory
    RegistryKind.LIBRARY -> Icons.Default.LocalLibrary
    RegistryKind.KEYS -> Icons.Default.Key
    RegistryKind.HISTORY -> Icons.Default.HistoryEdu
    RegistryKind.VOICE_MEMO -> Icons.Default.KeyboardVoice
    RegistryKind.TORAH_PASSPORT -> Icons.Default.Badge
    RegistryKind.PUSHKE -> Icons.Default.Savings
    RegistryKind.PAROCHET -> Icons.Default.Checkroom
    RegistryKind.GENIZAH -> Icons.Default.Archive
    RegistryKind.VOLUNTEER -> Icons.Default.Groups
    RegistryKind.KIDDUSH_CAL -> Icons.Default.WineBar
    RegistryKind.BIKUR_CHOLIM -> Icons.Default.Healing
    RegistryKind.NEW_FAMILY -> Icons.Default.FamilyRestroom
    RegistryKind.RAV_QUESTION -> Icons.Default.QuestionAnswer
    RegistryKind.PROGRAM -> Icons.Default.School
    RegistryKind.FUND -> Icons.Default.AccountBalance
    RegistryKind.MAINTENANCE -> Icons.Default.Build
    RegistryKind.GOAL -> Icons.Default.Flag
    RegistryKind.MEZUZAH -> Icons.Default.DoorFront
    RegistryKind.MAASER -> Icons.Default.Percent
    RegistryKind.CALL_CHAIN -> Icons.Default.Campaign
    RegistryKind.MINYAN -> Icons.Default.Star
    RegistryKind.ALIYAH_PLAN -> Icons.Default.EventSeat
    RegistryKind.SEATING -> Icons.Default.Chair
    RegistryKind.MEMO -> Icons.Default.StickyNote2
    RegistryKind.BAR_MITZVAH -> Icons.Default.Cake
    RegistryKind.VIP_GUEST -> Icons.Default.WorkspacePremium
    RegistryKind.AUDIO_GUIDE -> Icons.Default.Speaker
    RegistryKind.SUPPLIES -> Icons.Default.Inventory2
    RegistryKind.TIMERS -> Icons.Default.Timer
    RegistryKind.HALL_BOOKING -> Icons.Default.MeetingRoom
    RegistryKind.CEMETERY -> Icons.Default.Place
    RegistryKind.HONOR_WALL -> Icons.Default.EmojiEvents
    RegistryKind.FOOD_BASKETS -> Icons.Default.LocalGroceryStore
    RegistryKind.MIKVEH_APPT -> Icons.Default.Lock
    RegistryKind.SHABBAT_PREP -> Icons.Default.Checklist
    RegistryKind.SYNAGOGUE_DIR -> Icons.Default.LocationCity
}

private fun reminderText(e: RegistryEntity, k: RegistryKind, s: AppSettings): String = when (k) {
    RegistryKind.GEMACH, RegistryKind.INSTALLMENT -> Messages.nederReminder(e.memberName.ifBlank { e.title }, RegistryRules.remaining(e), e.currency, s.shulName())
    RegistryKind.LIBRARY -> Lf("შალომ, {0}! გთხოვთ დააბრუნოთ წიგნი „{1}“ სინაგოგის ბიბლიოთეკაში. თოდა რაბა! {2}", e.memberName, e.title, s.shulName())
    RegistryKind.LOST_FOUND -> Lf("შალომ, {0}! სინაგოგაში ინახება თქვენი ნივთი: {1}. {2}", e.memberName, e.title, s.shulName())
    RegistryKind.PUSHKE -> Lf("შალომ, {0}! მოვალთ ცედაკის ყუთის ამოსაღებად. თოდა რაბა! {1}", e.memberName, s.shulName())
    RegistryKind.VOLUNTEER -> Lf("შალომ, {0}! შეგახსენებთ: „{1}“. თოდა რაბა დახმარებისთვის! {2}", e.memberName, e.title, s.shulName())
    RegistryKind.KIDDUSH_CAL -> Lf("შალომ, {0}! თქვენი კიდუში ({1}) დაჯავშნილია. თოდა რაბა! {2}", e.memberName, e.title, s.shulName())
    RegistryKind.MEZUZAH -> Lf("შალომ, {0}! დროა შემოწმდეს: {1}. {2}", e.memberName, e.title, s.shulName())
    RegistryKind.CALL_CHAIN -> Lf("სასწრაფო: {0}. {1} — {2}", e.title, e.details, s.shulName())
    RegistryKind.GOAL -> Lf("„{0}“: შეგროვდა {1} / {2}. შეუერთდით! {3}", e.title, money(e.paidAmount, e.currency), money(e.amount, e.currency), s.shulName())
    RegistryKind.GUESTS -> Lf("შალომ! სტუმარი {0} ({1} კაცი) ეძებს შაბათის მასპინძელს. შეგიძლიათ მიიღოთ? {2}", e.title, e.count, s.shulName())
    RegistryKind.ALIYAH_PLAN -> AdvanceAliyot.message(e.memberName, e.extra, e.title, s.shulName())
    else -> "${e.title} — ${s.shulName()}"
}

@Composable
private fun RegistrySummary(kind: RegistryKind, rows: List<RegistryEntity>, s: AppSettings) {
    CosmicGlassCard(Modifier.fillMaxWidth(), borderColor = CosmicCelestialGold.copy(alpha = .4f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(iconOf(kind), null, tint = CosmicCelestialGold); Spacer(Modifier.width(8.dp))
            Column {
                Text(kind.title, fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                Text(kind.he, color = CosmicCelestialGold, fontSize = 13.sp)
            }
        }
        val open = rows.count { it.status == RegistryStatus.OPEN }
        Text(Lf("სულ: {0} • {1}: {2} • {3}: {4}", rows.size, L(kind.openLabel), open, L(kind.doneLabel), rows.size - open), color = CosmicTextSecondary, fontSize = 13.sp)
        if (kind.hasAmount) rows.groupBy { it.currency }.forEach { (cur, l) ->
            val total = l.sumOf { RegistryRules.total(it) }
            val line = if (kind == RegistryKind.GEMACH || kind == RegistryKind.INSTALLMENT)
                Lf("ჯამი: {0} • დაფარული: {1} • დარჩენილი: {2}", money(total, cur), money(l.sumOf { it.paidAmount }, cur), money(l.sumOf { RegistryRules.remaining(it) }, cur))
            else Lf("ჯამი: {0}", money(total, cur))
            Text(line, color = CosmicEmeraldSuccess, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        if (kind == RegistryKind.UTILITY) {
            val spent = RegistryRules.monthSpent(rows)
            if (s.utilityBudget > 0) {
                LinearProgressIndicator(progress = { (spent / s.utilityBudget).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    color = if (spent > s.utilityBudget) CosmicAlertRose else CosmicEmeraldSuccess)
                Text(Lf("ამ თვეში: {0} / ბიუჯეტი {1}", money(spent), money(s.utilityBudget)), color = CosmicTextSecondary, fontSize = 13.sp)
                if (spent > s.utilityBudget) Text(Lf("⚠ ბიუჯეტი გადაჭარბებულია {0}-ით!", money(spent - s.utilityBudget)), color = CosmicAlertRose, fontWeight = FontWeight.Bold, modifier = Modifier.testTag("budget_warning"))
            } else Text(L("თვიური ბიუჯეტი დააყენეთ პარამეტრებში"), color = CosmicTextMuted, fontSize = 12.sp)
        }
        if (kind == RegistryKind.MAASER) rows.groupBy { it.currency }.forEach { (cur, l) ->
            Text(Lf("გასაცემი მაასერი: {0}", money(RegistryRules.maaserDue(l), cur)), color = CosmicCelestialGold, fontWeight = FontWeight.Bold)
        }
        if (kind == RegistryKind.MEZUZAH) Text(L("მეზუზები და თეფილინი მოწმდება შვიდ წელიწადში ორჯერ — „ვადა“ ველში ჩაწერეთ შემდეგი შემოწმება."), color = CosmicTextMuted, fontSize = 12.sp)
        if (kind == RegistryKind.CALL_CHAIN) Text(L("თითოეულ წევრზე ერთი ჩანაწერი: გაუგზავნეთ, შემდეგ მონიშნეთ „ნახა / უპასუხა“. დარჩენილებს დაურეკეთ."), color = CosmicTextMuted, fontSize = 12.sp)
        V219Summary(kind, rows, s)
        val overdue = rows.count { RegistryRules.overdue(it) }
        if (overdue > 0) Text(Lf("⚠ ვადაგადაცილებული: {0}", overdue), color = CosmicAlertRose, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RegistryCard(
    e: RegistryEntity, k: RegistryKind, s: AppSettings,
    onEdit: () -> Unit, onDelete: () -> Unit, onPay: () -> Unit, onToggle: () -> Unit,
    onCall: () -> Unit, onWhatsapp: () -> Unit, onSms: () -> Unit, onCard: () -> Unit, onTehillim: () -> Unit,
    conflict: Boolean = false, onMaps: (() -> Unit)? = null, onPrayers: (() -> Unit)? = null, onGroup: (() -> Unit)? = null
) {
    val done = e.status == RegistryStatus.DONE
    CosmicGlassCard(Modifier.fillMaxWidth(), borderColor = if (RegistryRules.overdue(e)) CosmicAlertRose else if (done) CosmicEmeraldSuccess.copy(alpha = .4f) else CosmicBorderGlow) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(nb(e.title), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                if (e.memberName.isNotBlank()) Text(nb(e.memberName), color = CosmicTextSecondary)
                if (k.extraLabel != null && e.extra.isNotBlank()) Text(L(k.extraLabel) + ": " + nb(e.extra), color = CosmicTextSecondary, fontSize = 13.sp)
                Text(DualDates.gregorianText(e.dateMillis) + if (e.dueMillis > 0) "  →  " + L("ვადა: ") + DualDates.gregorianText(e.dueMillis) else "", color = CosmicTextMuted, fontSize = 12.sp)
                if (k.hasAmount) {
                    val total = RegistryRules.total(e)
                    val txt = when (k) {
                        RegistryKind.GEMACH, RegistryKind.INSTALLMENT -> Lf("{0} • დაფარული {1} • დარჩა {2}", money(total, e.currency), money(e.paidAmount, e.currency), money(RegistryRules.remaining(e), e.currency))
                        RegistryKind.GOAL -> Lf("შეგროვდა {0} / {1} ({2}%)", money(e.paidAmount, e.currency), money(e.amount, e.currency), (RegistryRules.goalProgress(e) * 100).toInt())
                        RegistryKind.MAASER -> Lf("შემოსავალი {0} • მაასერი {1} • გაცემულია {2}", money(e.amount, e.currency), money(e.amount * 0.1, e.currency), money(e.paidAmount, e.currency))
                        else -> if (k.hasCount && e.count > 1) "${e.count} × ${money(e.amount, e.currency)} = ${money(total, e.currency)}" else money(total, e.currency)
                    }
                    Text(txt, color = CosmicCelestialGold, fontWeight = FontWeight.SemiBold)
                    if (k == RegistryKind.GOAL) LinearProgressIndicator(progress = { RegistryRules.goalProgress(e) }, modifier = Modifier.fillMaxWidth().height(10.dp).padding(vertical = 2.dp), color = CosmicCelestialGold)
                    if (k == RegistryKind.INSTALLMENT && e.count > 0) Text(Lf("თვიური შენატანი: {0} ({1} თვე)", money(RegistryRules.installment(e), e.currency), e.count), color = CosmicTextSecondary, fontSize = 12.sp)
                    if ((k == RegistryKind.GEMACH || k == RegistryKind.INSTALLMENT) && e.amount > 0)
                        LinearProgressIndicator(progress = { (e.paidAmount / e.amount).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), color = CosmicEmeraldSuccess)
                } else if (k.hasCount && e.count > 1) Text(Lf("რაოდენობა: {0}", e.count), color = CosmicTextSecondary, fontSize = 13.sp)
                if (e.details.isNotBlank()) Text(nb(e.details), color = CosmicTextMuted, fontSize = 12.sp, maxLines = 6, overflow = TextOverflow.Ellipsis)
                if (conflict) Text(L("⚠ ორმაგი ჯავშანი: ამ დღეს და სლოტზე სხვა ღონისძიებაც არის!"), color = CosmicAlertRose, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.testTag("hall_conflict"))
                if (e.photoBase64.isNotBlank()) MemberPhoto(e.photoBase64, 96.dp, CosmicCelestialGold) { }
                AssistChip(onClick = onToggle, label = { Text(L(if (done) k.doneLabel else k.openLabel), maxLines = 1) },
                    leadingIcon = { Icon(if (done) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null, Modifier.size(16.dp)) })
            }
            Column {
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, L("რედაქტირება"), tint = CosmicAuroraBlue) }
                IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, L("წაშლა"), tint = CosmicAlertRose) }
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if ((k == RegistryKind.GEMACH || k == RegistryKind.INSTALLMENT) && !done) FilledTonalButton(onClick = onPay) { Icon(Icons.Default.Payments, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(L("გადახდის აღრიცხვა")) }
            if ((k == RegistryKind.GOAL || k == RegistryKind.MAASER) && !done) FilledTonalButton(onClick = onPay) { Icon(Icons.Default.Add, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(if (k == RegistryKind.GOAL) L("შეგროვებული თანხის დამატება") else L("გაცემული მაასერის დამატება")) }
            if (e.phone.isNotBlank()) {
                OutlinedButton(onClick = onCall) { Icon(Icons.Default.Call, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(L("დარეკვა")) }
                OutlinedButton(onClick = onWhatsapp) { Icon(Icons.Default.Chat, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("WhatsApp") }
                OutlinedButton(onClick = onSms) { Icon(Icons.Default.Sms, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("SMS") }
            }
            if (k.finance != null && k.financeType == TransactionType.INCOME && RegistryRules.total(e) > 0)
                OutlinedButton(onClick = onCard) { Icon(Icons.Default.CardGiftcard, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(L("სამადლობელი ბარათი")) }
            onMaps?.let { FilledTonalButton(onClick = it) { Icon(Icons.Default.Directions, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(L("ნავიგაცია Google Maps-ში")) } }
            onPrayers?.let { OutlinedButton(onClick = it) { Icon(Icons.Default.MenuBook, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(L("კადიში / ელ მალე რახამიმ")) } }
            onGroup?.let { OutlinedButton(onClick = it) { Icon(Icons.Default.Groups, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(L("სინაგოგის ჯგუფში გაზიარება")) } }
            if (k == RegistryKind.TEHILLIM) FilledTonalButton(onClick = onTehillim) { Icon(Icons.Default.Groups, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(L("150 ფსალმუნის განაწილება")) }
        }
    }
}

@Composable
private fun RegistryDialog(kind: RegistryKind, initial: RegistryEntity?, memberNames: List<String>, onAddMember: (String) -> Unit, phoneOf: (String) -> String, onDismiss: () -> Unit, onSave: (RegistryEntity) -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var member by remember { mutableStateOf(initial?.memberName ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var date by remember { mutableStateOf(initial?.dateMillis ?: System.currentTimeMillis()) }
    var due by remember { mutableStateOf(initial?.dueMillis ?: 0L) }
    var amount by remember { mutableStateOf(initial?.amount?.takeIf { it > 0 }?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var currency by remember { mutableStateOf(initial?.currency ?: I18n.defaultCurrency) }
    var count by remember { mutableStateOf((initial?.count ?: if (kind == RegistryKind.INSTALLMENT) 12 else 1).toString()) }
    var details by remember { mutableStateOf(initial?.details ?: "") }
    var extra by remember { mutableStateOf(initial?.extra ?: "") }
    var done by remember { mutableStateOf(initial?.status == RegistryStatus.DONE) }
    var error by remember { mutableStateOf(false) }
    var photo by remember { mutableStateOf(initial?.photoBase64 ?: "") }
    val dictate = rememberSpeechInput { t -> details = (details + " " + t).trim(); if (title.isBlank()) title = t.take(40) }
    FormDialog(
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false), modifier = Modifier.fillMaxWidth(.94f),
        onDismissRequest = onDismiss,
        title = { Text((if (initial == null) L("ახალი ჩანაწერი") else L("რედაქტირება")) + " — " + kind.title, fontWeight = FontWeight.Bold) },
        text = { LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            item {
                if (kind.suggestions.isNotEmpty()) SuggestField(L(kind.titleLabel), title, { title = it }, kind.suggestions.map { L(it) }, modifier = Modifier.testTag("registry_title"))
                else OutlinedTextField(title, { title = it }, label = { Text(L(kind.titleLabel)) }, singleLine = true, isError = error && title.isBlank(), modifier = Modifier.fillMaxWidth().testTag("registry_title"))
            }
            if (kind.hasMember) item { MemberField(L("წევრი / პასუხისმგებელი"), member, { member = it; if (phone.isBlank()) phone = phoneOf(it) }, memberNames, onAddMember) }
            if (kind.hasPhone) item { OutlinedTextField(phone, { phone = it }, label = { Text(L("ტელეფონი")) }, singleLine = true, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone), modifier = Modifier.fillMaxWidth()) }
            if (kind.hasAmount) item { AmountCurrencyField(if (kind.hasCount && kind != RegistryKind.INSTALLMENT) L("ერთეულის ფასი") else L("თანხა"), amount, { amount = it }, currency, { currency = it }) }
            if (kind.hasCount) item {
                OutlinedTextField(count, { v -> count = v.filter(Char::isDigit).take(4) }, label = { Text(if (kind == RegistryKind.INSTALLMENT) L("თვეების რაოდენობა") else L("რაოდენობა")) }, singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            }
            item { DualDateField(L("თარიღი"), date, { date = it }) }
            if (kind.hasDue) item { DualDateField(if (kind == RegistryKind.GUESTS) L("ჩამოსვლის / შაბათის თარიღი") else L("დაბრუნების ვადა"), due, { due = it }, optional = true) }
            if (kind.extraLabel != null) item { OutlinedTextField(extra, { extra = it }, label = { Text(L(kind.extraLabel)) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(details, { details = it }, label = { Text(L("დეტალები / შენიშვნა")) }, modifier = Modifier.weight(1f).testTag("registry_details"))
                    IconButton(onClick = dictate, modifier = Modifier.testTag("registry_dictate")) { Icon(Icons.Default.Mic, L("ხმით ჩაწერა"), tint = CosmicStardustCyan) }
                }
            }
            if (kind == RegistryKind.LOST_FOUND) item { Text(L("ნივთის ფოტო"), color = CosmicTextSecondary, fontSize = 13.sp); MemberPhotoEditor(photo) { photo = it } }
            if (kind == RegistryKind.CEMETERY) item { Text(L("კოორდინატები ჩაწერეთ ასე: 41.6938, 44.8015 (Google Maps-ში საფლავზე თითის დაჭერით მიიღებთ)"), color = CosmicTextMuted, fontSize = 12.sp) }
            item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(done, { done = it }); Text(L(kind.doneLabel), color = CosmicTextSecondary) } }
        } },
        confirmButton = { Button(onClick = {
            if (title.isBlank()) { error = true; return@Button }
            val base = initial ?: RegistryEntity(kind = kind.name, title = "")
            onSave(base.copy(title = title.trim(), memberName = member.trim(), phone = phone.trim(), dateMillis = date, dueMillis = due,
                amount = amount.toDoubleOrNull() ?: 0.0, currency = currency, count = count.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                details = details.trim(), extra = extra.trim(), photoBase64 = photo, status = if (done) RegistryStatus.DONE else RegistryStatus.OPEN,
                paidAmount = if (done && (kind == RegistryKind.GEMACH || kind == RegistryKind.INSTALLMENT)) (amount.toDoubleOrNull() ?: 0.0) else base.paidAmount))
        }, modifier = Modifier.testTag("btn_save_registry")) { Text(L("შენახვა")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L("გაუქმება")) } }
    )
}

@Composable
private fun PaymentDialog(e: RegistryEntity, onDismiss: () -> Unit, onPay: (Double) -> Unit) {
    val suggested = if (e.kind == RegistryKind.INSTALLMENT.name) RegistryRules.installment(e).coerceAtMost(RegistryRules.remaining(e)) else RegistryRules.remaining(e)
    var text by remember { mutableStateOf(String.format(java.util.Locale.US, "%.0f", suggested)) }
    FormDialog(onDismissRequest = onDismiss,
        title = { Text(L("გადახდის აღრიცხვა")) },
        text = { Column {
            Text(Lf("დარჩენილი: {0}", money(RegistryRules.remaining(e), e.currency)), color = CosmicTextSecondary)
            OutlinedTextField(text, { v -> text = v.filter { it.isDigit() || it == '.' } }, label = { Text(L("თანხა")) }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("payment_amount"))
        } },
        confirmButton = { Button(onClick = { onPay(text.toDoubleOrNull() ?: 0.0) }) { Text(L("შენახვა")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L("გაუქმება")) } })
}

@Composable
private fun TehillimDialog(e: RegistryEntity, members: List<MemberEntity>, s: AppSettings, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val withPhone = members.filter { it.phone.isNotBlank() }
    var chosen by remember { mutableStateOf(setOf<Long>()) }
    val readers = withPhone.filter { it.id in chosen }
    val ranges = com.example.ui.calendar.JewishTools.splitTehillim(readers.size)
    FormDialog(properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false), modifier = Modifier.fillMaxWidth(.94f),
        onDismissRequest = onDismiss,
        title = { Text(L("150 ფსალმუნის განაწილება") + " — " + nb(e.title)) },
        text = { LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item { Text(L("მონიშნეთ მკითხველები. თითოეულს WhatsApp-ით გაეგზავნება თავისი თავები."), color = CosmicTextSecondary, fontSize = 13.sp) }
            if (withPhone.isEmpty()) item { Text(L("წევრებს ტელეფონის ნომერი არ აქვთ მითითებული"), color = CosmicAlertRose) }
            items(withPhone, key = { it.id }) { m ->
                val idx = readers.indexOf(m)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(m.id in chosen, { chosen = if (it) chosen + m.id else chosen - m.id })
                    Column(Modifier.weight(1f)) {
                        Text(m.fullName, color = CosmicTextPrimary)
                        if (idx >= 0) Text(Lf("ფსალმუნები {0}–{1}", ranges[idx].first, ranges[idx].last), color = CosmicCelestialGold, fontSize = 12.sp)
                    }
                    if (idx >= 0) IconButton(onClick = { Share.whatsapp(context, m.phone, Messages.tehillim(e.title, e.extra.ifBlank { L("რაფუა შელემა") }, m.fullName, ranges[idx])) }) {
                        Icon(Icons.Default.Send, "WhatsApp", tint = CosmicEmeraldSuccess)
                    }
                }
            }
        } },
        confirmButton = { TextButton(onClick = onDismiss) { Text(L("დახურვა")) } })
}
