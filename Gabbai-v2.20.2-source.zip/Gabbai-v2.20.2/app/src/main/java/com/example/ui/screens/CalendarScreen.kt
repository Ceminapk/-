package com.example.ui.screens

import kotlinx.coroutines.flow.first
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.scrollBy

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.calendar.*
import com.example.ui.components.AppDropdown
import com.example.ui.components.CosmicGlassCard
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

private fun today(): Triple<Int, Int, Int> {
    val c = Calendar.getInstance()
    return Triple(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun formatTime(millis: Long?, city: ZmanimCity): String {
    if (millis == null) return "—"
    val f = SimpleDateFormat("HH:mm", Locale.US); f.timeZone = TimeZone.getTimeZone(city.tz)
    return f.format(Date(millis))
}

private val weekdayKa = listOf("კვირა", "ორშაბათი", "სამშაბათი", "ოთხშაბათი", "ხუთშაბათი", "პარასკევი", "შაბათი")
private fun weekdayShort(): List<String> = when (com.example.ui.settings.I18n.lang) {
    com.example.ui.settings.AppLanguage.RU -> listOf("Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб")
    com.example.ui.settings.AppLanguage.EN -> listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    com.example.ui.settings.AppLanguage.HE -> listOf("א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳")
    else -> listOf("კვ", "ორ", "სა", "ოთ", "ხუ", "პა", "შა")
}
private val monthKa = listOf("იანვარი", "თებერვალი", "მარტი", "აპრილი", "მაისი", "ივნისი", "ივლისი", "აგვისტო", "სექტემბერი", "ოქტომბერი", "ნოემბერი", "დეკემბერი")

fun gregorianLabel(di: DayInfo) = "${L(weekdayKa[di.weekday - 1])}, ${di.d} ${L(monthKa[di.m - 1])} ${di.y}"

/** Compact card for the main screen: next candle lighting and Shabbat / holiday end. */
@Composable
fun ShabbatTimesCard(onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val city = CalendarPrefs.city
    val (y, m, d) = today()
    val period = remember(city, y, m, d) { runCatching { JewishCalendar.nextRestPeriod(y, m, d, city) }.getOrNull() }
    val todayInfo = remember(city, y, m, d) { runCatching { JewishCalendar.day(y, m, d, city) }.getOrNull() }
    CosmicGlassCard(modifier = modifier.fillMaxWidth().clickable(onClick = onOpen).testTag("shabbat_card"), borderColor = CosmicCelestialGold.copy(alpha = 0.6f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LocalFireDepartment, null, tint = CosmicCelestialGold, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                todayInfo?.let {
                    Text(JewishCalendar.hebrewDateHe(it.heb), color = CosmicTextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                    Text(gregorianLabel(it) + " • " + L(city.nameKa), color = CosmicTextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Icon(Icons.Default.ChevronRight, null, tint = CosmicTextSecondary)
        }
        period?.let { (start, end) ->
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (start === end) TimeBox(L("🕯️ ახლა მიმდინარეობს"), start.holidays.firstOrNull { it.yomTov }?.let { L(it.ka) } ?: L("შაბათი"), Modifier.weight(1f))
                else TimeBox(L("🕯️ სანთლის ანთება"), "${L(weekdayKa[start.weekday - 1])} ${formatTime(start.candleLighting ?: start.tzeit, city)}", Modifier.weight(1f))
                TimeBox(L("✨ გასვლა"), end?.let { "${L(weekdayKa[it.weekday - 1])} ${formatTime(it.havdalah, city)}" } ?: "—", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun TimeBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(CosmicCelestialGold.copy(alpha = 0.12f))
            .border(1.dp, CosmicCelestialGold.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(label, fontSize = 11.sp, color = CosmicTextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CosmicTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun CalendarScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val city = CalendarPrefs.city
    var locationMessage by remember { mutableStateOf("") }
    fun useLastLocation() {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val location = manager.getProviders(true).mapNotNull { provider ->
            runCatching { manager.getLastKnownLocation(provider) }.getOrNull()
        }.maxByOrNull { it.time }
        if (location != null) {
            CalendarPrefs.setGps(location.latitude, location.longitude)
            locationMessage = L("GPS მდებარეობა არჩეულია")
        } else locationMessage = L("მდებარეობა ვერ მოიძებნა — ჩართეთ GPS და სცადეთ კვლავ")
    }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) useLastLocation() else locationMessage = L("მდებარეობის ნებართვა არ არის გაცემული")
    }
    val (ty, tm, td) = remember { today() }
    var viewY by remember { mutableStateOf(ty) }
    var viewM by remember { mutableStateOf(tm) }
    var sel by remember { mutableStateOf(Triple(ty, tm, td)) }
    val selInfo = remember(sel, city) { JewishCalendar.day(sel.first, sel.second, sel.third, city) }
    val monthDays = remember(viewY, viewM, city) {
        val c = GregorianCalendar(viewY, viewM - 1, 1)
        val len = c.getActualMaximum(Calendar.DAY_OF_MONTH)
        (1..len).map { JewishCalendar.day(viewY, viewM, it, city) }
    }
    val upcoming = remember(city, ty, tm, td) {
        val c = GregorianCalendar(ty, tm - 1, td)
        val list = mutableListOf<Pair<DayInfo, Holiday>>()
        repeat(120) {
            val di = JewishCalendar.day(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), city)
            di.holidays.filter { it.ka != "როშ ხოდეში" || true }.forEach { h ->
                if (list.none { it.second.ka == h.ka && it.first.y == di.y && it.first.m == di.m && kotlin.math.abs(it.first.d - di.d) <= 8 }) list += di to h
            }
            c.add(Calendar.DAY_OF_MONTH, 1)
        }
        list.take(14)
    }

    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    var flash by remember { mutableStateOf(false) }
    var zmanimOnly by remember { mutableStateOf(CalendarFocus.zmanim) }
    LaunchedEffect(CalendarFocus.zmanim) {
        if (CalendarFocus.zmanim) {
            CalendarFocus.zmanim = false
            zmanimOnly = true
            sel = Triple(ty, tm, td)
            kotlinx.coroutines.delay(150)
            listState.scrollToItem(0)
            flash = true; kotlinx.coroutines.delay(1600); flash = false
        }
    }
    val wantHolidays = remember { CalendarFocus.holidays }
    LaunchedEffect(Unit) {
        if (wantHolidays) {
            zmanimOnly = false
            CalendarFocus.holidays = false
            // Wait for the list to be laid out, then find the header by key (scrolling down if needed).
            androidx.compose.runtime.snapshotFlow { listState.layoutInfo.totalItemsCount }.first { it > 4 }
            kotlinx.coroutines.delay(120)
            repeat(30) {
                    val vis = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.key == "upcoming_header" }?.index
                if (vis != null) { listState.animateScrollToItem(vis); flash = true; kotlinx.coroutines.delay(1600); flash = false; return@LaunchedEffect }
                listState.animateScrollBy(600f)
                kotlinx.coroutines.delay(30)
            }
            listState.animateScrollToItem(4)
        }
    }
    val flashBorder by androidx.compose.animation.animateColorAsState(if (flash) CosmicCelestialGold else androidx.compose.ui.graphics.Color.Transparent, androidx.compose.animation.core.tween(500), label = "zflash")
    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize().padding(horizontal = 16.dp).testTag("calendar_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp)
    ) {
        item {
            AppDropdown(
                label = L("ქალაქი (ზმანიმი)"),
                value = city.nameKa,
                options = listOf("GPS — მიმდინარე მდებარეობა") + Cities.all.map { it.nameKa },
                optionLabel = { L(it) },
                onSelected = {
                    if (it == "GPS — მიმდინარე მდებარეობა") {
                        val fine = androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (fine) useLastLocation() else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    } else CalendarPrefs.set(it)
                },
                modifier = Modifier.fillMaxWidth()
            )
            if (locationMessage.isNotEmpty()) Text(locationMessage, color = CosmicTextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        if (zmanimOnly) item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WbSunny, null, tint = CosmicCelestialGold); Spacer(Modifier.width(8.dp))
                Text(L("დღის დროები (ზმანიმი)"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 17.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { zmanimOnly = false }, modifier = Modifier.testTag("btn_full_calendar")) { Text(L("სრული კალენდარი")) }
            }
        }
        if (!zmanimOnly) item { ShabbatTimesCard(onOpen = { sel = Triple(ty, tm, td); viewY = ty; viewM = tm }) }

        // Month grid
        if (!zmanimOnly) item {
            CosmicGlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (viewM == 1) { viewM = 12; viewY-- } else viewM-- }) { Icon(Icons.Default.ChevronLeft, L("წინა თვე"), tint = CosmicTextPrimary) }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${L(monthKa[viewM - 1])} $viewY", fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 16.sp, maxLines = 1)
                        val f = monthDays.first().heb; val l = monthDays.last().heb
                        val heLabel = if (f.month == l.month) "${JewishCalendar.monthNameHe(f)} ${JewishCalendar.gematria(f.year)}"
                            else "${JewishCalendar.monthNameHe(f)} – ${JewishCalendar.monthNameHe(l)} ${JewishCalendar.gematria(l.year)}"
                        Text(heLabel, color = CosmicCelestialGold, fontSize = 13.sp, maxLines = 1)
                    }
                    IconButton(onClick = { if (viewM == 12) { viewM = 1; viewY++ } else viewM++ }) { Icon(Icons.Default.ChevronRight, L("შემდეგი თვე"), tint = CosmicTextPrimary) }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth()) {
                    weekdayShort().forEachIndexed { i, w ->
                        Text(w, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp, maxLines = 1,
                            color = if (i == 6) CosmicCelestialGold else CosmicTextSecondary, fontWeight = FontWeight.SemiBold)
                    }
                }
                val lead = monthDays.first().weekday - 1
                val cells: List<DayInfo?> = List(lead) { null } + monthDays
                cells.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        (0 until 7).forEach { i ->
                            val di = week.getOrNull(i)
                            Box(Modifier.weight(1f).aspectRatio(0.82f).padding(2.dp)) {
                                if (di != null) DayCell(di, isToday = di.y == ty && di.m == tm && di.d == td,
                                    selected = sel == Triple(di.y, di.m, di.d)) { sel = Triple(di.y, di.m, di.d) }
                            }
                        }
                    }
                }
            }
        }

        // Selected day details
        item {
            CosmicGlassCard(Modifier.fillMaxWidth().border(2.dp, flashBorder, RoundedCornerShape(26.dp)).testTag("zmanim_card")) {
                Text(gregorianLabel(selInfo), fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 16.sp)
                Text(JewishCalendar.hebrewDateHe(selInfo.heb), color = CosmicCelestialGold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(L(JewishCalendar.monthNameKa(selInfo.heb)).let { "${selInfo.heb.day} $it ${selInfo.heb.year}" }, color = CosmicTextSecondary, fontSize = 12.sp)
                selInfo.holidays.forEach { h ->
                    Spacer(Modifier.height(4.dp))
                    Text("${if (h.yomTov) "✡" else if (h.fast) "◐" else "•"} ${L(h.ka)}", color = if (h.yomTov) CosmicCelestialGold else CosmicTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(h.he, color = CosmicTextSecondary, fontSize = 13.sp)
                }
                selInfo.omer?.let { Text(Lf("ომერის თვლა: {0}-ე დღე (საღამოს — {1})", it, it + 1), color = CosmicStardustCyan, fontSize = 13.sp) }
                Spacer(Modifier.height(10.dp))
                if (selInfo.candleLighting != null) ZmanRow(if (selInfo.candleAfterNightfall) L("🕯️ სანთლის ანთება (ღამის შემდეგ)") else L("🕯️ სანთლის ანთება"), formatTime(selInfo.candleLighting, city), highlight = true)
                if (selInfo.havdalah != null) ZmanRow(L("✨ შაბათის / დღესასწაულის გასვლა"), formatTime(selInfo.havdalah, city), highlight = true)
                HorizontalDivider(Modifier.padding(vertical = 6.dp), color = CosmicTextPrimary.copy(alpha = 0.1f))
                ZmanRow(L("ალოთ ჰაშახარი (განთიადი)"), formatTime(selInfo.alot, city))
                ZmanRow(L("ნეც — მზის ამოსვლა"), formatTime(selInfo.sunrise, city))
                ZmanRow(L("სოფ ზმან შემა (გრა)"), formatTime(selInfo.sofShema, city))
                ZmanRow(L("სოფ ზმან თეფილა"), formatTime(selInfo.sofTefila, city))
                ZmanRow(L("ხაცოთი — შუადღე"), formatTime(selInfo.chatzot, city))
                ZmanRow(L("მინხა გედოლა"), formatTime(selInfo.minchaGedola, city))
                ZmanRow(L("ფლაგ ჰამინხა"), formatTime(selInfo.plag, city))
                ZmanRow(L("შკია — მზის ჩასვლა"), formatTime(selInfo.sunset, city))
                ZmanRow(L("ცეთ ჰაქოხავიმ — ვარსკვლავები"), formatTime(selInfo.tzeit, city))
                if (selInfo.holidays.any { it.fast }) Text(L("მარხვა: განთიადიდან ვარსკვლავების გამოჩენამდე (იომ კიპური და თიშა ბეავი — წინა საღამოდან)"), color = CosmicTextMuted, fontSize = 12.sp)
            }
        }

        item(key = "upcoming_header") {
            Column {
                Text(L("მომავალი დღესასწაულები"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary, style = MaterialTheme.typography.titleMedium)
                Text(L("ზმანიმი მზის ასტრონომიული გამოთვლაა; ჰალახურ პრაქტიკაში გადაამოწმეთ ადგილობრივ რაბინთან."), color = CosmicTextMuted, fontSize = 11.sp)
            }
        }
        upcoming.forEach { (di, h) ->
            item {
                CosmicGlassCard(Modifier.fillMaxWidth().clickable { sel = Triple(di.y, di.m, di.d); viewY = di.y; viewM = di.m }, cornerRadius = 14.dp,
                    borderColor = if (h.yomTov) CosmicCelestialGold.copy(alpha = 0.6f) else CosmicBorderGlow) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(L(h.ka), fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(h.he, color = CosmicTextSecondary, fontSize = 13.sp, maxLines = 1)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${di.d} ${L(monthKa[di.m - 1])}", color = CosmicTextPrimary, fontSize = 13.sp, maxLines = 1)
                            Text(JewishCalendar.hebrewDateHe(di.heb).substringBeforeLast(' '), color = CosmicCelestialGold, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(di: DayInfo, isToday: Boolean, selected: Boolean, onClick: () -> Unit) {
    val special = di.isShabbat || di.isYomTov
    val bg = when {
        selected -> CosmicAuroraBlue.copy(alpha = 0.35f)
        di.isYomTov -> CosmicCelestialGold.copy(alpha = 0.22f)
        di.holidays.isNotEmpty() -> CosmicStardustCyan.copy(alpha = 0.12f)
        di.isShabbat -> CosmicCelestialGold.copy(alpha = 0.10f)
        else -> CosmicTextPrimary.copy(alpha = 0.03f)
    }
    Column(
        Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp)).background(bg)
            .border(if (isToday) 2.dp else 0.5.dp, if (isToday) CosmicCelestialGold else CosmicTextPrimary.copy(alpha = 0.08f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick).padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("${di.d}", fontSize = 15.sp, fontWeight = if (special || isToday) FontWeight.Bold else FontWeight.Medium, color = if (special) CosmicCelestialGold else CosmicTextPrimary, maxLines = 1)
        Text(JewishCalendar.gematria(di.heb.day), fontSize = 10.sp, color = CosmicTextSecondary, maxLines = 1)
        if (di.candleLighting != null || di.holidays.isNotEmpty()) {
            Text(if (di.candleLighting != null) "🕯" else "•", fontSize = 8.sp, maxLines = 1)
        }
    }
}

@Composable
private fun ZmanRow(label: String, time: String, highlight: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = if (highlight) 14.sp else 13.sp, color = if (highlight) CosmicTextPrimary else CosmicTextSecondary,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.width(8.dp))
        Text(time, fontSize = if (highlight) 17.sp else 14.sp, fontWeight = FontWeight.Bold, color = if (highlight) CosmicCelestialGold else CosmicTextPrimary, maxLines = 1)
    }
}


/** Set by the main-screen ticker: the calendar opens scrolled to today's times. */
object CalendarFocus { var zmanim by mutableStateOf(false); var holidays by mutableStateOf(false) }
