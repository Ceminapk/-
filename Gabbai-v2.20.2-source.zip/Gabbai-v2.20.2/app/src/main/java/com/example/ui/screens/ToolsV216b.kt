package com.example.ui.screens

import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.calendar.*
import com.example.ui.components.*
import com.example.ui.settings.*
import com.example.ui.share.PdfMaker
import com.example.ui.share.Share
import com.example.ui.theme.*
import com.example.ui.v216.*
import com.example.ui.viewmodel.GabbaiUiState
import com.example.ui.viewmodel.GabbaiViewModel
import java.text.SimpleDateFormat
import java.util.*

private fun d3(t: Long) = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(t))
private fun hebOf(t: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = t }
    return JewishCalendar.hebrewDateHe(JewishCalendar.toHebrew(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)))
}

@Composable
private fun Card2(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    CosmicGlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = CosmicCelestialGold); Spacer(Modifier.width(8.dp)); Text(title, fontWeight = FontWeight.Bold, color = CosmicTextPrimary, fontSize = 16.sp) }
        Spacer(Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
    }
}

private fun speechTag(l: AppLanguage) = when (l) { AppLanguage.RU -> "ru-RU"; AppLanguage.EN -> "en-US"; AppLanguage.HE -> "he-IL"; else -> "ka-GE" }

/** Post-Shabbat dictation → honours and pledges, confirmed before saving. */
@Composable
fun VoiceDebriefTool(state: GabbaiUiState, vm: GabbaiViewModel) {
    val s = LocalAppSettings.current
    var text by remember { mutableStateOf("") }
    var parasha by remember { mutableStateOf("") }
    val items = remember(text, state.members) { DebriefParser.parse(text, state.members, s.currency) }
    val fixes = remember { mutableStateMapOf<Pair<Int, String>, DebriefItem>() }
    val ctx = LocalContext.current
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { text = (text + " " + it).trim() }
    }
    Card2(Icons.Default.RecordVoiceOver, L("შაბათის შემდეგ ხმოვანი კარნახი")) {
        Text(L("თქვით: „დავითმა ფეთიხა 100 ლარი, იაკობმა შელიში 50 დოლარი, მოშემ ნედერი 200“"), color = CosmicTextMuted, fontSize = 12.sp)
        Button(onClick = {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, speechTag(s.language)).putExtra(RecognizerIntent.EXTRA_PROMPT, L("ჩაილაპარაკეთ შაბათის ალიები"))
            try { mic.launch(i) } catch (e: Exception) { android.widget.Toast.makeText(ctx, L("ხმის ამოცნობა ამ ტელეფონზე მიუწვდომელია"), android.widget.Toast.LENGTH_SHORT).show() }
        }, modifier = Modifier.fillMaxWidth().testTag("btn_debrief_mic")) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(6.dp)); Text(L("კარნახის დაწყება")) }
        OutlinedTextField(text, { text = it }, label = { Text(L("ტექსტი (შეგიძლიათ ჩაასწოროთ)")) }, modifier = Modifier.fillMaxWidth().testTag("debrief_text"))
        OutlinedTextField(parasha, { parasha = it }, label = { Text(L("ფარაშა / შემთხვევა")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (text.isNotBlank() && items.isEmpty()) Text(L("ალია ან ნედერი ვერ ამოვიცანი — დაასახელეთ პატივი (ფეთიხა, ქოჰენი, შელიში...)"), color = CosmicTextMuted, fontSize = 12.sp)
        val people = state.members.filter { it.status != MemberStatus.DECEASED }.map { it.fullName }
        items.forEachIndexed { i, base ->
            val it2 = fixes[i to base.source] ?: base
            CosmicGlassCard(Modifier.fillMaxWidth()) {
                Text("${it2.type.titleKa} — ${money(it2.amount, it2.currency)}" + if (!it2.matchedMember) "  ⚠ " + L("შეამოწმეთ სახელი") else "",
                    color = if (it2.matchedMember) CosmicTextPrimary else CosmicCelestialGold, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                SuggestField(label = L("წევრი"), value = it2.memberName, suggestions = people, onValueChange = { v -> fixes[i to base.source] = it2.copy(memberName = v, matchedMember = v in people) })
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(if (it2.amount == 0.0) "" else it2.amount.toBigDecimal().stripTrailingZeros().toPlainString(), { v -> fixes[i to base.source] = it2.copy(amount = v.replace(',', '.').toDoubleOrNull() ?: 0.0) },
                        label = { Text(L("თანხა")) }, singleLine = true, modifier = Modifier.weight(1f))
                    AppDropdown(label = L("ვალუტა"), value = it2.currency, options = Currencies.all.map { it.code }, optionLabel = { c -> Currencies.symbol(c) + " " + c },
                        onSelected = { c -> fixes[i to base.source] = it2.copy(currency = c) }, modifier = Modifier.weight(1f))
                }
            }
        }
        if (items.isNotEmpty()) Button(onClick = {
            items.mapIndexed { i, b -> fixes[i to b.source] ?: b }.forEach { d ->
                if (d.type == AliyahType.NEDER) vm.addQuickNeder(d.memberName, d.amount, d.currency, parasha, false)
                else vm.addAliyah(parasha.ifBlank { L("შაბათი") }, d.type, d.memberName, d.amount, TransactionStatus.PLEDGED, d.currency)
            }
            text = ""; fixes.clear()
        }, modifier = Modifier.fillMaxWidth().testTag("btn_debrief_save")) { Icon(Icons.Default.Check, null); Spacer(Modifier.width(6.dp)); Text(Lf("დადასტურება და შენახვა ({0})", items.size)) }
    }
}

/** PDF receipt for a payment and the annual donation certificate. */
@Composable
fun PdfReceiptTool(state: GabbaiUiState) {
    val s = LocalAppSettings.current
    val ctx = LocalContext.current
    val shul = s.shulName()
    val paid = state.transactions.filter { it.type == TransactionType.INCOME && it.status == TransactionStatus.PAID }.sortedByDescending { it.dateMillis }
    var who by remember { mutableStateOf("") }
    var year by remember { mutableStateOf(Calendar.getInstance().get(Calendar.YEAR).toString()) }
    Card2(Icons.Default.PictureAsPdf, L("PDF ქვითარი და წლიური ცნობა")) {
        Text(L("ბოლო გადახდები — დააჭირეთ ქვითრის გასაგზავნად:"), color = CosmicTextMuted, fontSize = 12.sp)
        if (paid.isEmpty()) Text(L("ჩანაწერი არ არის"), color = CosmicTextMuted)
        paid.take(8).forEach { t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${d3(t.dateMillis)} • ${nb(t.memberName.ifBlank { "—" })} • ${money(t.amount, t.currency)}", color = CosmicTextPrimary, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    val doc = PdfMaker.Doc(shul, L("შემოწირულობის ქვითარი") + " № " + t.id + "\n" + d3(t.dateMillis) + " • " + hebOf(t.dateMillis), listOf(
                        Lf("მიღებულია: {0}", t.memberName.ifBlank { "—" }), Lf("თანხა: {0}", money(t.amount, t.currency)),
                        Lf("დანიშნულება: {0}", t.title), Lf("კატეგორია: {0}", t.category.titleKa), Lf("გადახდის მეთოდი: {0}", t.paymentMethod), "",
                        L("გმადლობთ თქვენი შემოწირულობისთვის!")), blessing = "תִּזְכּוּ לְמִצְווֹת — " + L("ღმერთმა გიკურთხოთ"), seal = shul)
                    PdfMaker.share(ctx, PdfMaker.build(ctx, "receipt_${t.id}", doc), L("შემოწირულობის ქვითარი"))
                }, modifier = Modifier.testTag("btn_receipt_${t.id}")) { Text("PDF") }
            }
        }
        HorizontalDivider()
        SuggestField(label = L("წევრი (წლიური ცნობა)"), value = who, suggestions = state.members.map { it.fullName }, onValueChange = { who = it })
        OutlinedTextField(year, { year = it.filter(Char::isDigit).take(4) }, label = { Text(L("წელი")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(enabled = who.isNotBlank() && year.length == 4, onClick = {
            val y = year.toInt()
            val lines = com.example.ui.share.Messages.annualCertificate(who, y, state.transactions, shul).lines().drop(2)
            val doc = PdfMaker.Doc(shul, Lf("შემოწირულობების წლიური ცნობა — {0}", y), lines, blessing = "חֲזַק וּבָרוּךְ", seal = shul)
            PdfMaker.share(ctx, PdfMaker.build(ctx, "certificate_${y}_$who", doc), L("წლიური ცნობა"))
        }, modifier = Modifier.fillMaxWidth().testTag("btn_certificate")) { Icon(Icons.Default.WorkspacePremium, null); Spacer(Modifier.width(6.dp)); Text(L("წლიური ცნობის PDF")) }
    }
}

/** Mi Shebeirach / Hazkara texts in one tap and the Friday bimah plan sheet. */
@Composable
fun BimahHelperTool(state: GabbaiUiState) {
    val s = LocalAppSettings.current
    val ctx = LocalContext.current
    var mode by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf("") }
    var parent by remember { mutableStateOf("") }
    var female by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    val modes = listOf(L("მი შებერახი ავადმყოფისთვის"), L("მი შებერახი ამომსვლელისთვის"), L("ჰაზქარა (ელ მალე რახამიმ)"))
    Card2(Icons.Default.MenuBook, L("ბიმას დამხმარე")) {
        AppDropdown(label = L("ტექსტი"), value = mode, options = listOf(0, 1, 2), optionLabel = { modes[it] }, onSelected = { mode = it })
        val names = (state.members.filter { it.status != MemberStatus.DECEASED } ).map { it.fullName } + state.yahrzeits.map { it.deceasedName }
        SuggestField(label = L("სახელი"), value = name, suggestions = names.distinct(), onValueChange = { v ->
            name = v
            state.members.firstOrNull { it.fullName == v }?.hebrewName?.takeIf { it.isNotBlank() }?.let { name = it }
        })
        OutlinedTextField(parent, { parent = it }, label = { Text(if (mode == 0) L("დედის სახელი (ებრაულად)") else L("მამის სახელი (ებრაულად)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (mode != 1) Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(female, { female = it }); Text(L("ქალია (בת)"), color = CosmicTextSecondary) }
        if (mode == 1) OutlinedTextField(amount, { amount = it }, label = { Text(L("ნედერი (სურვილისამებრ)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (name.isNotBlank()) {
            val he = HebrewNames.of(name) ?: name
            val text = when (mode) { 0 -> BimahTexts.miShebeirachSick(he, parent, female); 1 -> BimahTexts.miShebeirachOleh(he, parent, amount); else -> BimahTexts.hazkara(he, parent, female) }
            Text(text, color = CosmicCelestialGold, fontSize = 18.sp, lineHeight = 28.sp, modifier = Modifier.testTag("bimah_text"))
            OutlinedButton(onClick = { Share.text(ctx, text) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text(L("გაზიარება")) }
        }
        HorizontalDivider()
        BimahPlanSection(state, s.shulName())
    }
}

@Composable
private fun BimahPlanSection(state: GabbaiUiState, shul: String) {
    val ctx = LocalContext.current
    val fri = remember { nextFriday() }
    val sat = remember { (fri.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) } }
    var parasha by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    val picks = remember { mutableStateMapOf<AliyahType, String>() }
    val people = state.members.filter { it.status != MemberStatus.DECEASED }.map { it.fullName }
    Text(L("შაბათის ბიმას გეგმა"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
    OutlinedTextField(parasha, { parasha = it }, label = { Text(L("კვირის ფარაშა")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
    BimahPlan.standardHonours.forEach { h ->
        SuggestField(label = h.titleKa, value = picks[h].orEmpty(), suggestions = people, onValueChange = { picks[h] = it })
    }
    OutlinedTextField(notes, { notes = it }, label = { Text(L("განცხადებები")) }, modifier = Modifier.fillMaxWidth())
    val yz = YahrzeitTools.within(state.yahrzeits, 8).map { "${it.item.deceasedName} — ${it.item.relatedMemberName} (${it.daysUntil} ${L("დღეში")})" }
    val kid = state.registry.filter { it.kind == RegistryKind.KIDDUSH_CAL.name && it.dueMillis in (fri.timeInMillis - 86_400_000L)..(sat.timeInMillis + 86_400_000L) }.map { "${it.memberName} — ${it.title}" }
    val text = BimahPlan.text(shul, d3(sat.timeInMillis) + " • " + hebOf(sat.timeInMillis), parasha, BimahPlan.standardHonours.map { it.titleKa to picks[it].orEmpty() }, yz, kid, notes)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { Share.text(ctx, text) }, modifier = Modifier.weight(1f)) { Text(L("ტექსტი")) }
        Button(onClick = {
            val l = text.lines()
            PdfMaker.share(ctx, PdfMaker.build(ctx, "bimah_${d3(sat.timeInMillis)}", PdfMaker.Doc(shul, l.getOrElse(1) { "" }, l.drop(2))), L("ბიმას გეგმა"))
        }, modifier = Modifier.weight(1f).testTag("btn_bimah_pdf")) { Text("PDF") }
    }
}

/** Budget alarm, minyan stars and the annual meeting report. */
@Composable
fun BudgetAlarmTool(state: GabbaiUiState) {
    val s = LocalAppSettings.current
    val b = BudgetAlarm.status(state.transactions, state.kollelStudents, s.utilityBudget)
    Card2(if (b.alarm) Icons.Default.Warning else Icons.Default.Savings, L("ბიუჯეტის განგაში (ეს თვე)")) {
        Text(Lf("შემოსავალი: {0}", money(b.income, s.currency)), color = CosmicTextPrimary)
        Text(Lf("გასავალი: {0}", money(b.expense, s.currency)), color = CosmicTextPrimary)
        Text(Lf("ფიქსირებული ხარჯები (სტიპენდიები + კომუნალური ბიუჯეტი): {0}", money(b.fixed, s.currency)), color = CosmicTextSecondary, fontSize = 12.sp)
        if (b.alarm) Text(Lf("⚠ ხარჯების დასაფარად აკლია {0}", money(b.shortfall, s.currency)), color = CosmicCelestialGold, fontWeight = FontWeight.Bold, modifier = Modifier.testTag("budget_alarm"))
        else Text(L("✓ ამ თვის ხარჯები დაფარულია"), color = CosmicTextSecondary, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MinyanStarsTool(state: GabbaiUiState, vm: GabbaiViewModel) {
    val ctx = LocalContext.current
    val prayers = listOf(L("შახარითი"), L("მინხა"), L("ყარბითი"))
    var prayer by remember { mutableStateOf(prayers[0]) }
    val present = remember { mutableStateListOf<String>() }
    val living = state.members.filter { it.status == MemberStatus.ACTIVE }
    val monthStart = remember { Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0) }.timeInMillis }
    val rank = MinyanStars.ranking(state.registry, monthStart)
    val missing = MinyanStars.missing(state.registry, state.members, 30)
    Card2(Icons.Default.Star, L("მინიანის დასწრების ვარსკვლავები")) {
        AppDropdown(label = L("ლოცვა"), value = prayer, options = prayers, optionLabel = { it }, onSelected = { prayer = it })
        Text(Lf("მონიშნეთ მოსულები ({0})", present.size), color = CosmicTextMuted, fontSize = 12.sp)
        living.forEach { m ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(m.fullName in present, { if (it) present.add(m.fullName) else present.remove(m.fullName) })
                Text(nb(m.fullName), color = CosmicTextPrimary)
            }
        }
        Button(enabled = present.isNotEmpty(), onClick = {
            present.forEach { vm.saveRegistry(RegistryEntity(kind = RegistryKind.MINYAN.name, title = prayer, memberName = it, status = RegistryStatus.DONE), postToFinance = false) }
            present.clear()
        }, modifier = Modifier.fillMaxWidth().testTag("btn_minyan_save")) { Text(L("დასწრების შენახვა")) }
        HorizontalDivider()
        Text(L("ამ თვის მადლობის სია:"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
        if (rank.isEmpty()) Text(L("ჩანაწერი არ არის"), color = CosmicTextMuted)
        rank.take(15).forEach { r -> Text("${"★".repeat(MinyanStars.stars(r.count))} ${nb(r.name)} — ${r.count}", color = CosmicCelestialGold, fontSize = 13.sp) }
        if (missing.isNotEmpty()) {
            Text(Lf("30 დღეზე მეტია არ მოსულა: {0}", missing.size), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
            missing.take(10).forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(nb(m.fullName), color = CosmicTextSecondary, modifier = Modifier.weight(1f))
                    if (m.phone.isNotBlank()) TextButton(onClick = { Share.whatsapp(ctx, m.phone, Lf("შალომ {0}! გვენატრებით სინაგოგაში — მოგელით მინიანზე.", m.fullName)) }) { Text("WhatsApp") }
                }
            }
        }
    }
}

@Composable
fun AnnualReportTool(state: GabbaiUiState) {
    val s = LocalAppSettings.current
    val ctx = LocalContext.current
    var year by remember { mutableStateOf(Calendar.getInstance().get(Calendar.YEAR).toString()) }
    val y = year.toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
    val lines = AnnualReport.lines(s.shulName(), AnnualReport.figures(y, state.transactions, state.aliyot, state.events), AnnualReport.figures(y - 1, state.transactions, state.aliyot, state.events), s.currency)
    Card2(Icons.Default.Assessment, L("კრების წლიური ანგარიში")) {
        OutlinedTextField(year, { year = it.filter(Char::isDigit).take(4) }, label = { Text(L("წელი")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        lines.drop(2).take(6).forEach { Text(it, color = CosmicTextPrimary, fontSize = 13.sp) }
        Button(onClick = { PdfMaker.share(ctx, PdfMaker.build(ctx, "annual_report_$y", PdfMaker.Doc(lines[0], lines[1], lines.drop(3), seal = s.shulName())), lines[1]) },
            modifier = Modifier.fillMaxWidth().testTag("btn_annual_pdf")) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(6.dp)); Text(L("ანგარიშის PDF")) }
    }
}
