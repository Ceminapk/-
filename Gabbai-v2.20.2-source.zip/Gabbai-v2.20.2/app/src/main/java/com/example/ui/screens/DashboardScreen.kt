package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TransactionType
import com.example.data.security.CosmicVault
import com.example.ui.components.CosmicCryptoBadge
import com.example.ui.components.CosmicGlassCard
import com.example.ui.components.CosmicMetricCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiScreen
import com.example.ui.viewmodel.GabbaiUiState
import com.example.ui.settings.*
import com.example.ui.calendar.CalendarPrefs
import com.example.ui.calendar.JewishCalendar
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(
    state: GabbaiUiState,
    settings: AppSettings,
    onNavigate: (GabbaiScreen) -> Unit,
    onOpenVoice: () -> Unit = {},
    onExport: () -> Unit = {},
    onQuickNeder: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val dateFormatter = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    var detail by remember { mutableStateOf<MetricDetail?>(null) }
    detail?.let { MetricDetailDialog(it, state, onNavigate) { detail = null } }
    var kiosk by remember { mutableStateOf(false) }
    if (kiosk) KioskDialog(state, settings) { kiosk = false }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
    ) {
        // 1. Hero Cosmic Sanctuary Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .border(1.dp, CosmicBorderGlow, RoundedCornerShape(22.dp))
            ) {
                AnimatedDome()

                // Dark gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    CosmicDeepSpace.copy(alpha = 0.85f),
                                    CosmicDeepSpace
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    val shulSettings = com.example.ui.settings.LocalAppSettings.current
                    if (shulSettings.synagogueName.isNotBlank()) Text(
                        text = shulSettings.emblem + "  " + shulSettings.synagogueName,
                        color = CosmicCelestialGold, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(6.dp))
                    HeroShabbatTimes(settings.shabbatTimesDaily)
                }
            }
        }

        item {
            val city = CalendarPrefs.city
            val cal = Calendar.getInstance()
            val day = remember(city, cal.get(Calendar.DAY_OF_YEAR)) { JewishCalendar.day(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), city) }
            val prayers = remember(day, city) { JewishCalendar.prayerTimes(day, city) }
            val ticker = listOf(
                L("შახარითი") + " ${settings.shacharitTime}",
                L("ნეც") + " ${formatTime(day.sunrise, city)}",
                L("სოფ ზმან შემა") + " ${formatTime(day.sofShema, city)}",
                L("მინხა") + " ${formatTime(prayers.first, city)}",
                L("შკია") + " ${formatTime(day.sunset, city)}",
                L("ყარბითი") + " ${formatTime(prayers.second, city)}",
                L("ცეთ") + " ${formatTime(day.tzeit, city)}"
            ).joinToString("    ✦    ")
            ZmanimTickerBar(ticker, onHolidays = { CalendarFocus.holidays = true; onNavigate(GabbaiScreen.CALENDAR) }, onZmanim = { CalendarFocus.zmanim = true; onNavigate(GabbaiScreen.CALENDAR) }, onKiosk = { kiosk = true })
        }

        // 2. Metrics Row 1: Balance & Outstanding Pledges
        item {
            Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Max),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CosmicMetricCard(
                    title = L("წმინდა ბალანსი (יתרה)"),
                    value = money(state.netBalance),
                    subtitle = L("აქტიური სალარო"),
                    icon = Icons.Default.AccountBalance,
                    accentColor = if (state.netBalance >= 0) CosmicStardustCyan else CosmicAlertRose,
                    modifier = Modifier.weight(1f),
                    testTag = "card_balance",
                    onClick = { detail = MetricDetail.BALANCE }
                )

                CosmicMetricCard(
                    title = L("დავალიანება (חובות)"),
                    value = money(state.totalOutstandingPledges),
                    subtitle = L("ნედერები & საწევრო"),
                    icon = Icons.Default.PendingActions,
                    accentColor = CosmicCelestialGold,
                    modifier = Modifier.weight(1f),
                    testTag = "card_pledges",
                    onClick = { detail = MetricDetail.DEBT }
                )
            }
        }

        // 3. Metrics Row 2: Incomes & Expenses
        item {
            Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Max),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CosmicMetricCard(
                    title = L("სულ შემოსავალი (הכנסות)"),
                    value = signedMoney(state.totalIncome, true),
                    subtitle = L("ალიები, შემოწირულობები"),
                    icon = Icons.Default.TrendingUp,
                    accentColor = CosmicEmeraldSuccess,
                    modifier = Modifier.weight(1f),
                    testTag = "card_income",
                    onClick = { detail = MetricDetail.INCOME }
                )

                CosmicMetricCard(
                    title = L("სულ გასავალი (הוצאות)"),
                    value = signedMoney(state.totalExpense, false),
                    subtitle = L("ხელფასები, ქოლელი, დენი"),
                    icon = Icons.Default.TrendingDown,
                    accentColor = CosmicAlertRose,
                    modifier = Modifier.weight(1f),
                    testTag = "card_expense",
                    onClick = { detail = MetricDetail.EXPENSE }
                )
            }
        }


        // Upcoming birthdays (lead time from settings) — tap opens the members list.
        item {
            val birthdays = remember(state.members, settings.birthdayReminderDays) {
                com.example.ui.calendar.BirthdayTools.within(state.members, settings.birthdayReminderDays)
            }
            if (birthdays.isNotEmpty()) CosmicGlassCard(Modifier.fillMaxWidth().clickable { onNavigate(GabbaiScreen.MEMBERS) }.testTag("birthday_card")) {
                Text(L("მოახლოებული დაბადების დღეები"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                Spacer(Modifier.height(6.dp))
                birthdays.take(6).forEach { b ->
                    Text(b.member.fullName, color = CosmicTextPrimary, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Clip, modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE))
                    Text(
                        (if (b.daysUntil == 0) L("დღეს!") else Lf("{0} დღეში", b.daysUntil)) + " • " +
                            com.example.ui.components.DualDates.gregorianText(b.dateMillis) + " • " + Lf("{0} წელი", b.turningAge),
                        color = CosmicCelestialGold, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(4.dp))
                }
            }
        }

        // 4. Quick Action Cosmic Panel
        item { QuickAccessPanel(onNavigate, onQuickNeder) }

        // 5. Active Torah Aliyot Bids Summary
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = L("ბოლო ალიები და ფასუკები"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = LocalGabbaiPalette.current.text,
                    lineHeight = 25.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = Lf("ყველა ({0})", state.aliyot.size),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.clickable { onNavigate(GabbaiScreen.ALIYOT) }
                )
            }
        }

        items(state.aliyot.take(3)) { aliyah ->
            CosmicGlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 14.dp,
                borderColor = CosmicCelestialGold.copy(alpha = 0.3f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = aliyah.aliyahType.titleKa, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = CosmicCelestialGold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(text = "(${aliyah.aliyahType.titleHe})", fontSize = 11.sp, color = CosmicTextSecondary, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                        Text(
                            text = aliyah.winnerName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CosmicTextPrimary,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = nb(aliyah.parashaName),
                            style = MaterialTheme.typography.bodySmall,
                            color = CosmicTextMuted,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = money(aliyah.amount, aliyah.currency),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = CosmicStardustCyan
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (aliyah.status == com.example.data.model.TransactionStatus.PAID)
                                CosmicEmeraldSuccess.copy(alpha = 0.2f)
                            else
                                CosmicAlertRose.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = if (aliyah.status == com.example.data.model.TransactionStatus.PAID) L("გადახდილია") else L("ნედერი (ვალი)"),
                                fontSize = 11.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
                                color = if (aliyah.status == com.example.data.model.TransactionStatus.PAID) CosmicEmeraldSuccess else CosmicAlertRose,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // 6. Recent Ledger Transactions with SHA-256 Hash
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = L("სალაროს ბოლო ტრანზაქციები"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = LocalGabbaiPalette.current.text,
                    lineHeight = 25.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = Lf("სრულად ({0})", state.transactions.size),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.clickable { onNavigate(GabbaiScreen.FINANCES) }
                )
            }
        }

        items(state.transactions.take(4)) { tx ->
            CosmicGlassCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 14.dp,
                borderColor = if (tx.type == TransactionType.INCOME) CosmicEmeraldSuccess.copy(alpha = 0.2f) else CosmicAlertRose.copy(alpha = 0.2f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    if (tx.type == TransactionType.INCOME) CosmicEmeraldSuccess.copy(alpha = 0.15f)
                                    else CosmicAlertRose.copy(alpha = 0.15f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (tx.type == TransactionType.INCOME) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                contentDescription = null,
                                tint = if (tx.type == TransactionType.INCOME) CosmicEmeraldSuccess else CosmicAlertRose,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = nb(tx.title),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = CosmicTextPrimary,
                                maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = dateFormatter.format(Date(tx.dateMillis)),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = CosmicTextMuted
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = CosmicVault.formatShortHash(tx.hash),
                                    fontSize = 11.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
                                    color = CosmicStardustCyan.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }

                    Text(
                        text = signedMoney(tx.amount, tx.type == TransactionType.INCOME, tx.currency),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (tx.type == TransactionType.INCOME) CosmicEmeraldSuccess else CosmicAlertRose
                    )
                }
            }
        }
    }
}

@Composable
fun QuickActionIcon(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f))
                .border(1.dp, color.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                 modifier = Modifier.size(21.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            color = LocalGabbaiPalette.current.secondaryText,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
    }
}


enum class MetricDetail { BALANCE, DEBT, INCOME, EXPENSE }

@Composable
fun MetricDetailDialog(kind: MetricDetail, state: GabbaiUiState, onNavigate: (GabbaiScreen) -> Unit, onDismiss: () -> Unit) {
    val fmt = remember { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()) }
    val pal = LocalGabbaiPalette.current
    val txs = state.transactions
    val green = CosmicEmeraldSuccess; val rose = CosmicAlertRose; val gold = CosmicCelestialGold
    val title = when (kind) {
        MetricDetail.BALANCE -> L("წმინდა ბალანსი (יתרה)")
        MetricDetail.DEBT -> L("დავალიანება (חובות)")
        MetricDetail.INCOME -> L("სულ შემოსავალი (הכנסות)")
        MetricDetail.EXPENSE -> L("სულ გასავალი (הוצאות)")
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            val ctx = androidx.compose.ui.platform.LocalContext.current
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(nb(title), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                IconButton(onClick = { com.example.data.export.XlsxExporter.shareSheets(ctx, com.example.data.export.XlsxExporter.metricSheets(state, kind.name), csv = false, subject = "Gabbai — " + title) }, modifier = Modifier.testTag("metric_export")) {
                    Icon(Icons.Default.FileDownload, L("სწრაფი ექსპორტი"), tint = gold)
                }
            }
        },
        text = {
            LazyColumn(Modifier.heightIn(max = 480.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                @Composable fun line(a: String, b: String, c: Color = pal.text, sub: String = "") {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.copy(alpha = .07f)).padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(nb(a), Modifier.weight(1f), color = pal.text)
                            Spacer(Modifier.width(8.dp))
                            Text(b, color = c, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                        }
                        if (sub.isNotBlank()) Text(sub, color = pal.secondaryText, fontSize = 11.sp)
                    }
                }
                when (kind) {
                    MetricDetail.BALANCE -> {
                        item { line(L("სულ შემოსავალი (הכנסות)"), signedMoney(state.totalIncome, true), green) }
                        item { line(L("სულ გასავალი (הוצאות)"), signedMoney(state.totalExpense, false), rose) }
                        item { line(L("წმინდა ბალანსი (יתרה)"), money(state.netBalance), if (state.netBalance >= 0) green else rose) }
                        item { line(L("დავალიანება (חובות)"), money(state.totalOutstandingPledges), gold) }
                        val byCur = txs.groupBy { it.currency }
                        if (byCur.size > 1) items(byCur.entries.toList()) { (cur, l) ->
                            val n = l.sumOf { if (it.type == TransactionType.INCOME) it.amount else -it.amount }
                            line(cur, money(n, cur))
                        }
                        val months = txs.groupBy { SimpleDateFormat("MM.yyyy", Locale.getDefault()).format(Date(it.dateMillis)) }.entries.sortedByDescending { it.value.maxOf { t -> t.dateMillis } }.take(6)
                        items(months) { (m, l) ->
                            val inc = l.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
                            val exp = l.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
                            line(m, money(inc - exp), if (inc >= exp) green else rose, "+${money(inc)}  /  -${money(exp)}")
                        }
                    }
                    MetricDetail.DEBT -> {
                        val debtors = state.members.filter { it.outstandingDebt > 0 }.sortedByDescending { it.outstandingDebt }
                        val pledged = state.aliyot.filter { it.status == com.example.data.model.TransactionStatus.PLEDGED }.sortedByDescending { it.dateMillis }
                        if (debtors.isEmpty() && pledged.isEmpty()) item { Text(L("დავალიანება არ არის"), color = pal.secondaryText) }
                        if (debtors.isNotEmpty()) item { Text(L("წევრები") + " (${debtors.size})", fontWeight = FontWeight.Bold, color = pal.text) }
                        items(debtors) { m -> line(m.fullName, money(m.outstandingDebt), gold) }
                        if (pledged.isNotEmpty()) item { Text(L("ალიები") + " (${pledged.size})", fontWeight = FontWeight.Bold, color = pal.text) }
                        items(pledged) { a -> line(a.winnerName, money(a.amount, a.currency), gold, a.parashaName + " • " + fmt.format(Date(a.dateMillis))) }
                    }
                    MetricDetail.INCOME, MetricDetail.EXPENSE -> {
                        val type = if (kind == MetricDetail.INCOME) TransactionType.INCOME else TransactionType.EXPENSE
                        val c = if (type == TransactionType.INCOME) green else rose
                        val list = txs.filter { it.type == type }.sortedByDescending { it.dateMillis }
                        if (list.isEmpty()) item { Text(L("ჩანაწერი არ არის"), color = pal.secondaryText) }
                        val cats = list.groupBy { it.category }.entries.sortedByDescending { e -> e.value.sumOf { it.amount } }
                        if (cats.isNotEmpty()) item { Text(L("კატეგორიები"), fontWeight = FontWeight.Bold, color = pal.text) }
                        items(cats) { (cat, l) -> line(cat.titleKa, money(l.sumOf { it.amount }), c, "${l.size} × • ${cat.titleHe}") }
                        if (list.isNotEmpty()) item { Text(L("ბოლო ოპერაციები"), fontWeight = FontWeight.Bold, color = pal.text) }
                        items(list.take(30)) { t -> line(t.title, signedMoney(t.amount, type == TransactionType.INCOME, t.currency), c, listOf(fmt.format(Date(t.dateMillis)), t.memberName, t.paymentMethod).filter { it.isNotBlank() }.joinToString(" • ")) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onDismiss(); onNavigate(if (kind == MetricDetail.DEBT) GabbaiScreen.MEMBERS else GabbaiScreen.FINANCES) }) {
                Text(if (kind == MetricDetail.DEBT) L("წევრები") else L("ფინანსები"))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L("დახურვა")) } }
    )
}


/** Living dome: slow celestial sway and drift, twinkling stars, a rotating light halo and a passing shimmer. */
@Composable
private fun AnimatedDome() {
    val style = com.example.ui.settings.LocalAppSettings.current.domeStyle
    if (style == com.example.ui.settings.DomeStyle.STILL) {
        Image(painter = painterResource(id = R.drawable.cosmic_synagogue_hero_1790845710719), contentDescription = "Cosmic Synagogue Sanctuary",
            contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        return
    }
    val jerusalem = style == com.example.ui.settings.DomeStyle.JERUSALEM
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "dome")
    fun spec(ms: Int, rev: Boolean = true) = androidx.compose.animation.core.infiniteRepeatable<Float>(
        androidx.compose.animation.core.tween(ms, easing = androidx.compose.animation.core.LinearEasing),
        if (rev) androidx.compose.animation.core.RepeatMode.Reverse else androidx.compose.animation.core.RepeatMode.Restart)
    val sway by t.animateFloat(-4f, 4f, spec(14000), label = "sway")
    val zoom by t.animateFloat(1.22f, 1.38f, spec(18000), label = "zoom")
    val drift by t.animateFloat(-1f, 1f, spec(22000), label = "drift")
    val spin by t.animateFloat(0f, 360f, spec(30000, false), label = "spin")
    val tw by t.animateFloat(0f, 1f, spec(5000, false), label = "tw")
    val sweep by t.animateFloat(-0.4f, 1.4f, spec(6500, false), label = "sweep")
    val stars = remember { val r = java.util.Random(7); List(46) { floatArrayOf(r.nextFloat(), r.nextFloat() * 0.7f, r.nextFloat(), 1f + r.nextFloat() * 2.2f) } }
    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.cosmic_synagogue_hero_1790845710719),
            contentDescription = "Cosmic Synagogue Sanctuary",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = zoom; scaleY = zoom; rotationZ = sway
                translationX = drift * size.width * 0.05f
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0.15f)
            }
        )
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val c = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height * 0.1f)
            // Rotating halo rays from the dome's apex
            rotate(spin, c) {
                for (i in 0 until 12) {
                    rotate(i * 30f, c) {
                        drawRect(
                            Brush.verticalGradient(listOf(if (jerusalem) Color(0x99FFC94A) else Color(0x55FFE9A8), Color.Transparent), startY = c.y, endY = c.y + size.height),
                            topLeft = androidx.compose.ui.geometry.Offset(c.x - 3f, c.y), size = androidx.compose.ui.geometry.Size(6f, size.height)
                        )
                    }
                }
            }
            drawCircle(Brush.radialGradient(listOf(Color(0x66FFE9A8), Color.Transparent), c, size.height * 0.6f), size.height * 0.6f, c)
            // Twinkling stars
            if (!jerusalem) stars.forEach { st ->
                val a = ((kotlin.math.sin((tw + st[2]) * 2 * Math.PI) + 1) / 2).toFloat()
                drawCircle(Color.White.copy(alpha = 0.15f + 0.85f * a), st[3] * (0.6f + 0.6f * a), androidx.compose.ui.geometry.Offset(st[0] * size.width, st[1] * size.height))
            }
            // Passing shimmer
            val x = sweep * size.width
            drawRect(Brush.linearGradient(listOf(Color.Transparent, Color(0x33FFFFFF), Color.Transparent),
                start = androidx.compose.ui.geometry.Offset(x - 120f, 0f), end = androidx.compose.ui.geometry.Offset(x + 120f, size.height)))
        }
    }
}
