package com.example.ui.components

import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.foundation.clickable
import com.example.ui.settings.L
import com.example.ui.settings.Lf

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.random.Random

/**
 * Cosmic Animated Starfield & Nebula Canvas background.
 * Draws subtle twinkling stars and celestial glow.
 */
@Composable
fun CosmicAnimatedBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val palette = LocalGabbaiPalette.current
    val infiniteTransition = rememberInfiniteTransition(label = "cosmic_nebula")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.45f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Pre-calculate fixed star positions
    val stars = remember {
        List(60) {
            Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 2f + 1f)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(palette.background)
            .drawBehind {
                val topGlow = if (palette.isNight) NightGold else NightGold
                val bottomGlow = if (palette.isNight) NightCyan else DayTeal
                // Reflected ambient light, adapted to each lighting mode
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(topGlow.copy(alpha = pulse * 0.22f), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.15f),
                        radius = size.width * 0.8f
                    )
                )

                // Stardust cyan nebula at bottom left
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(bottomGlow.copy(alpha = pulse * 0.16f), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.85f),
                        radius = size.width * 0.7f
                    )
                )

                // Golden Torah glow in center
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf((if (palette.isNight) NightGold else DayGold).copy(alpha = 0.08f), Color.Transparent),
                        center = Offset(size.width * 0.5f, size.height * 0.4f),
                        radius = size.width * 0.6f
                    )
                )

                // Draw starry particles
                if (palette.isNight) stars.take(18).forEach { (nx, ny, r) ->
                    val x = nx * size.width
                    val y = ny * size.height
                    drawCircle(
                        color = palette.text.copy(alpha = 0.10f + (r / 3f) * 0.12f),
                        radius = r,
                        center = Offset(x, y)
                    )
                }
            }
    ) {
        content()
    }
}

/**
 * Ultra-Modern Cosmic Glass Card with subtle stardust border.
 */
@Composable
fun CosmicGlassCard(
    modifier: Modifier = Modifier,
    borderColor: Color = LocalGabbaiPalette.current.border,
    cornerRadius: Dp = 26.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .shadow(8.dp, RoundedCornerShape(cornerRadius), ambientColor = Color(0x330C3B2E), spotColor = Color(0x330C3B2E))
            .clip(RoundedCornerShape(cornerRadius))
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        borderColor.copy(alpha = 0.35f),
                        borderColor.copy(alpha = 0.15f),
                        borderColor.copy(alpha = 0.30f)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            ),
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.cardColors(
            containerColor = LocalGabbaiPalette.current.glass
        )
    ) {
        val footer = LocalCardFooter.current
        Column(modifier = Modifier.padding(18.dp)) {
            CompositionLocalProvider(LocalCardFooter provides null) {
                content()
                if (footer != null) {
                    HorizontalDivider(Modifier.padding(top = 10.dp), color = borderColor.copy(alpha = 0.18f))
                    footer()
                }
            }
        }
    }
}

/** Actions (edit / delete) rendered inside the next CosmicGlassCard, never floating outside it. */
val LocalCardFooter = staticCompositionLocalOf<(@Composable () -> Unit)?> { null }

@Composable
fun RecordCard(actions: @Composable () -> Unit, card: @Composable () -> Unit) {
    CompositionLocalProvider(LocalCardFooter provides actions) { card() }
}

/**
 * Cosmic Metric Card for Dashboards and Financial analytics.
 */
@Composable
fun CosmicMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    testTag: String = "metric_card",
    onClick: (() -> Unit)? = null
) {
    CosmicGlassCard(
        modifier = modifier.fillMaxHeight().testTag(testTag).then(if (onClick != null) Modifier.clip(RoundedCornerShape(22.dp)).clickable(onClick = onClick) else Modifier),
        borderColor = accentColor.copy(alpha = 0.4f)
    ) {
        // Icon + title on one line, the amount gets the full card width so it never gets cut.
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f))
                    .border(1.dp, accentColor.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.weight(1f))
            if (onClick != null) Icon(androidx.compose.material.icons.Icons.Default.ChevronRight, null, tint = accentColor, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = com.example.ui.settings.nb(title),
            style = MaterialTheme.typography.labelMedium,
            color = LocalGabbaiPalette.current.secondaryText,
            minLines = 2,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 16.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            fontSize = if (value.length > 11) 17.sp else 20.sp,
            color = LocalGabbaiPalette.current.text,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = accentColor,
            fontSize = 11.sp,
            minLines = 2,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 14.sp
        )
    }
}

/**
 * Cryptographic verification badge showing AES-256 & SHA-256 integrity.
 */
@Composable
fun CosmicCryptoBadge(
    hash: String = "SHA-256 Verified",
    isVerified: Boolean = true,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = if (isVerified) CosmicStardustCyan.copy(alpha = 0.12f) else CosmicAlertRose.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isVerified) CosmicStardustCyan.copy(alpha = 0.5f) else CosmicAlertRose.copy(alpha = 0.6f)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isVerified) Icons.Default.Lock else Icons.Default.Warning,
                contentDescription = "Crypto badge",
                tint = if (isVerified) CosmicStardustCyan else CosmicAlertRose,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = hash,
                color = if (isVerified) CosmicStardustCyan else CosmicAlertRose,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 11.sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * Top App Bar with cosmic styling, date, and security lock indicator.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CosmicTopBar(
    currentTitle: String,
    subtitle: String,
    isVaultUnlocked: Boolean,
    onToggleVault: () -> Unit,
    onOpenDocs: () -> Unit,
    onOpenAssistant: () -> Unit = {},
    onOpenVoice: () -> Unit = {},
    onToggleTheme: () -> Unit = {},
    onToggleLanguage: () -> Unit = {},
    isNight: Boolean = true,
    languageCode: String = "KA",
    onBackup: () -> Unit = {},
    onRestore: () -> Unit = {},
    onWipe: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    onQuickExport: () -> Unit = {},
    onSos: () -> Unit = {},
    onSelectLanguage: (com.example.ui.settings.AppLanguage) -> Unit = {},
    modifier: Modifier = Modifier
) {
    TopAppBar(
        title = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = currentTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = LocalGabbaiPalette.current.text,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = LocalGabbaiPalette.current.secondaryText,
                    fontSize = 11.sp,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        actions = {
            SosLamp(onSos)
            var langOpen by remember { mutableStateOf(false) }
            Box {
                Surface(onClick = { langOpen = true }, shape = RoundedCornerShape(10.dp), color = CosmicCelestialGold.copy(alpha = .12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CosmicCelestialGold.copy(alpha = .45f)), modifier = Modifier.padding(horizontal = 2.dp).testTag("btn_language")) {
                    Row(Modifier.padding(start = 8.dp, end = 2.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(languageCode, style = MaterialTheme.typography.labelLarge, color = CosmicCelestialGold)
                        Icon(Icons.Default.ArrowDropDown, null, tint = CosmicCelestialGold, modifier = Modifier.size(18.dp))
                    }
                }
                DropdownMenu(expanded = langOpen, onDismissRequest = { langOpen = false }) {
                    val flags = mapOf("KA" to "🇬🇪", "RU" to "🇷🇺", "EN" to "🇬🇧", "HE" to "🇮🇱")
                    com.example.ui.settings.AppLanguage.values().forEach { lang ->
                        DropdownMenuItem(
                            text = { Text(lang.nativeName, fontWeight = if (lang.short == languageCode) FontWeight.Bold else FontWeight.Normal, maxLines = 1) },
                            leadingIcon = { Text(flags[lang.short] ?: "🌐") },
                            trailingIcon = { if (lang.short == languageCode) Icon(Icons.Default.Check, null, tint = CosmicCelestialGold) },
                            onClick = { langOpen = false; onSelectLanguage(lang) },
                            modifier = Modifier.testTag("lang_" + lang.short)
                        )
                    }
                }
            }
            IconButton(onClick = onToggleTheme) {
                Icon(if (isNight) Icons.Default.LightMode else Icons.Default.DarkMode, if (isNight) L("დღის რეჟიმი") else L("ღამის რეჟიმი"), tint = CosmicCelestialGold)
            }
            var menuExpanded by remember { mutableStateOf(false) }
            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(Icons.Default.MoreVert, L("მეტი მოქმედება"), tint = LocalGabbaiPalette.current.text)
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(text = { Text(L("სწრაფი ექსპორტი") + " • Excel", maxLines = 1) }, leadingIcon = { Icon(Icons.Default.FileDownload, null, tint = CosmicCelestialGold) }, onClick = { menuExpanded = false; onQuickExport() }, modifier = Modifier.testTag("btn_quick_export"))
                    DropdownMenuItem(text = { Text(L("პარამეტრები"), maxLines = 1) }, leadingIcon = { Icon(Icons.Default.Settings, null) }, onClick = { menuExpanded = false; onOpenSettings() }, modifier = Modifier.testTag("btn_settings"))
                    DropdownMenuItem(text = { Text(L("ხმოვანი მართვა"), maxLines = 1) }, leadingIcon = { Icon(Icons.Default.Mic, null) }, onClick = { menuExpanded = false; onOpenVoice() })
                    DropdownMenuItem(text = { Text("Gabbai AI", maxLines = 1) }, leadingIcon = { Icon(Icons.Default.AutoAwesome, null) }, onClick = { menuExpanded = false; onOpenAssistant() }, modifier = Modifier.testTag("btn_ai_assistant"))
                    DropdownMenuItem(text = { Text(L("დოკუმენტაცია"), maxLines = 1) }, leadingIcon = { Icon(Icons.Default.Description, null) }, onClick = { menuExpanded = false; onOpenDocs() }, modifier = Modifier.testTag("btn_docs_top"))
                    DropdownMenuItem(text = { Text(L("უსაფრთხოება"), maxLines = 1) }, leadingIcon = { Icon(if (isVaultUnlocked) Icons.Default.LockOpen else Icons.Default.Lock, null) }, onClick = { menuExpanded = false; onToggleVault() }, modifier = Modifier.testTag("btn_vault_toggle"))
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text(com.example.ui.settings.tr(L("სარეზერვო ასლის შექმნა"), "Создать резервную копию"), maxLines = 1) }, leadingIcon = { Icon(Icons.Default.Backup, null) }, onClick = { menuExpanded = false; onBackup() })
                    DropdownMenuItem(text = { Text(com.example.ui.settings.tr(L("ასლიდან აღდგენა"), "Восстановить из копии"), maxLines = 1) }, leadingIcon = { Icon(Icons.Default.Restore, null) }, onClick = { menuExpanded = false; onRestore() })
                    DropdownMenuItem(text = { Text(com.example.ui.settings.tr(L("ბაზის სრული გასუფთავება"), "Полная очистка базы"), maxLines = 1, color = MaterialTheme.colorScheme.error) }, leadingIcon = { Icon(Icons.Default.DeleteForever, null, tint = MaterialTheme.colorScheme.error) }, onClick = { menuExpanded = false; onWipe() })
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = LocalGabbaiPalette.current.glass
        ),
        modifier = modifier
    )
}


/** Small glowing lamp in the top bar that opens the SOS dialog. */
@Composable
fun SosLamp(onClick: () -> Unit) {
    val glow by androidx.compose.animation.core.rememberInfiniteTransition(label = "sos").animateFloat(0.25f, 0.6f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(1400), androidx.compose.animation.core.RepeatMode.Reverse), label = "g")
    IconButton(onClick = onClick, modifier = Modifier.testTag("btn_sos")) {
        Box(contentAlignment = Alignment.Center) {
            Box(Modifier.size(30.dp).clip(androidx.compose.foundation.shape.CircleShape).background(
                androidx.compose.ui.graphics.Brush.radialGradient(listOf(CosmicAlertRose.copy(alpha = glow), androidx.compose.ui.graphics.Color.Transparent))))
            Icon(Icons.Default.Lightbulb, L("SOS — საგანგებო"), tint = CosmicAlertRose, modifier = Modifier.size(21.dp))
        }
    }
}
