package com.example.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.ui.settings.L

/**
 * One generic journal for the synagogue's smaller registers (mikveh, gemach, orders, lost items…).
 * Each [RegistryKind] decides which fields its form shows and whether a record also posts to finances.
 */
@Entity(tableName = "registry_entries")
data class RegistryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val title: String,
    @ColumnInfo(defaultValue = "") val memberName: String = "",
    @ColumnInfo(defaultValue = "") val phone: String = "",
    @ColumnInfo(defaultValue = "0") val dateMillis: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "0") val dueMillis: Long = 0L,
    @ColumnInfo(defaultValue = "0") val amount: Double = 0.0,
    @ColumnInfo(defaultValue = "0") val paidAmount: Double = 0.0,
    @ColumnInfo(defaultValue = "1") val count: Int = 1,
    @ColumnInfo(defaultValue = "GEL") val currency: String = "GEL",
    @ColumnInfo(defaultValue = "OPEN") val status: String = "OPEN",
    @ColumnInfo(defaultValue = "") val details: String = "",
    @ColumnInfo(defaultValue = "") val extra: String = "",
    /** Bounded JPEG thumbnail (lost-and-found item photo). */
    @ColumnInfo(defaultValue = "") val photoBase64: String = ""
)

/** OPEN = active / not returned; DONE = paid, returned, fixed, delivered. */
object RegistryStatus { const val OPEN = "OPEN"; const val DONE = "DONE" }

enum class RegistryKind(
    private val ka: String,
    val he: String,
    val titleLabel: String,
    val hasMember: Boolean = true,
    val hasPhone: Boolean = false,
    val hasAmount: Boolean = false,
    val hasDue: Boolean = false,
    val hasCount: Boolean = false,
    val extraLabel: String? = null,
    val doneLabel: String = "დასრულებულია",
    val openLabel: String = "აქტიური",
    /** When set, paid money is posted to finances with this category. */
    val finance: FinanceCategory? = null,
    val financeType: TransactionType = TransactionType.INCOME,
    val suggestions: List<String> = emptyList()
) {
    MIKVEH("მიკვე — შემოსავალი", "מקווה", "ვიზიტის ტიპი", hasAmount = true, hasCount = true, finance = FinanceCategory.OTHER_INCOME,
        suggestions = listOf("ქალთა მიკვე", "მამაკაცთა მიკვე", "ჭურჭლის ტვილა", "ყოველთვიური აბონემენტი"), doneLabel = "გადახდილია", openLabel = "გადასახდელია"),
    GEMACH("გემახი — უპროცენტო სესხი", "גמ״ח", "სესხის მიზანი", hasPhone = true, hasAmount = true, hasDue = true, extraLabel = "თავდები",
        doneLabel = "დაბრუნებულია", openLabel = "აქტიური სესხი"),
    INSTALLMENT("ნედერის განვადება", "נדר בתשלומים", "ნედერის მიზეზი", hasPhone = true, hasAmount = true, hasCount = true, finance = FinanceCategory.NEDARIM_PLEDGES,
        doneLabel = "სრულად დაფარულია", openLabel = "იფარება"),
    AUCTION("მიცვების აუქციონი", "מכירת מצוות", "მიცვა", hasAmount = true, finance = FinanceCategory.ALIYOT_TORAH,
        suggestions = listOf("ფეთიხათ ჰაარონი", "ქოჰენი", "ლევი", "შელიში", "მაფტირი", "ჰაგბაჰა", "გელილა", "რიმონიმ", "ხათან თორა", "ხათან ბერეშით", "ატა ჰორეითა", "კოლ ჰანეარიმ", "ნეილა — ფეთიხა"),
        doneLabel = "გადახდილია", openLabel = "დაპირებულია"),
    UTILITY("კომუნალური და ხარჯები", "הוצאות שוטפות", "ხარჯის სახე", hasMember = false, hasAmount = true, finance = FinanceCategory.UTILITIES_COMMUNAL, financeType = TransactionType.EXPENSE,
        suggestions = listOf("ელექტროენერგია", "გაზი / გათბობა", "წყალი", "კონდიცირება", "ინტერნეტი", "დამლაგებელი", "დარაჯი", "მცირე რემონტი"), doneLabel = "გადახდილია", openLabel = "გადასახდელია"),
    ORDER("სუქოთის და ფესახის შეკვეთები", "הזמנות ד׳ מינים ומצות", "შეკვეთა", hasPhone = true, hasAmount = true, hasCount = true, finance = FinanceCategory.OTHER_INCOME,
        suggestions = listOf("ეთროგი + ლულავი (არბაათ ჰამინიმ)", "ეთროგი", "ლულავი", "ჰადასიმ", "არავოთ", "შმურა მაცა (ხელის)", "მაცა (მანქანის)", "ღვინო ფესახისთვის"),
        doneLabel = "გაცემულია", openLabel = "მოლოდინში"),
    HANUKKAH("ხანუქას სპონსორები", "חסות חנוכה", "სპონსორობა", hasAmount = true, extraLabel = "საღამო (1–8)", finance = FinanceCategory.KIDDUSH_SPONSOR,
        suggestions = listOf("მენორას ანთება", "სუფგანიოთი", "საჩუქრები ბავშვებისთვის", "ხანუქას ტრაპეზი"), doneLabel = "გადახდილია", openLabel = "დაპირებულია"),
    KAPAROT("ქაფაროთის ცედაკა", "כפרות", "ქაფაროთი", hasAmount = true, hasCount = true, finance = FinanceCategory.TZEDAKAH_INCOME, doneLabel = "გადახდილია", openLabel = "მოლოდინში"),
    CHAMETZ("ხამეცის გაყიდვა", "מכירת חמץ", "მინდობილობა", hasPhone = true, extraLabel = "ხამეცის ადგილი / მისამართი", doneLabel = "გადაეცა რაბინს", openLabel = "მიღებულია"),
    GUESTS("სტუმრები — ჰახნასათ ორხიმ", "הכנסת אורחים", "სტუმრის სახელი", hasPhone = true, hasDue = true, hasCount = true, extraLabel = "მასპინძელი ოჯახი", doneLabel = "განთავსებულია", openLabel = "ელოდება ოჯახს"),
    TEHILLIM("თეჰილიმი — რაფუა / ჰაზქარა", "תהילים", "ვისთვის (მაგ. იოსებ ბენ სარა)", hasMember = false, extraLabel = "მიზეზი", suggestions = listOf("რაფუა შელემა", "ჰაზქარა", "ზივუგი", "ხეზკათ"), doneLabel = "დასრულდა", openLabel = "იკითხება"),
    EMERGENCY("საგანგებო კონტაქტები", "אנשי קשר חירום", "სამსახური", hasMember = false, hasPhone = true,
        suggestions = listOf("ხევრა კადიშა", "მთავარი რაბინი", "სინაგოგის დაცვა", "სასწრაფო დახმარება 112", "პოლიცია", "მოჰელი", "სოფერი"), doneLabel = "არააქტიური", openLabel = "აქტიური"),
    TORAH_DEFECT("სეფერ თორის დეფექტები", "פסולים בספר תורה", "სეფერ თორა", hasMember = false, extraLabel = "ადგილი (წიგნი, ფარაშა, სვეტი, ფასუკი)", doneLabel = "შეკეთებულია (კაშერია)", openLabel = "პასულია — არ გაიხსნას"),
    LOST_FOUND("დაკარგული ნივთები", "השבת אבידה", "ნივთი", suggestions = listOf("ტალითი", "თეფილინი", "სიდური", "ხუმაში", "სათვალე", "ქუდი / კიპა", "ქოლგა"), extraLabel = "სად იპოვეს", doneLabel = "დაუბრუნდა პატრონს", openLabel = "პატრონს ელოდება"),
    LIBRARY("ბიბლიოთეკა — წიგნების გაცემა", "ספרייה", "წიგნი", hasPhone = true, hasDue = true, doneLabel = "დაბრუნებულია", openLabel = "გატანილია"),
    KEYS("გასაღებები და სეიფი", "מפתחות וכספת", "გასაღები / წვდომა", hasPhone = true,
        suggestions = listOf("სინაგოგის მთავარი კარი", "არონ ჰაკოდეში", "სეიფი", "ოფისი", "მიკვე", "სიგნალიზაციის კოდი"), doneLabel = "დაბრუნებულია", openLabel = "ხელთ აქვს"),
    HISTORY("სინაგოგის მატიანე", "דברי הימים", "მოვლენა", suggestions = listOf("სეფერ თორის შემობრძანება", "რაბინის ვიზიტი", "სინაგოგის იუბილე", "რემონტის დასრულება"), extraLabel = "შემომწირველი / მონაწილე", doneLabel = "ისტორიული", openLabel = "ისტორიული"),
    VOICE_MEMO("გაბაის ხმოვანი ჩანიშვნები", "פתקים קוליים", "სათაური", hasMember = false, doneLabel = "შესრულებულია", openLabel = "გასაკეთებელი"),
    // ---- 2.16 ----
    MINYAN("მინიანის დასწრება", "נוכחות במניין", "ლოცვა", suggestions = listOf("შახარითი", "მინხა", "ყარბითი"), doneLabel = "მოვიდა", openLabel = "არ მოსულა"),
    TORAH_PASSPORT("სეფერ თორის პასპორტი", "דרכון ספר תורה", "სეფერ თორა (სახელი / შემომწირველი)", hasMember = false, hasDue = true, extraLabel = "სად არის გადახვეული (ფარაშა)",
        suggestions = listOf("მთავარი სეფერ თორა", "მეორე სეფერ თორა", "მესამე სეფერ თორა", "პატარა სეფერ თორა"), doneLabel = "კაშერია, შემოწმებულია", openLabel = "შესამოწმებელია"),
    PUSHKE("ფუშკების ინკასაცია", "קופות צדקה", "ყუთის ადგილი", hasPhone = true, hasAmount = true, hasDue = true, finance = FinanceCategory.TZEDAKAH_INCOME,
        suggestions = listOf("სინაგოგის შესასვლელი", "ქალთა დარბაზი", "მაღაზია", "ოჯახი", "მიკვე"), extraLabel = "ვინ ამოიღო", doneLabel = "ამოღებულია", openLabel = "ამოსაღებია"),
    PAROCHET("ფარდები და წმინდა ნივთები", "פרוכות ותשמישי קדושה", "ნივთი", hasAmount = true, extraLabel = "შემომწირველი / წარწერა",
        suggestions = listOf("ფაროხეთი (ჩვეულებრივი)", "თეთრი ფაროხეთი (იამიმ ნორაიმ)", "მეილი (თორის ტანსაცმელი)", "თორის გვირგვინი", "რიმონიმი", "იადი", "ბიმას გადასაფარებელი"), doneLabel = "გამოიყენება", openLabel = "საწყობშია"),
    GENIZAH("გენიზა", "גניזה", "რა ჩაიდო", hasMember = false, hasCount = true, hasDue = true, extraLabel = "დაკრძალვის ადგილი",
        suggestions = listOf("გაცვეთილი სიდურები", "ხუმაშები", "თეფილინი", "მეზუზები", "წმინდა ფურცლები"), doneLabel = "დაკრძალულია", openLabel = "ყუთშია"),
    VOLUNTEER("მოხალისეების დაფა", "מתנדבים", "საქმე", hasPhone = true, hasDue = true,
        suggestions = listOf("კიდუშის მომზადება", "დალაგება", "სკამების დაწყობა", "სიდურების დალაგება", "სუქას აშენება", "ჰავდალა"), doneLabel = "შესრულდა", openLabel = "დაგეგმილია"),
    KIDDUSH_CAL("კიდუშის სპონსორების კალენდარი", "לוח חסות קידוש", "მიზეზი", hasPhone = true, hasAmount = true, hasDue = true, finance = FinanceCategory.KIDDUSH_SPONSOR,
        suggestions = listOf("იორცაიტი", "ბავშვის დაბადება", "ქორწილი", "ბარ მიცვა", "მადლიერება", "დაბადების დღე"), extraLabel = "გამოცხადების ტექსტი", doneLabel = "გადახდილია", openLabel = "დაჯავშნილია"),
    BIKUR_CHOLIM("ავადმყოფები და შივა", "ביקור חולים ושבעה", "მდგომარეობა", hasPhone = true, hasDue = true, extraLabel = "მისამართი / საავადმყოფო",
        suggestions = listOf("ავადაა სახლში", "საავადმყოფოშია", "შივაზე ზის", "საჭმლის მიტანა", "შივას მინიანი"), doneLabel = "დასრულდა", openLabel = "მზრუნველობა სჭირდება"),
    NEW_FAMILY("ახალი ოჯახების მიღება", "קליטת משפחות", "ნაბიჯი", hasPhone = true, hasDue = true, extraLabel = "პასუხისმგებელი",
        suggestions = listOf("გაცნობა", "შაბათის სტუმრობა", "ადგილის მიცემა", "წევრად ჩაწერა", "ბავშვების პროგრამა"), doneLabel = "შესრულდა", openLabel = "გასაკეთებელი"),
    RAV_QUESTION("კითხვები რავისთვის", "שאלות לרב", "კითხვა", hasPhone = true, extraLabel = "რავის პასუხი", doneLabel = "პასუხი გაცემულია", openLabel = "პასუხს ელოდება"),
    PROGRAM("ქალთა და ბავშვთა პროგრამები", "תוכניות נשים וילדים", "პროგრამა", hasPhone = true, hasAmount = true, hasCount = true, hasDue = true, finance = FinanceCategory.OTHER_INCOME, extraLabel = "მასწავლებელი",
        suggestions = listOf("ქალთა შიური", "ბავშვთა გაკვეთილი", "ბანაკი", "ბათ მიცვას მომზადება", "ბარ მიცვას მომზადება"), doneLabel = "გადახდილია", openLabel = "გადასახდელია"),
    FUND("მიზნობრივი ფონდები", "קרנות ייעודיות", "ფონდი", hasAmount = true, finance = FinanceCategory.TZEDAKAH_INCOME, extraLabel = "ვის გადაეცა (დამალული)",
        suggestions = listOf("სასწრაფო დახმარება", "ჰახნასათ კალა (საქორწილო)", "დაკრძალვის ხარჯები", "ფიდიონ შვუიმი"), doneLabel = "მიღებულია", openLabel = "დაპირებულია"),
    MAINTENANCE("ქონების მოვლის კალენდარი", "תחזוקת הבניין", "რა უნდა შემოწმდეს", hasPhone = true, hasAmount = true, hasDue = true, extraLabel = "ხელოსანი",
        finance = FinanceCategory.REPAIRS_RENOVATION, financeType = TransactionType.EXPENSE,
        suggestions = listOf("სახურავი", "გათბობა", "კონდიციონერი", "ცეცხლმაქრები", "ელექტროობა", "წყალსადენი", "მიკვეს ფილტრი"), doneLabel = "შემოწმდა", openLabel = "ვადა მოდის"),
    GOAL("ცედაკის მიზნები", "יעדי צדקה", "მიზანი", hasMember = false, hasAmount = true, hasDue = true,
        suggestions = listOf("ახალი სეფერ თორა", "სინაგოგის რემონტი", "ახალი სიდურები", "მიკვე"), doneLabel = "მიღწეულია", openLabel = "გროვდება"),
    MEZUZAH("მეზუზები და თეფილინი", "בדיקת מזוזות ותפילין", "რა შემოწმდა", hasPhone = true, hasDue = true, extraLabel = "სოფერი",
        suggestions = listOf("სახლის მეზუზები", "სინაგოგის მეზუზები", "თეფილინი", "ბავშვის თეფილინი (ბარ მიცვა)"), doneLabel = "შემოწმდა", openLabel = "შესამოწმებელია"),
    MAASER("მაასერის მრიცხველი", "מעשרות", "შემოსავლის წყარო", hasAmount = true, doneLabel = "გაცემულია", openLabel = "გასაცემია"),
    CALL_CHAIN("სასწრაფო შეტყობინებების ჯაჭვი", "שרשרת טלפונים", "ამბავი", hasPhone = true,
        suggestions = listOf("დაკრძალვა", "მინიანი გვჭირდება", "ლოცვის დრო შეიცვალა", "შივა", "სასწრაფო ამბავი"), doneLabel = "ნახა / უპასუხა", openLabel = "ჯერ არ უნახავს"),
    ALIYAH_PLAN("ალიების წინასწარი დარიგება", "חלוקת עליות מראש", "ალია", hasPhone = true, hasDue = true, extraLabel = "შაბათი / ფარაშა",
        doneLabel = "ბიმაზე გადატანილია", openLabel = "დაგეგმილია"),
    SEATING("სინაგოგის ადგილების რუკა", "מפת מקומות", "ადგილი (რიგი-ნომერი)", hasPhone = true, hasAmount = true, finance = FinanceCategory.OTHER_INCOME, extraLabel = "დარბაზი",
        suggestions = listOf("მამაკაცთა დარბაზი", "ქალთა დარბაზი", "იამიმ ნორაიმის ადგილი"), doneLabel = "დაკავებულია", openLabel = "თავისუფალია"),
    MEMO("გაბაის სწრაფი ბლოკნოტი", "פנקס הגבאי", "ჩანაწერი", hasMember = false, hasDue = true, doneLabel = "შესრულდა", openLabel = "გასაკეთებელი"),
    BAR_MITZVAH("ბარ-მიცვას გეგმა", "תכנון בר מצווה", "ნაბიჯი", hasPhone = true, hasDue = true, extraLabel = "ფარაშა / მასწავლებელი",
        suggestions = listOf("თეფილინის შეკვეთა", "ფარაშის სწავლა", "ჰაფტარას სწავლა", "დრაშა", "კიდუში / სეუდა", "პირველი ალია"), doneLabel = "მზადაა", openLabel = "მზადდება"),
    VIP_GUEST("საპატიო სტუმრებისა და რაბინების წიგნი", "ספר אורחים נכבדים", "სტუმარი / წოდება", hasMember = false, hasPhone = true, extraLabel = "საიდან / შეხვედრის მიზეზი",
        suggestions = listOf("რავი", "შალიახი", "მთავარი რაბინი", "სტუმარი ისრაელიდან"), doneLabel = "პატივი მიეგო", openLabel = "მოსალოდნელია"),
    AUDIO_GUIDE("აუდიო-სისტემის გზამკვლევი", "מדריך מערכת הגברה", "მოწყობილობა / ინსტრუქცია", hasMember = false, extraLabel = "ნაბიჯები",
        suggestions = listOf("მიკროფონი ბიმაზე", "დინამიკები", "შაბათის ტაიმერი", "პროექტორი", "ჩამწერი"), doneLabel = "მუშაობს", openLabel = "პრობლემაა"),
    SUPPLIES("ჰავდალა და მარაგები", "מלאי והבדלה", "მარაგი", hasMember = false, hasCount = true, hasAmount = true, finance = FinanceCategory.EVENTS_CATERING, financeType = TransactionType.EXPENSE,
        suggestions = listOf("ღვინო / მიცი", "ჰავდალას სანთელი", "ბესამიმი", "ხალა", "ერთჯერადი ჭიქები", "ყავა და ჩაი", "ნათურები"), doneLabel = "საკმარისია", openLabel = "საყიდელია"),
    TIMERS("შაბათის ტაიმერები და განათება", "שעוני שבת", "ტაიმერი / ზონა", hasMember = false, extraLabel = "ჩართვა – გამორთვა",
        suggestions = listOf("დარბაზის განათება", "ქალთა დარბაზი", "კონდიციონერი / გათბობა", "ცხელი წყლის ქვაბი", "ეზოს განათება", "მიკვე"), doneLabel = "შემოწმდა", openLabel = "შესამოწმებელია"),
    // ---- 2.19 ----
    HALL_BOOKING("დარბაზისა და სუფრების დაჯავშნა", "הזמנת אולם", "ღონისძიება", hasPhone = true, hasAmount = true, hasDue = true, hasCount = true, extraLabel = "სლოტი (დილა / საღამო)",
        finance = FinanceCategory.OTHER_INCOME, suggestions = listOf("ბრიტ მილა", "ბარ მიცვა", "ბათ მიცვა", "ქორწილი", "შევა ბრახოთი", "კიდუში", "ხინა", "მემორიალური სეუდა"),
        doneLabel = "დეპოზიტი გადახდილია", openLabel = "დეპოზიტს ელოდება"),
    CEMETERY("სასაფლაოები და საფლავები (GPS)", "בתי עלמין", "გარდაცვლილი (ზ״ლ)", hasPhone = true, extraLabel = "GPS კოორდინატები (lat, lng)",
        suggestions = listOf("სექტორი / რიგი / საფლავი"), doneLabel = "შემოწმებულია", openLabel = "მოსანახულებელია"),
    HONOR_WALL("საპატიო დაფა და მემორიალური ფირფიტები", "לוח כבוד ונציב זיכרון", "ფირფიტის ტექსტი", hasAmount = true, extraLabel = "დონე (ოქრო / ვერცხლი / ბრინჯაო / ლეილუი ნიშმათ)",
        finance = FinanceCategory.TZEDAKAH_INCOME, suggestions = listOf("ოქროს სპონსორი", "ვერცხლის სპონსორი", "ბრინჯაოს სპონსორი", "ლეილუი ნიშმათ"), doneLabel = "დაფაზეა", openLabel = "მზადდება"),
    FOOD_BASKETS("სადღესასწაულო კალათები (ქიმხა დეფისხა)", "קמחא דפסחא", "ოჯახი", hasPhone = true, hasAmount = true, hasCount = true, extraLabel = "მოხალისე / მიმტანი",
        finance = FinanceCategory.TZEDAKAH_DISBURSEMENT, financeType = TransactionType.EXPENSE,
        suggestions = listOf("ფესახის კალათა", "როშ ჰაშანას კალათა", "სუქოთის კალათა", "ხანუქას საჩუქარი", "პურიმის მიშლოახ მანოთ"), doneLabel = "მიტანილია", openLabel = "მოსამზადებელია"),
    MIKVEH_APPT("მიკვეს კონფიდენციალური ჯავშნები", "תורים למקווה", "ჯავშნის კოდი (სახელის გარეშე)", hasMember = false, hasDue = true, extraLabel = "დრო / ოთახი",
        suggestions = listOf("ქალთა მიკვე", "მამაკაცთა მიკვე", "ჭურჭლის ტვილა"), doneLabel = "შესრულდა", openLabel = "დაჯავშნილია"),
    SHABBAT_PREP("შაბათის დამხმარის ინსტრუქციები", "הכנות לשבת", "დავალება", hasMember = false, extraLabel = "როდის / ვინ",
        suggestions = listOf("განათების ტაიმერი", "გათბობა / კონდიცირება", "ცხელი წყლის ქვაბი (שבת)", "ერუვის შემოწმება", "სანთლები და ღვინო", "საგანგებო ნომრები კედელზე", "კარის საკეტი"),
        doneLabel = "მზადაა", openLabel = "გასაკეთებელია"),
    SYNAGOGUE_DIR("სინაგოგების ბაზა", "מאגר בתי כנסת", "სინაგოგის სახელი", hasMember = false, hasPhone = true, extraLabel = "ქალაქი / მისამართი",
        suggestions = SynagogueDirectory.names, doneLabel = "გადამოწმებულია", openLabel = "გადასამოწმებელია");

    val title: String get() = L(ka)
    val keyKa: String get() = ka
}

object RegistryRules {
    /** Remaining balance of a loan / installment plan; never negative. */
    fun remaining(e: RegistryEntity): Double = (e.amount - e.paidAmount).coerceAtLeast(0.0)

    /** Monthly installment: total split evenly over [RegistryEntity.count] months. */
    fun installment(e: RegistryEntity): Double = if (e.count <= 0) e.amount else e.amount / e.count

    /** Applies one payment and closes the record when it is fully paid. */
    fun pay(e: RegistryEntity, payment: Double): RegistryEntity {
        val paid = (e.paidAmount + payment).coerceAtMost(e.amount)
        return e.copy(paidAmount = paid, status = if (paid >= e.amount - 0.001) RegistryStatus.DONE else RegistryStatus.OPEN)
    }

    /** Total money of a record (unit price × quantity for mikveh / orders / kaparot). */
    fun total(e: RegistryEntity): Double {
        val k = runCatching { RegistryKind.valueOf(e.kind) }.getOrNull()
        return if (k != null && k.hasCount && k != RegistryKind.INSTALLMENT && k != RegistryKind.GUESTS) e.amount * e.count.coerceAtLeast(1) else e.amount
    }

    /** Maaser due: 10% of recorded income minus what was already given. */
    fun maaserDue(rows: List<RegistryEntity>): Double = rows.filter { it.kind == RegistryKind.MAASER.name }.sumOf { it.amount * 0.1 - it.paidAmount }.coerceAtLeast(0.0)

    /** Progress 0..1 of a tzedakah goal (paidAmount = collected so far). */
    fun goalProgress(e: RegistryEntity): Float = if (e.amount <= 0) 0f else (e.paidAmount / e.amount).toFloat().coerceIn(0f, 1f)

    /** Next mezuzah/tefillin check: twice in seven years (~42 months). */
    fun nextMezuzahCheck(lastMillis: Long): Long = java.util.Calendar.getInstance().apply { timeInMillis = lastMillis; add(java.util.Calendar.MONTH, 42) }.timeInMillis

    fun overdue(e: RegistryEntity, now: Long = System.currentTimeMillis()) = e.status == RegistryStatus.OPEN && e.dueMillis in 1 until now

    /** Utilities spent in the calendar month containing [now]. */
    fun monthSpent(all: List<RegistryEntity>, now: Long = System.currentTimeMillis()): Double {
        val c = java.util.Calendar.getInstance().apply { timeInMillis = now }
        return all.filter { it.kind == RegistryKind.UTILITY.name }.filter {
            val d = java.util.Calendar.getInstance().apply { timeInMillis = it.dateMillis }
            d.get(java.util.Calendar.YEAR) == c.get(java.util.Calendar.YEAR) && d.get(java.util.Calendar.MONTH) == c.get(java.util.Calendar.MONTH)
        }.sumOf { it.amount }
    }
}


/** Starter names for the synagogue directory; addresses and phones are filled in by the gabbai (never invented). */
object SynagogueDirectory {
    val names = listOf(
        "თბილისის დიდი სინაგოგა (ქართული)", "თბილისის აშკენაზური სინაგოგა", "ქუთაისის სინაგოგა", "ბათუმის სინაგოგა",
        "ონის სინაგოგა", "ახალციხის სინაგოგა", "კულაშის სინაგოგა", "სურამის სინაგოგა", "ცხინვალის სინაგოგა", "საჩხერის სინაგოგა"
    )
}

/** Rules added in 2.19. */
object V219Rules {
    private fun dayKey(m: Long): Long { val c = java.util.Calendar.getInstance().apply { timeInMillis = m }; return c.get(java.util.Calendar.YEAR) * 1000L + c.get(java.util.Calendar.DAY_OF_YEAR) }

    /** Two open hall bookings on the same day and the same slot are a double booking. */
    fun hallConflicts(rows: List<RegistryEntity>): Set<Long> = rows
        .filter { it.kind == RegistryKind.HALL_BOOKING.name && it.dueMillis > 0 }
        .groupBy { dayKey(it.dueMillis) to it.extra.trim().lowercase() }
        .values.filter { it.size > 1 }.flatten().map { it.id }.toSet()

    /** Parses "41.69, 44.80" into a lat/lng pair; null when invalid. */
    fun parseGps(s: String): Pair<Double, Double>? {
        val p = s.split(',', ';', ' ').map { it.trim() }.filter { it.isNotEmpty() }
        if (p.size != 2) return null
        val lat = p[0].toDoubleOrNull() ?: return null; val lng = p[1].toDoubleOrNull() ?: return null
        return if (lat in -90.0..90.0 && lng in -180.0..180.0) lat to lng else null
    }

    fun mapsUrl(lat: Double, lng: Double) = "https://www.google.com/maps/dir/?api=1&destination=$lat,$lng"

    /** Bar mitzvah preparation progress for one boy: done steps / all steps. */
    fun barMitzvahProgress(rows: List<RegistryEntity>, boy: String): Pair<Int, Int> {
        val l = rows.filter { it.kind == RegistryKind.BAR_MITZVAH.name && it.memberName.equals(boy, true) }
        return l.count { it.status == RegistryStatus.DONE } to l.size
    }

    /** Mezuzot / tefillin whose check is due within [days]. */
    fun mezuzahDueSoon(rows: List<RegistryEntity>, days: Int = 30, now: Long = System.currentTimeMillis()) =
        rows.filter { it.kind == RegistryKind.MEZUZAH.name && it.status == RegistryStatus.OPEN && it.dueMillis > 0 && it.dueMillis <= now + days * 86_400_000L }
}
