package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.calendar.HebDate
import com.example.ui.calendar.JewishCalendar
import com.example.ui.calendar.YahrzeitTools
import com.example.ui.settings.L
import com.example.ui.theme.*
import java.util.Calendar
import java.util.TimeZone

/** Shared date helpers for the combined Gregorian / Hebrew picker. */
object DualDates {
    fun localNoon(y: Int, m: Int, d: Int): Long =
        Calendar.getInstance().apply { clear(); set(y, m - 1, d, 12, 0, 0) }.timeInMillis

    fun hebrewOf(millis: Long): HebDate {
        val c = Calendar.getInstance().apply { timeInMillis = millis }
        return JewishCalendar.toHebrew(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    fun gregorianText(millis: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = millis }
        return "%02d.%02d.%04d".format(c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR))
    }

    fun bothText(millis: Long): String {
        val h = hebrewOf(millis)
        return "${gregorianText(millis)} • ${JewishCalendar.hebrewDateKa(h)}"
    }

    /** Hebrew months valid in a given year (Adar I only exists in leap years). */
    fun monthsFor(year: Int): List<Int> = if (JewishCalendar.isLeap(year)) (0..12).toList() else (0..12).filter { it != 5 }

    fun daysIn(year: Int, month: Int): Int = runCatching {
        android.icu.util.HebrewCalendar(year, month, 1).getActualMaximum(android.icu.util.Calendar.DAY_OF_MONTH)
    }.getOrDefault(30)

    /** Hebrew date → Gregorian local-noon millis. */
    fun fromHebrew(year: Int, month: Int, day: Int): Long? =
        YahrzeitTools.gregorianForHebrew(year, month, day)?.let { m ->
            val c = Calendar.getInstance().apply { timeInMillis = m }
            localNoon(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        }
}

/**
 * One field, two calendars: shows the Gregorian and Hebrew date together and lets the user
 * pick either a Gregorian day or a Hebrew day/month/year; the other side updates automatically.
 * [millis] == 0 means "not set" when [optional] is true.
 */
@Composable
fun DualDateField(
    label: String,
    millis: Long,
    onChange: (Long) -> Unit,
    modifier: Modifier = Modifier,
    optional: Boolean = false
) {
    var open by remember { mutableStateOf(false) }
    val text = if (millis > 0) DualDates.bothText(millis) else L("თარიღი არ არის არჩეული")
    DropdownFace(label = label, text = text, onClick = { open = true }, modifier = modifier.fillMaxWidth())
    if (open) DualDateDialog(
        initial = if (millis > 0) millis else System.currentTimeMillis(),
        optional = optional,
        onDismiss = { open = false },
        onClear = { onChange(0L); open = false },
        onPick = { onChange(it); open = false }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DualDateDialog(initial: Long, optional: Boolean, onDismiss: () -> Unit, onClear: () -> Unit, onPick: (Long) -> Unit) {
    var hebrewMode by remember { mutableStateOf(false) }
    var current by remember { mutableStateOf(initial) }
    val h0 = remember(current) { DualDates.hebrewOf(current) }
    var hy by remember(current) { mutableStateOf(h0.year) }
    var hm by remember(current) { mutableStateOf(h0.month) }
    var hd by remember(current) { mutableStateOf(h0.day) }
    val initialUtc = remember(current) {
        val c = Calendar.getInstance().apply { timeInMillis = current }
        Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { clear(); set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)) }.timeInMillis
    }
    val picker = key(initialUtc) { rememberDatePickerState(initialSelectedDateMillis = initialUtc) }

    fun gregorianFromPicker(): Long? = picker.selectedDateMillis?.let {
        val u = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = it }
        DualDates.localNoon(u.get(Calendar.YEAR), u.get(Calendar.MONTH) + 1, u.get(Calendar.DAY_OF_MONTH))
    }
    val hebrewResult = DualDates.fromHebrew(hy, hm, hd.coerceAtMost(DualDates.daysIn(hy, hm)))

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(shape = MaterialTheme.shapes.extraLarge, color = CosmicDarkSurface, tonalElevation = 6.dp, modifier = Modifier.fillMaxWidth(0.96f).testTag("dual_date_dialog")) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val tabColors = @Composable { sel: Boolean -> ButtonDefaults.buttonColors(containerColor = if (sel) CosmicCelestialGold else CosmicDarkSurface, contentColor = if (sel) CosmicOnAccent else CosmicTextPrimary) }
                    Button(onClick = { gregorianFromPicker()?.let { current = it }; hebrewMode = false }, colors = tabColors(!hebrewMode), modifier = Modifier.weight(1f)) {
                        Text(L("გრიგორიანული"), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Button(onClick = { gregorianFromPicker()?.let { current = it }; hebrewMode = true }, colors = tabColors(hebrewMode), modifier = Modifier.weight(1f).testTag("tab_hebrew")) {
                        Text(L("ებრაული") + " • עברי", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (!hebrewMode) {
                    Box(Modifier.heightIn(max = 470.dp)) { DatePicker(picker, title = null, headline = null, showModeToggle = true) }
                    gregorianFromPicker()?.let {
                        val h = DualDates.hebrewOf(it)
                        Text("${JewishCalendar.hebrewDateKa(h)} • ${JewishCalendar.hebrewDateHe(h)}", color = CosmicCelestialGold, fontWeight = FontWeight.SemiBold)
                    }
                } else {
                    val years = ((hy - 120)..(hy + 5)).toList().reversed()
                    AppDropdown(L("წელი"), hy, years, { "$it • ${JewishCalendar.gematria(it)}" }, { y -> hy = y; if (hm !in DualDates.monthsFor(y)) hm = 6 })
                    AppDropdown(L("თვე"), hm, DualDates.monthsFor(hy), { m -> val d = HebDate(hy, m, 1, JewishCalendar.isLeap(hy)); "${JewishCalendar.monthNameKa(d)} • ${JewishCalendar.monthNameHe(d)}" }, { hm = it })
                    AppDropdown(L("დღე"), hd.coerceAtMost(DualDates.daysIn(hy, hm)), (1..DualDates.daysIn(hy, hm)).toList(), { "$it • ${JewishCalendar.gematria(it)}" }, { hd = it })
                    Text(hebrewResult?.let { L("გრიგორიანულით: ") + DualDates.gregorianText(it) } ?: L("არასწორი თარიღი"), color = CosmicCelestialGold, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    if (optional) TextButton(onClick = onClear) { Text(L("გასუფთავება"), color = CosmicAlertRose) }
                    TextButton(onClick = onDismiss) { Text(L("გაუქმება"), color = CosmicTextSecondary) }
                    Button(onClick = {
                        val r = if (hebrewMode) hebrewResult else gregorianFromPicker()
                        if (r != null) onPick(r)
                    }, modifier = Modifier.testTag("dual_date_ok")) { Text(L("არჩევა")) }
                }
            }
        }
    }
}
