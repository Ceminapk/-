package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemberEntity
import com.example.ui.calendar.JewishTools
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.theme.*

/** A family link stored on a member: relation, name, optional birth date and gender. */
data class Relative(val relation: String, val name: String, val birthMillis: Long = 0L, val male: Boolean = true)

object Relatives {
    val relations = listOf("მამა", "დედა", "მეუღლე", "ვაჟი", "ქალიშვილი", "ძმა", "და", "შვილიშვილი")

    fun parse(s: String): List<Relative> = s.lines().mapNotNull { line ->
        val p = line.split("|")
        if (p.size < 2 || p[1].isBlank()) null
        else Relative(p[0], p[1], p.getOrNull(2)?.toLongOrNull() ?: 0L, p.getOrNull(3) != "F")
    }

    fun encode(list: List<Relative>): String = list.filter { it.name.isNotBlank() }.joinToString("\n") {
        listOf(it.relation, it.name.replace("|", " "), it.birthMillis.toString(), if (it.male) "M" else "F").joinToString("|")
    }

    data class Simcha(val member: MemberEntity, val child: Relative, val dateMillis: Long, val shabbatMillis: Long, val bat: Boolean)

    /** Children whose bar mitzvah (13) / bat mitzvah (12) falls in the next [days] days. */
    fun upcomingMitzvot(members: List<MemberEntity>, days: Int, now: Long = System.currentTimeMillis()): List<Simcha> {
        val end = now + days * 86_400_000L
        return members.flatMap { m -> parse(m.relatives).filter { it.birthMillis > 0 && it.relation in listOf("ვაჟი", "ქალიშვილი", "შვილიშვილი") }.map { m to it } }
            .mapNotNull { (m, c) ->
                runCatching { JewishTools.barMitzvah(c.birthMillis, false, girl = !c.male) }.getOrNull()
                    ?.takeIf { it.dateMillis in JewishTools.dayStart(now)..end }?.let { Simcha(m, c, it.dateMillis, it.shabbatMillis, !c.male) }
            }.sortedBy { it.dateMillis }
    }
}

@Composable
fun RelativesEditor(value: String, onChange: (String) -> Unit, memberNames: List<String>, onAddMember: (String) -> Unit) {
    val list = remember { Relatives.parse(value).toMutableStateList() }
    fun push() = onChange(Relatives.encode(list))
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.testTag("relatives_editor")) {
        Text(L("ოჯახური კავშირები"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
        Text(L("შვილის დაბადების თარიღით აპი გამოთვლის ბარ/ბათ-მიცვას და წინასწარ შეგახსენებთ."), fontSize = 12.sp, color = CosmicTextMuted)
        list.forEachIndexed { i, r ->
            CosmicGlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppDropdown(L("ნათესაობა"), r.relation, Relatives.relations, { L(it) }, { list[i] = r.copy(relation = it, male = it !in listOf("დედა", "ქალიშვილი", "და")); push() }, modifier = Modifier.weight(1f))
                    IconButton(onClick = { list.removeAt(i); push() }) { Icon(Icons.Default.Close, L("წაშლა"), tint = CosmicAlertRose) }
                }
                MemberField(L("სახელი"), r.name, { list[i] = r.copy(name = it); push() }, memberNames, onAddMember)
                DualDateField(L("დაბადების თარიღი"), r.birthMillis, { list[i] = r.copy(birthMillis = it); push() }, optional = true)
                if (r.birthMillis > 0 && r.relation in listOf("ვაჟი", "ქალიშვილი", "შვილიშვილი")) {
                    val bm = runCatching { JewishTools.barMitzvah(r.birthMillis, false, girl = !r.male) }.getOrNull()
                    if (bm != null) Text(Lf(if (r.male) "ბარ-მიცვა: {0}" else "ბათ-მიცვა: {0}", DualDates.bothText(bm.dateMillis)), color = CosmicCelestialGold, fontSize = 12.sp)
                }
            }
        }
        OutlinedButton(onClick = { list.add(Relative("ვაჟი", "")); push() }, modifier = Modifier.testTag("add_relative")) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text(L("ნათესავის დამატება"))
        }
    }
}
