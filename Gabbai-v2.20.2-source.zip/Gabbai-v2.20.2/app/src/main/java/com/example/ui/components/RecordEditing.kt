package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import com.example.ui.theme.*

/** Small "edit / delete" strip shown under any record card. */
@Composable
fun RecordActionsRow(onEdit: () -> Unit, onDelete: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onEdit, modifier = Modifier.testTag("btn_edit_record")) {
            Icon(Icons.Default.Edit, null, tint = CosmicAuroraBlue, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp)); Text(L("შესწორება"), color = CosmicAuroraBlue, maxLines = 1)
        }
        if (onDelete != null) TextButton(onClick = onDelete) {
            Icon(Icons.Default.DeleteOutline, null, tint = CosmicAlertRose, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp)); Text(L("წაშლა"), color = CosmicAlertRose, maxLines = 1)
        }
    }
}

@Composable
fun ConfirmDeleteDialog(name: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(L("წაშლის დადასტურება"), fontWeight = FontWeight.Bold) },
        text = { Text(Lf("ნამდვილად წაიშალოს „{0}“? ამ მოქმედების გაუქმება შეუძლებელია.", name)) },
        confirmButton = { Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = CosmicAlertRose), modifier = Modifier.testTag("btn_confirm_delete")) { Text(L("წაშლა")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L("გაუქმება")) } }
    )
}

/** Common shell for every edit form: scrolling body, Save / Cancel always visible. */
@Composable
private fun EditShell(title: String, onDismiss: () -> Unit, onSave: () -> Boolean, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    FormDialog(
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.fillMaxWidth(0.94f),
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = { LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) },
        confirmButton = { Button(onClick = { onSave() }, modifier = Modifier.testTag("btn_save_edit")) { Text(L("შენახვა")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L("გაუქმება")) } }
    )
}

private fun parseAmount(t: String): Double? = t.replace(',', '.').trim().toDoubleOrNull()?.takeIf { it >= 0 }
private fun amountText(d: Double) = if (d % 1.0 == 0.0) d.toLong().toString() else d.toString()

@Composable
private fun AmountError(show: Boolean) { if (show) Text(L("შეიყვანეთ სწორი თანხა"), color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }

@Composable
fun EditTransactionDialog(tx: TransactionEntity, memberNames: List<String>, onAddMember: (String) -> Unit, onDismiss: () -> Unit, onSave: (TransactionEntity) -> Unit) {
    var title by remember { mutableStateOf(tx.title) }
    var type by remember { mutableStateOf(tx.type) }
    var category by remember { mutableStateOf(tx.category) }
    var amount by remember { mutableStateOf(amountText(tx.amount)) }
    var currency by remember { mutableStateOf(tx.currency) }
    var member by remember { mutableStateOf(tx.memberName) }
    var method by remember { mutableStateOf(L(tx.paymentMethod)) }
    var status by remember { mutableStateOf(tx.status) }
    var date by remember { mutableStateOf(tx.dateMillis) }
    var err by remember { mutableStateOf(false) }
    val cats = if (type == TransactionType.INCOME) FinanceCategory.values().take(7) else FinanceCategory.values().drop(7)
    EditShell(L("ოპერაციის რედაქტირება"), onDismiss, onSave = {
        val a = parseAmount(amount)
        if (title.isBlank() || a == null) { err = true; false } else {
            onSave(tx.copy(title = title.trim(), type = type, category = category, amount = a, currency = currency, memberName = member.trim(), paymentMethod = method, status = status, dateMillis = date)); true
        }
    }) {
        item { AppDropdown(L("ტიპი"), type, TransactionType.values().toList(), { if (it == TransactionType.INCOME) L("შემოსავალი (+)") else L("გასავალი (-)") }, { type = it; category = (if (it == TransactionType.INCOME) FinanceCategory.values().take(7) else FinanceCategory.values().drop(7)).first() }) }
        item {
            SuggestField(L("დასახელება"), title, { title = it }, Catalogs.operations.filter { it.type == type }.map { it.title })
            if (err && title.isBlank()) Text(L("შეავსეთ დასახელება"), color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        }
        item { AppDropdown(L("კატეგორია"), category, cats, { it.titleKa }, { category = it }) }
        item { AmountCurrencyField(L("თანხა"), amount, { amount = it }, currency, { currency = it }); AmountError(err && parseAmount(amount) == null) }
        item { MemberField(L("წევრი / კონტრაგენტი"), member, { member = it }, memberNames, onAddMember) }
        item { SuggestField(L("გადახდის მეთოდი"), method, { method = it }, Catalogs.paymentMethods) }
        item { AppDropdown(L("სტატუსი"), status, TransactionStatus.values().toList(), { statusLabel(it) }, { status = it }) }
        item { DualDateField(L("თარიღი"), date, { date = it }) }
    }
}

fun statusLabel(s: TransactionStatus) = when (s) {
    TransactionStatus.PAID -> L("გადახდილია")
    TransactionStatus.PENDING -> L("მოლოდინშია")
    TransactionStatus.PLEDGED -> L("დაპირებულია")
}

@Composable
fun EditAliyahDialog(a: AliyahEntity, parashot: List<String>, memberNames: List<String>, onAddMember: (String) -> Unit, onDismiss: () -> Unit, onSave: (AliyahEntity) -> Unit) {
    var parasha by remember { mutableStateOf(a.parashaName) }
    var type by remember { mutableStateOf(a.aliyahType) }
    var winner by remember { mutableStateOf(a.winnerName) }
    var amount by remember { mutableStateOf(amountText(a.amount)) }
    var currency by remember { mutableStateOf(a.currency) }
    var status by remember { mutableStateOf(a.status) }
    var date by remember { mutableStateOf(a.dateMillis) }
    var err by remember { mutableStateOf(false) }
    EditShell(L("ალიის რედაქტირება"), onDismiss, onSave = {
        val v = parseAmount(amount)
        if (winner.isBlank() || v == null) { err = true; false } else { onSave(a.copy(parashaName = parasha.trim(), aliyahType = type, winnerName = winner.trim(), amount = v, currency = currency, status = status, dateMillis = date)); true }
    }) {
        item { SuggestField(L("ფარაშა / მიზეზი"), parasha, { parasha = it }, parashot) }
        item { AppDropdown(L("ალიის ტიპი"), type, AliyahType.values().toList(), { it.titleKa + " • " + it.titleHe }, { type = it }) }
        item { MemberField(L("მყიდველი"), winner, { winner = it }, memberNames, onAddMember); if (err && winner.isBlank()) Text(L("შეავსეთ სახელი"), color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        item { AmountCurrencyField(L("თანხა"), amount, { amount = it }, currency, { currency = it }); AmountError(err && parseAmount(amount) == null) }
        item { AppDropdown(L("სტატუსი"), status, TransactionStatus.values().toList(), { statusLabel(it) }, { status = it }) }
        item { DualDateField(L("თარიღი"), date, { date = it }) }
    }
}

@Composable
fun EditKollelStudentDialog(s: KollelStudentEntity, onDismiss: () -> Unit, onSave: (KollelStudentEntity) -> Unit) {
    var name by remember { mutableStateOf(s.fullName) }
    var phone by remember { mutableStateOf(s.phone) }
    var masechet by remember { mutableStateOf(s.currentMasechet) }
    var stipend by remember { mutableStateOf(amountText(s.monthlyStipend)) }
    var currency by remember { mutableStateOf(s.currency) }
    var paid by remember { mutableStateOf(s.stipendPaidThisMonth) }
    var err by remember { mutableStateOf(false) }
    EditShell(L("ავრეხის რედაქტირება"), onDismiss, onSave = {
        val v = parseAmount(stipend)
        if (name.isBlank() || v == null) { err = true; false } else { onSave(s.copy(fullName = name.trim(), phone = phone.trim(), currentMasechet = masechet, monthlyStipend = v, currency = currency, stipendPaidThisMonth = paid)); true }
    }) {
        item { OutlinedTextField(name, { name = it }, label = { Text(L("სრული სახელი")) }, singleLine = true, isError = err && name.isBlank(), modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(phone, { phone = it }, label = { Text(L("ტელეფონი")) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { SuggestField(L("მასეხეთი"), masechet, { masechet = it }, Catalogs.masechtot) }
        item { AmountCurrencyField(L("ყოველთვიური სტიპენდია"), stipend, { stipend = it }, currency, { currency = it }); AmountError(err && parseAmount(stipend) == null) }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(paid, { paid = it }); Text(L("ამ თვის სტიპენდია გაცემულია"), color = CosmicTextSecondary) } }
    }
}

@Composable
fun EditTzedakahDialog(t: TzedakahEntity, onDismiss: () -> Unit, onSave: (TzedakahEntity) -> Unit) {
    var code by remember { mutableStateOf(t.recipientPrivacyCode) }
    var category by remember { mutableStateOf(t.category) }
    var amount by remember { mutableStateOf(amountText(t.amount)) }
    var currency by remember { mutableStateOf(t.currency) }
    var emergency by remember { mutableStateOf(t.isEmergency) }
    var approved by remember { mutableStateOf(t.approvedByRabbi) }
    var date by remember { mutableStateOf(t.dateMillis) }
    var err by remember { mutableStateOf(false) }
    EditShell(L("ცედაკის რედაქტირება"), onDismiss, onSave = {
        val v = parseAmount(amount)
        if (code.isBlank() || v == null) { err = true; false } else { onSave(t.copy(recipientPrivacyCode = code.trim(), category = category, amount = v, currency = currency, isEmergency = emergency, approvedByRabbi = approved.trim(), dateMillis = date)); true }
    }) {
        item { OutlinedTextField(code, { code = it }, label = { Text(L("მიმღების კოდი")) }, singleLine = true, isError = err && code.isBlank(), modifier = Modifier.fillMaxWidth()) }
        item { AppDropdown(L("საჭიროების მიმართულება"), category, TzedakahCategory.values().toList(), { it.titleKa }, { category = it }) }
        item { AmountCurrencyField(L("თანხა"), amount, { amount = it }, currency, { currency = it }); AmountError(err && parseAmount(amount) == null) }
        item { OutlinedTextField(approved, { approved = it }, label = { Text(L("დაამტკიცა")) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(emergency, { emergency = it }); Text(L("გადაუდებელი"), color = CosmicTextSecondary) } }
        item { DualDateField(L("თარიღი"), date, { date = it }) }
    }
}

@Composable
fun EditEventDialog(e: SynagogueEventEntity, memberNames: List<String>, onAddMember: (String) -> Unit, onDismiss: () -> Unit, onSave: (SynagogueEventEntity) -> Unit) {
    var title by remember { mutableStateOf(e.title) }
    var type by remember { mutableStateOf(L(e.eventType)) }
    var sponsor by remember { mutableStateOf(e.sponsorName) }
    var cost by remember { mutableStateOf(amountText(e.totalCost)) }
    var contribution by remember { mutableStateOf(amountText(e.sponsorContribution)) }
    var currency by remember { mutableStateOf(e.currency) }
    var guests by remember { mutableStateOf(e.expectedGuests.toString()) }
    var done by remember { mutableStateOf(e.isCompleted) }
    var date by remember { mutableStateOf(e.dateMillis) }
    var err by remember { mutableStateOf(false) }
    EditShell(L("ღონისძიების რედაქტირება"), onDismiss, onSave = {
        val c = parseAmount(cost); val s = parseAmount(contribution)
        if (title.isBlank() || c == null || s == null) { err = true; false } else {
            onSave(e.copy(title = title.trim(), eventType = type, sponsorName = sponsor.trim(), totalCost = c, sponsorContribution = s, currency = currency,
                expectedGuests = guests.filter(Char::isDigit).toIntOrNull() ?: e.expectedGuests, isCompleted = done, dateMillis = date)); true
        }
    }) {
        item { OutlinedTextField(title, { title = it }, label = { Text(L("დასახელება")) }, singleLine = true, isError = err && title.isBlank(), modifier = Modifier.fillMaxWidth()) }
        item { SuggestField(L("ღონისძიების ტიპი"), type, { type = it }, Catalogs.eventTypes) }
        item { DualDateField(L("თარიღი"), date, { date = it }) }
        item { MemberField(L("სპონსორი"), sponsor, { sponsor = it }, memberNames, onAddMember) }
        item { AmountCurrencyField(L("სრული ხარჯი"), cost, { cost = it }, currency, { currency = it }); AmountError(err && parseAmount(cost) == null) }
        item { AmountCurrencyField(L("სპონსორის წვლილი"), contribution, { contribution = it }, currency, { currency = it }); AmountError(err && parseAmount(contribution) == null) }
        item { OutlinedTextField(guests, { guests = it.filter(Char::isDigit).take(5) }, label = { Text(L("სტუმრების რაოდენობა")) }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(done, { done = it }); Text(L("დასრულებულია"), color = CosmicTextSecondary) } }
    }
}
