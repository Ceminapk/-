package com.example.data.export

import com.example.ui.settings.L
import com.example.ui.settings.Lf

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.ui.viewmodel.GabbaiUiState
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object XlsxExporter {
    private val date = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

    /** Category of data the user can export separately. Sheet names stay stable for spreadsheet tools. */
    enum class Module(val ka: String, val sheets: List<String>) {
        MEMBERS("ჯამაათის წევრები", listOf("Members")),
        FINANCES("ფინანსური სალარო", listOf("Finances")),
        ALIYOT("თორის ალიები და ნედერები", listOf("Aliyot")),
        YAHRZEITS("იორცაიტები და გარდაცვლილები", listOf("Yahrzeits")),
        KOLLEL("ქოლელი და დასწრება", listOf("Kollel", "Attendance")),
        TZEDAKAH("ცედაკა და გაჭირვებულები", listOf("Tzedakah", "Beneficiaries")),
        EVENTS("ღონისძიებები", listOf("Events"))
    }

    /** Builds only the requested sheets; finance rows are narrowed by type and category when given. */
    fun sheetsFor(
        state: GabbaiUiState,
        modules: Set<Module>,
        financeType: com.example.data.model.TransactionType? = null,
        financeCategory: com.example.data.model.FinanceCategory? = null
    ): List<Pair<String, List<List<Any?>>>> {
        val tx = state.transactions.filter { (financeType == null || it.type == financeType) && (financeCategory == null || it.category == financeCategory) }
        val all = allSheets(state.copy(transactions = tx))
        val wanted = Module.values().filter { it in modules }.flatMap { it.sheets }.toSet()
        return all.filter { it.first in wanted }
    }

    private fun allSheets(state: GabbaiUiState): List<Pair<String, List<List<Any?>>>> = listOf(
            "Members" to listOf(listOf("ID","Name","Phone","Role","Status","Seat","Annual fee","Debt")) + state.members.map { listOf(it.id,it.fullName,it.phone,it.role.titleKa,it.status.titleKa,it.seatNumber,it.annualFeeAmount,it.outstandingDebt) },
            "Yahrzeits" to listOf(listOf("ID","Deceased","Hebrew name","Relative","Relationship","Hebrew month","Hebrew day","Original date")) + state.yahrzeits.map { listOf(it.id,it.deceasedName,it.hebrewName,it.relatedMemberName,it.relationship,it.hebrewMonth,it.hebrewDay,date.format(Date(it.deathDateMillis))) },
            "Finances" to listOf(listOf("ID","Title","Type","Category","Amount","Person","Method","Date","Status")) + state.transactions.map { listOf(it.id,it.title,it.type.name,it.category.titleKa,it.amount,it.memberName,it.paymentMethod,date.format(Date(it.dateMillis)),it.status.name) },
            "Aliyot" to listOf(listOf("ID","Parasha","Aliyah","Winner","Amount","Date","Status")) + state.aliyot.map { listOf(it.id,it.parashaName,it.aliyahType.titleKa,it.winnerName,it.amount,date.format(Date(it.dateMillis)),it.status.name) },
            "Kollel" to listOf(listOf("ID","Student","Phone","Masechet","Stipend","Paid","Attendance")) + state.kollelStudents.map { listOf(it.id,it.fullName,it.phone,it.currentMasechet,it.monthlyStipend,it.stipendPaidThisMonth,"${it.totalSessionsPresent}/${it.totalSessionsExpected}") },
            "Attendance" to listOf(listOf("ID","Student","Date","Morning","Afternoon","Remarks")) + state.kollelAttendance.map { listOf(it.id,it.studentName,date.format(Date(it.dateMillis)),it.sederMorning,it.sederAfternoon,it.remarks) },
            "Tzedakah" to listOf(listOf("ID","Code","Category","Amount","Date","Emergency","Approved by")) + state.tzedakahFunds.map { listOf(it.id,it.recipientPrivacyCode,it.category.titleKa,it.amount,date.format(Date(it.dateMillis)),it.isEmergency,it.approvedByRabbi) },
            "Beneficiaries" to listOf(listOf("ID","Code","Name","Category","Family","Phone","Address","Need","Approved","Status")) + state.needyBeneficiaries.map { listOf(it.id,it.identifierCode,it.fullNameOrPseudonym,it.category.titleKa,it.familyMembersCount,it.phone,it.address,it.monthlyEstimatedNeed,it.monthlyApprovedAid,it.status.titleKa) },
            "Events" to listOf(listOf("ID","Title","Type","Date","Sponsor","Cost","Contribution","Guests","Completed")) + state.events.map { listOf(it.id,it.title,it.eventType,date.format(Date(it.dateMillis)),it.sponsorName,it.totalCost,it.sponsorContribution,it.expectedGuests,it.isCompleted) }
        )

    /** Sheets belonging to one screen; screens without own data export everything. */
    fun sheetsForScreen(state: GabbaiUiState, screen: com.example.ui.viewmodel.GabbaiScreen): List<Pair<String, List<List<Any?>>>> {

        val m = when (screen) {
            com.example.ui.viewmodel.GabbaiScreen.FINANCES -> Module.FINANCES; com.example.ui.viewmodel.GabbaiScreen.ALIYOT -> Module.ALIYOT; com.example.ui.viewmodel.GabbaiScreen.MEMBERS -> Module.MEMBERS
            com.example.ui.viewmodel.GabbaiScreen.KOLLEL -> Module.KOLLEL; com.example.ui.viewmodel.GabbaiScreen.TZEDAKAH -> Module.TZEDAKAH; com.example.ui.viewmodel.GabbaiScreen.EVENTS -> Module.EVENTS
            com.example.ui.viewmodel.GabbaiScreen.YAHRZEITS -> Module.YAHRZEITS; else -> null
        }
        return if (m == null) allSheets(state) else sheetsFor(state, setOf(m))
    }

    /** One-tap Excel export of the screen the user is looking at. */
    fun quickExport(context: Context, state: GabbaiUiState) =
        shareSheets(context, sheetsForScreen(state, state.currentScreen), csv = false, subject = "Gabbai — " + state.currentScreen.title)

    /** Excel export of one dashboard metric detail (balance, debt, income, expense). */
    fun metricSheets(state: GabbaiUiState, kind: String): List<Pair<String, List<List<Any?>>>> {
        val inc = com.example.data.model.TransactionType.INCOME; val exp = com.example.data.model.TransactionType.EXPENSE
        fun txRows(l: List<com.example.data.model.TransactionEntity>) = listOf(listOf("Date","Title","Category","Amount","Currency","Person","Method","Status")) +
            l.sortedByDescending { it.dateMillis }.map { listOf(date.format(Date(it.dateMillis)), it.title, it.category.titleKa, it.amount, it.currency, it.memberName, it.paymentMethod, it.status.name) }
        return when (kind) {
            "INCOME" -> listOf("Income" to txRows(state.transactions.filter { it.type == inc }))
            "EXPENSE" -> listOf("Expense" to txRows(state.transactions.filter { it.type == exp }))
            "DEBT" -> listOf(
                "Debtors" to listOf(listOf("Name","Phone","Debt")) + state.members.filter { it.outstandingDebt > 0 }.sortedByDescending { it.outstandingDebt }.map { listOf(it.fullName, it.phone, it.outstandingDebt) },
                "Pledges" to listOf(listOf("Date","Parasha","Winner","Amount","Currency")) + state.aliyot.filter { it.status == com.example.data.model.TransactionStatus.PLEDGED }.map { listOf(date.format(Date(it.dateMillis)), it.parashaName, it.winnerName, it.amount, it.currency) })
            else -> listOf(
                "Balance" to listOf(listOf("Item","Amount"), listOf("Income", state.totalIncome), listOf("Expense", state.totalExpense), listOf("Net balance", state.netBalance), listOf("Debt", state.totalOutstandingPledges)),
                "Transactions" to txRows(state.transactions))
        }
    }

    fun share(context: Context, state: GabbaiUiState) =
        shareSheets(context, allSheets(state), csv = false, subject = L("Gabbai Cosmos — სრული მონაცემები"))

    fun shareSheets(context: Context, sheets: List<Pair<String, List<List<Any?>>>>, csv: Boolean, subject: String) {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val stamp = System.currentTimeMillis()
        val files = if (csv) sheets.map { (name, rows) -> File(dir, "Gabbai_${name}_$stamp.csv").also { it.writeBytes(csvText(rows).toByteArray(Charsets.UTF_8)) } }
                    else listOf(File(dir, "Gabbai_Cosmos_$stamp.xlsx").also { writeWorkbook(it, sheets) })
        val uris = ArrayList(files.map { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it) })
        val intent = if (uris.size == 1) Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris[0]) }
                     else Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
        intent.type = if (csv) "text/csv" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        intent.putExtra(Intent.EXTRA_SUBJECT, subject)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Google Sheets / Excel"))
    }

    /** CSV with UTF-8 BOM so Excel shows Georgian/Hebrew correctly. */
    fun csvText(rows: List<List<Any?>>): String = "\uFEFF" + rows.joinToString("\n") { r ->
        r.joinToString(",") { v -> val c = v?.toString() ?: ""; if (c.any { it == ',' || it == '"' || it == '\n' }) "\"" + c.replace("\"", "\"\"") + "\"" else c }
    } + "\n"

    private fun writeWorkbook(file: File, sheets: List<Pair<String,List<List<Any?>>>>) {
        ZipOutputStream(FileOutputStream(file)).use { zip ->
            fun entry(name: String, content: String) { zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray()); zip.closeEntry() }
            entry("[Content_Types].xml", contentTypes(sheets.size))
            entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml", workbookXml(sheets))
            entry("xl/_rels/workbook.xml.rels", workbookRels(sheets.size))
            entry("xl/styles.xml", stylesXml())
            sheets.forEachIndexed { i, (_, rows) -> entry("xl/worksheets/sheet${i+1}.xml", sheetXml(rows)) }
        }
    }

    private fun esc(v: Any?) = (v?.toString() ?: "").replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
    private fun col(n: Int): String { var x=n+1; var s=""; while(x>0){ x--; s=('A'.code+x%26).toChar()+s; x/=26 }; return s }
    private fun sheetXml(rows: List<List<Any?>>): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>""")
        val count = rows.maxOfOrNull { it.size } ?: 1
        repeat(count) { append("<col min=\"${it+1}\" max=\"${it+1}\" width=\"20\" customWidth=\"1\"/>") }
        append("</cols><sheetData>")
        rows.forEachIndexed { r, row -> append("<row r=\"${r+1}\">"); row.forEachIndexed { c, value -> append("<c r=\"${col(c)}${r+1}\" t=\"inlineStr\" s=\"${if(r==0) 1 else 0}\"><is><t>${esc(value)}</t></is></c>") }; append("</row>") }
        if(rows.isNotEmpty()) append("</sheetData><autoFilter ref=\"A1:${col(count-1)}${rows.size}\"/></worksheet>") else append("</sheetData></worksheet>")
    }
    private fun contentTypes(n:Int) = """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${(1..n).joinToString(""){"<Override PartName=\"/xl/worksheets/sheet$it.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"}}</Types>"""
    private fun workbookXml(s:List<Pair<String,*>>) = """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${s.mapIndexed{i,p->"<sheet name=\"${esc(p.first)}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"/>"}.joinToString("")}</sheets></workbook>"""
    private fun workbookRels(n:Int) = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${(1..n).joinToString(""){"<Relationship Id=\"rId$it\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet$it.xml\"/>"}}<Relationship Id="rId${n+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
    private fun stylesXml() = """<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Arial"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF087E8B"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs></styleSheet>"""
}
