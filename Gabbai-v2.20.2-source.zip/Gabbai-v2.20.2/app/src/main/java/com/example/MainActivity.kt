package com.example

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.ui.platform.LocalContext
import com.example.ui.settings.*
import com.example.ui.voice.VoiceNavigationDialog
import com.example.data.export.XlsxExporter
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.CosmicAnimatedBackground
import com.example.ui.components.CosmicTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiScreen
import com.example.ui.viewmodel.GabbaiViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        I18n.init(applicationContext)
        ComplianceRules.init(applicationContext)
        com.example.ui.calendar.CalendarPrefs.init(applicationContext)
        runCatching { com.example.widget.ZmanimWidget.refresh(applicationContext) }
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            val context = LocalContext.current
            val store = remember { SettingsStore(context) }
            var settings by remember { mutableStateOf(store.load().also { I18n.lang = it.language; I18n.defaultCurrency = it.currency }) }
            GabbaiCosmosTheme(settings) {
                // Re-create the screen tree when the language changes so every text is refreshed.
                key(settings.language) {
                    GabbaiAppRoot(settings = settings, onSettingsChange = {
                        I18n.lang = it.language; I18n.defaultCurrency = it.currency
                        settings = it; store.save(it)
                    })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GabbaiAppRoot(
    viewModel: GabbaiViewModel = viewModel(),
    settings: AppSettings,
    onSettingsChange: (AppSettings) -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val snackbarHostState = remember { SnackbarHostState() }
    var showAssistantDialog by remember { mutableStateOf(false) }
    var wipeStep by remember { mutableStateOf(0) }
    var pendingRestore by remember { mutableStateOf<android.net.Uri?>(null) }
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val tap: () -> Unit = { if (settings.haptics) haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove) }
    LaunchedEffect(settings.autoBackup) {
        if (settings.autoBackup) runCatching { com.example.data.backup.BackupManager.autoBackup(context) }
    }
    val quietNow = settings.shabbatQuiet && run {
        val c = java.util.Calendar.getInstance()
        com.example.ui.v216.QuietMode.isQuiet(System.currentTimeMillis(), com.example.ui.calendar.JewishCalendar.day(c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH), com.example.ui.calendar.CalendarPrefs.city))
    }
    LaunchedEffect(state.yahrzeits, settings.yahrzeitReminderDays, quietNow) {
        if (!quietNow) com.example.ui.notifications.YahrzeitNotifier.notifyUpcoming(context, state.yahrzeits, settings.yahrzeitReminderDays)
    }
    LaunchedEffect(state.members, settings.birthdayReminderDays, quietNow) {
        if (!quietNow) com.example.ui.notifications.BirthdayNotifier.notifyUpcoming(context, state.members, settings.birthdayReminderDays)
    }
    val isKa = LocalAppSettings.current.language == AppLanguage.KA
    fun say(ka: String, ru: String) { val msg = when (I18n.lang) { AppLanguage.KA -> ka; AppLanguage.RU -> ru; else -> L(ka) }; scope.launch { snackbarHostState.showSnackbar(msg) } }
    val backupLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) viewModel.backupTo(uri) { r ->
        r.onSuccess { say(Lf("სარეზერვო ასლი შეინახა ({0} ჩანაწერი)", it), "Резервная копия сохранена ($it записей)") }
         .onFailure { say(L("ასლის შენახვა ვერ მოხერხდა"), "Не удалось сохранить копию") } } }
    val restoreLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) pendingRestore = uri }
    var showVoiceDialog by remember { mutableStateOf(false) }
    var assistantVoice by remember { mutableStateOf(false) }
    var showNederDialog by remember { mutableStateOf(false) }
    var showSos by remember { mutableStateOf(false) }
    var showCategoryExport by remember { mutableStateOf(false) }

    // Display status messages
    LaunchedEffect(state.statusMessage) {
        state.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    // Android back handler: pop to Dashboard if in sub-screen
    BackHandler(enabled = state.currentScreen != GabbaiScreen.DASHBOARD || drawerState.isOpen) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else {
            viewModel.setScreen(GabbaiScreen.DASHBOARD)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = LocalGabbaiPalette.current.surface,
                drawerContentColor = LocalGabbaiPalette.current.text,
                modifier = Modifier.width(320.dp)
            ) {
                Spacer(modifier = Modifier.height(24.dp))
                // Drawer Header
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(CosmicCelestialGold.copy(alpha = 0.2f))
                                .border(1.dp, CosmicCelestialGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = CosmicCelestialGold,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Gabbai Cosmos",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = CosmicTextPrimary
                            )
                             Text(
                                 text = tr("სინაგოგისა და ქოლელის მართვა", "Управление синагогой и коллелем"),
                                fontSize = 11.sp,
                                color = CosmicCelestialGold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = Color.White.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(12.dp))

                // Navigation Items
                GabbaiScreen.values().forEach { screen ->
                    val isSelected = state.currentScreen == screen
                    NavigationDrawerItem(
                        icon = {
                            Icon(
                                imageVector = when (screen) {
                                    GabbaiScreen.DASHBOARD -> Icons.Default.Dashboard
                                    GabbaiScreen.FINANCES -> Icons.Default.Payments
                                    GabbaiScreen.ALIYOT -> Icons.Default.MenuBook
                                    GabbaiScreen.MEMBERS -> Icons.Default.People
                                    GabbaiScreen.KOLLEL -> Icons.Default.School
                                    GabbaiScreen.TZEDAKAH -> Icons.Default.VolunteerActivism
                                    GabbaiScreen.EVENTS -> Icons.Default.Celebration
                                    GabbaiScreen.SECURITY -> Icons.Default.Security
                                    GabbaiScreen.TECH_DOCS -> Icons.Default.Description
                                    GabbaiScreen.SETTINGS -> Icons.Default.Settings
                                    GabbaiScreen.CALENDAR -> Icons.Default.CalendarMonth
                                    GabbaiScreen.YAHRZEITS -> Icons.Default.NotificationsActive
                                    GabbaiScreen.REGISTERS -> Icons.Default.LibraryBooks
                                    GabbaiScreen.TOOLS -> Icons.Default.AutoStories
                                },
                                    contentDescription = screen.title,
                                tint = if (isSelected) CosmicStardustCyan else CosmicTextSecondary
                            )
                        },
                        label = {
                            Column {
                                Text(
                                    text = screen.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                     color = if (isSelected) MaterialTheme.colorScheme.primary else LocalGabbaiPalette.current.text,
                                     maxLines = 1,
                                     softWrap = false,
                                     overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = nb(if (settings.language == AppLanguage.HE) screen.titleRu else screen.titleHe),
                                    fontSize = 10.sp,
                                    color = if (isSelected) MaterialTheme.colorScheme.secondary else LocalGabbaiPalette.current.mutedText,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        selected = isSelected,
                        onClick = {
                            viewModel.setScreen(screen)
                            scope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CosmicStardustCyan.copy(alpha = 0.15f),
                            unselectedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                    )
                }
            }
        }
    ) {
        CosmicAnimatedBackground {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    CosmicTopBar(
                        currentTitle = state.currentScreen.title,
                        subtitle = tr("სინაგოგა და ქოლელი", "Синагога и коллель"),
                        isVaultUnlocked = state.isVaultUnlocked,
                        onToggleVault = { viewModel.toggleVaultLock() },
                        onOpenDocs = { viewModel.setScreen(GabbaiScreen.TECH_DOCS) },
                        onOpenAssistant = { showAssistantDialog = true },
                        onOpenVoice = { assistantVoice = true; showAssistantDialog = true },
                        onToggleTheme = { onSettingsChange(settings.copy(lighting = if (settings.lighting == LightingMode.NIGHT) LightingMode.DAY else LightingMode.NIGHT)) },
                        onToggleLanguage = { onSettingsChange(settings.copy(language = AppLanguage.values()[(settings.language.ordinal + 1) % AppLanguage.values().size])) },
                        onOpenSettings = { viewModel.setScreen(GabbaiScreen.SETTINGS) },
                        onQuickExport = { com.example.data.export.XlsxExporter.quickExport(context, state) },
                        isNight = settings.lighting == LightingMode.NIGHT,
                        languageCode = settings.language.name,
                        onBackup = { backupLauncher.launch("gabbai-backup-" + java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.US).format(java.util.Date()) + ".json") },
                        onRestore = { restoreLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
                        onWipe = { wipeStep = 1 },
                        onSos = { showSos = true },
                        onSelectLanguage = { onSettingsChange(settings.copy(language = it)) },
                        modifier = Modifier.statusBarsPadding()
                    )
                },
                bottomBar = {
                    val docked = com.example.ui.components.DockedAdd.action
                    val navColors = @Composable { c: Color -> NavigationBarItemDefaults.colors(selectedIconColor = c, indicatorColor = c.copy(alpha = 0.2f), unselectedIconColor = CosmicTextSecondary) }
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .testTag("bottom_nav_bar")
                    ) {
                    val slots = 6f + if (docked != null) 1.2f else 0f
                    val slotW = maxWidth / slots
                    NavigationBar(
                        containerColor = Color.Transparent,
                        contentColor = LocalGabbaiPalette.current.text,
                        tonalElevation = 0.dp,
                        windowInsets = WindowInsets(0, 0, 0, 0),
                        modifier = Modifier
                            .padding(top = 28.dp)
                            .background(
                                LocalGabbaiPalette.current.glass,
                                if (docked != null) com.example.ui.components.NotchedBarShape(36.dp) else androidx.compose.ui.graphics.RectangleShape
                            )
                    ) {
                        // Slot for the raised AI sphere
                        Box(Modifier.weight(1f).height(80.dp), contentAlignment = Alignment.BottomCenter) {
                            Text(L("ასისტენტი"), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = CosmicTextSecondary, modifier = Modifier.padding(bottom = 12.dp))
                        }
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Dashboard, contentDescription = tr("მთავარი", "Главная")) },
                            label = { Text(tr("მთავარი", "Главная"), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = state.currentScreen == GabbaiScreen.DASHBOARD,
                            onClick = { tap(); viewModel.setScreen(GabbaiScreen.DASHBOARD) },
                            colors = navColors(CosmicStardustCyan)
                        )
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Payments, contentDescription = tr("ფინანსები", "Финансы")) },
                            label = { Text(tr("ფინანსები", "Финансы"), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = state.currentScreen == GabbaiScreen.FINANCES,
                            onClick = { tap(); viewModel.setScreen(GabbaiScreen.FINANCES) },
                            colors = navColors(CosmicEmeraldSuccess)
                        )
                        if (docked != null) Spacer(Modifier.weight(1.2f))
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.MenuBook, contentDescription = tr("ალიები", "Алиёт")) },
                            label = { Text(tr("ალიები", "Алиёт"), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = state.currentScreen == GabbaiScreen.ALIYOT,
                            onClick = { tap(); viewModel.setScreen(GabbaiScreen.ALIYOT) },
                            colors = navColors(CosmicCelestialGold)
                        )
                        NavigationBarItem(
                            icon = { Icon(Icons.Default.Mic, contentDescription = tr("ხმოვანი მართვა", "Голосовое управление")) },
                            label = { Text(tr("ხმა", "Голос"), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = false,
                            onClick = { tap(); assistantVoice = true; showAssistantDialog = true },
                            colors = navColors(CosmicNebulaPurple),
                            modifier = Modifier.testTag("nav_voice")
                        )
                        Box(Modifier.weight(1f).height(80.dp), contentAlignment = Alignment.BottomCenter) {
                            Text(tr("მოდულები", "Модули"), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = CosmicTextSecondary, modifier = Modifier.padding(bottom = 12.dp))
                        }
                    }
                    // Raised crystal spheres, rising above the bar's top edge
                    com.example.ui.components.CrystalAiSphere(
                        size = 54.dp, tint = CosmicStardustCyan,
                        onClick = { showAssistantDialog = true },
                        modifier = Modifier.align(Alignment.TopStart).offset(x = (slotW - 54.dp) / 2, y = 6.dp).testTag("bottom_ai_sphere")
                    )
                    com.example.ui.components.CrystalIconSphere(
                        size = 54.dp, tint = CosmicAuroraBlue, icon = Icons.Default.Apps,
                        contentDescription = tr("მოდულები", "Модули"),
                        onClick = { scope.launch { drawerState.open() } },
                        modifier = Modifier.align(Alignment.TopEnd).offset(x = -(slotW - 54.dp) / 2, y = 6.dp).testTag("bottom_modules_sphere")
                    )
                    if (docked != null) {
                        FloatingActionButton(
                            onClick = docked.onClick,
                            shape = CircleShape,
                            containerColor = docked.containerColor,
                            contentColor = docked.contentColor,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .size(56.dp)
                                .testTag(docked.tag)
                        ) { docked.icon() }
                    }
                    }
                },
                snackbarHost = { SnackbarHost(snackbarHostState) },
                modifier = Modifier.fillMaxSize()
            ) { padding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                ) {
                    AnimatedContent(
                        targetState = state.currentScreen,
                        transitionSpec = {
                            (fadeIn(tween(380, delayMillis = 60)) + scaleIn(tween(380), initialScale = 0.985f)) togetherWith fadeOut(tween(220))
                        },
                        label = "screen_transition"
                    ) { targetScreen ->
                        when (targetScreen) {
                            GabbaiScreen.DASHBOARD -> DashboardScreen(
                                state = state,
                                settings = settings,
                                onNavigate = { viewModel.setScreen(it) },
                                onOpenVoice = { assistantVoice = true; showAssistantDialog = true },
                                onExport = { XlsxExporter.share(context, state) },
                                onQuickNeder = { showNederDialog = true }
                            )
                            GabbaiScreen.CALENDAR -> com.example.ui.screens.CalendarScreen()
                            GabbaiScreen.YAHRZEITS -> YahrzeitScreen(viewModel, settings.yahrzeitReminderDays)
                            GabbaiScreen.REGISTERS -> RegistersScreen(viewModel = viewModel)
                            GabbaiScreen.TOOLS -> ToolsScreen(viewModel = viewModel)
                            GabbaiScreen.FINANCES -> FinancesScreen(viewModel = viewModel)
                            GabbaiScreen.ALIYOT -> AliyotScreen(viewModel = viewModel)
                            GabbaiScreen.MEMBERS -> MembersScreen(viewModel = viewModel)
                            GabbaiScreen.KOLLEL -> KollelScreen(viewModel = viewModel)
                            GabbaiScreen.TZEDAKAH -> TzedakahScreen(viewModel = viewModel)
                            GabbaiScreen.EVENTS -> EventsScreen(viewModel = viewModel)
                            GabbaiScreen.SECURITY -> SecurityScreen(viewModel = viewModel)
                            GabbaiScreen.TECH_DOCS -> TechDocsScreen()
                            GabbaiScreen.SETTINGS -> SettingsScreen(
                                settings = settings,
                                onSettingsChange = onSettingsChange,
                                onBackup = { backupLauncher.launch("gabbai-backup-" + java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.US).format(java.util.Date()) + ".json") },
                                onRestore = { restoreLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
                                onWipe = { wipeStep = 1 },
                                onExport = { XlsxExporter.share(context, state) },
                                onCategoryExport = { showCategoryExport = true }
                            )
                        }
                    }
                }
            }

            if (showCategoryExport) com.example.ui.components.CategoryExportDialog(state) { showCategoryExport = false }
            com.example.ui.components.GuidedTourOverlay(onNavigate = { viewModel.setScreen(it) })

            pendingRestore?.let { uri ->
                com.example.ui.components.FormDialog(
                    onDismissRequest = { pendingRestore = null },
                    title = { Text(tr("აღვადგინო ასლიდან?", "Восстановить из копии?")) },
                    text = { Text(tr("ახლანდელი მონაცემები შეიცვლება ფაილში შენახულით.", "Текущие данные будут заменены данными из файла.")) },
                    confirmButton = { Button(onClick = {
                        pendingRestore = null
                        viewModel.restoreFrom(uri) { r ->
                            r.onSuccess { say(Lf("აღდგენილია: {0} ჩანაწერი", it), "Восстановлено записей: $it") }
                             .onFailure { say(L("ფაილი არ არის სწორი სარეზერვო ასლი"), "Файл не является корректной копией") } }
                    }) { Text(tr("აღდგენა", "Восстановить")) } },
                    dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text(tr("გაუქმება", "Отмена")) } }
                )
            }
            if (wipeStep > 0) {
                com.example.ui.components.FormDialog(
                    onDismissRequest = { wipeStep = 0 },
                    icon = { Icon(Icons.Default.DeleteForever, null, tint = MaterialTheme.colorScheme.error) },
                    title = { Text(if (wipeStep == 1) tr("ბაზის სრული გასუფთავება", "Полная очистка базы") else tr("ნამდვილად წავშალო ყველაფერი?", "Точно удалить всё?")) },
                    text = { Text(if (wipeStep == 1) tr("წაიშლება ყველა წევრი, ფინანსი, ალია, ქოლელი, ცედაკა და ღონისძიება. რეკომენდებულია ჯერ სარეზერვო ასლის შექმნა.", "Будут удалены все прихожане, финансы, алиёт, коллель, цдака и события. Сначала рекомендуется создать резервную копию.") else tr("ამ მოქმედების გაუქმება შეუძლებელია.", "Это действие нельзя отменить.")) },
                    confirmButton = { Button(
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        onClick = {
                            if (wipeStep == 1) wipeStep = 2 else {
                                wipeStep = 0
                                viewModel.wipeDatabase { r -> r.onSuccess { say(L("ბაზა გასუფთავდა — იწყებთ ცარიელიდან"), "База очищена — начинаете с нуля") } }
                            }
                        }) { Text(if (wipeStep == 1) tr("გაგრძელება", "Продолжить") else tr("ყველაფრის წაშლა", "Удалить всё")) } },
                    dismissButton = { TextButton(onClick = { wipeStep = 0 }) { Text(tr("გაუქმება", "Отмена")) } }
                )
            }
            if (showAssistantDialog) {
                com.example.ui.components.SynagogueAssistantDialog(
                    viewModel = viewModel,
                    autoListen = assistantVoice,
                    onDismiss = { showAssistantDialog = false; assistantVoice = false },
                    onStartTour = { showAssistantDialog = false; com.example.ui.components.GuidedTour.start() },
                    onCommand = { cmd ->
                        showAssistantDialog = false; assistantVoice = false
                        cmd.search?.let(viewModel::setSearchQuery)
                        if (cmd.openNeder) showNederDialog = true
                        else cmd.screen?.let { viewModel.setScreen(it) }
                    }
                )
            }
            if (showSos) SosDialog(state) { showSos = false }
            if (showNederDialog) {
                com.example.ui.components.QuickNederDialog(
                    memberNames = state.members.filter { it.status != com.example.data.model.MemberStatus.DECEASED }.map { it.fullName },
                    onAddMember = { viewModel.quickAddMember(it) },
                    onDismiss = { showNederDialog = false },
                    onSave = { name, amount, currency, reason, paid ->
                        viewModel.addQuickNeder(name, amount, currency, reason, paid)
                        showNederDialog = false
                    }
                )
            }
            if (showVoiceDialog) {
                VoiceNavigationDialog(
                    onCommand = { text, command ->
                        command.screen?.let(viewModel::setScreen)
                        command.search?.let(viewModel::setSearchQuery)
                        if (command.openNeder) { showVoiceDialog = false; showNederDialog = true }
                    },
                    onDismiss = { showVoiceDialog = false }
                )
            }
        }
    }
}
