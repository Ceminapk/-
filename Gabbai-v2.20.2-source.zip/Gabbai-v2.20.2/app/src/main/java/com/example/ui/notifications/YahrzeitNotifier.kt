package com.example.ui.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.model.YahrzeitEntity
import com.example.ui.calendar.YahrzeitTools
import com.example.ui.settings.L

object YahrzeitNotifier {
    private const val CHANNEL = "yahrzeit_reminders"

    fun notifyUpcoming(context: Context, items: List<YahrzeitEntity>, leadDays: Int) {
        val upcoming = YahrzeitTools.within(items, leadDays)
        if (upcoming.isEmpty()) return
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, L("იორცაიტის შეხსენებები"), NotificationManager.IMPORTANCE_DEFAULT)
        )
        val first = upcoming.first()
        val more = if (upcoming.size > 1) L(" და კიდევ ${upcoming.size - 1}") else ""
        val text = "${first.item.deceasedName} — ${first.daysUntil} ${L("დღეში")}; ${first.item.relatedMemberName}$more"
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(L("მოახლოებული იორცაიტი"))
            .setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true).build()
        NotificationManagerCompat.from(context).notify(2701, notification)
    }
}
