package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color

// Raw night palette (used by color schemes outside composition)
val NightDeepSpace = Color(0xFF07251C)
val NightDarkSurface = Color(0xFF0C3B2E)
val NightSurfaceCard = Color(0xFF134836)
val NightSurfaceGlass = Color(0xE6104234)
val NightBorderGlow = Color(0x996D9773)
val NightCyan = Color(0xFF9CC7A2)
val NightGold = Color(0xFFFFBA00)
val NightPurple = Color(0xFFE59A4F)
val NightBlue = Color(0xFFB8D8BC)
val NightRose = Color(0xFFFF86A0)
val NightEmerald = Color(0xFF66E6A3)
val NightTextPrimary = Color(0xFFFFFFFF)
val NightTextSecondary = Color(0xFFDCEBDF)
val NightTextMuted = Color(0xFFADC4B2)

// Day palette: deep caramel / parchment tones with near-black inks (darker, calmer than plain cream)
val DaySky = Color(0xFFE6F4EA)
val DaySurface = Color(0xFFF4FAF5)
val DayCard = Color(0xFFFFFFFF)
val DayGlass = Color(0xF2FFFFFF)
val DayBorder = Color(0x996D9773)
val DayTextPrimary = Color(0xFF0C3B2E)
val DayTextSecondary = Color(0xFF24503F)
val DayTextMuted = Color(0xFF4A6B55)
val DayForest = Color(0xFF0C3B2E)
val DayForestDark = Color(0xFF082721)
val DayGold = Color(0xFF8F4F0F)
val DayWine = Color(0xFF7A1C33)
val DayTeal = Color(0xFF3F6E48)
val DayPurple = Color(0xFFB46617)
val DayBlue = Color(0xFF2F5D45)
val DayEmerald = Color(0xFF0F5530)
/** Text/icon colour that is always readable on a solid accent-coloured button. */
val DayOnAccent = Color(0xFFFFFFFF)

/** One full colour set; each app theme has a night and a day variant. */
data class ThemeColors(
    val deep: Color, val dark: Color, val card: Color, val glass: Color, val border: Color,
    val cyan: Color, val gold: Color, val purple: Color, val blue: Color, val rose: Color, val emerald: Color,
    val text: Color, val text2: Color, val muted: Color, val onAccent: Color
)

val EmeraldNight = ThemeColors(NightDeepSpace, NightDarkSurface, NightSurfaceCard, NightSurfaceGlass, NightBorderGlow, NightCyan, NightGold, NightPurple, NightBlue, NightRose, NightEmerald, NightTextPrimary, NightTextSecondary, NightTextMuted, NightDeepSpace)
val EmeraldDay = ThemeColors(DaySky, DaySurface, DayCard, DayGlass, DayBorder, DayTeal, DayGold, DayPurple, DayBlue, DayWine, DayEmerald, DayTextPrimary, DayTextSecondary, DayTextMuted, DayOnAccent)

private fun night(deep: Long, dark: Long, card: Long, glass: Long, border: Long, cyan: Long, gold: Long, purple: Long, blue: Long, text2: Long, muted: Long) =
    ThemeColors(Color(deep), Color(dark), Color(card), Color(glass), Color(border), Color(cyan), Color(gold), Color(purple), Color(blue), NightRose, NightEmerald, NightTextPrimary, Color(text2), Color(muted), Color(deep))
private fun day(sky: Long, surface: Long, border: Long, accent: Long, gold: Long, purple: Long, blue: Long, text: Long, text2: Long, muted: Long) =
    ThemeColors(Color(sky), Color(surface), DayCard, DayGlass, Color(border), Color(accent), Color(gold), Color(purple), Color(blue), DayWine, DayEmerald, Color(text), Color(text2), Color(muted), DayOnAccent)

/** Night/day colour pair of every selectable theme (EMERALD is the original look). */
fun themeColors(theme: com.example.ui.settings.AppTheme, isNight: Boolean): ThemeColors = when (theme) {
    com.example.ui.settings.AppTheme.EMERALD -> if (isNight) EmeraldNight else EmeraldDay
    com.example.ui.settings.AppTheme.ROYAL_BLUE -> if (isNight) night(0xFF0A1530, 0xFF10214A, 0xFF17306A, 0xE6122656, 0x995B7BD5, 0xFF9DB8FF, 0xFFE8C468, 0xFFD9A441, 0xFFC4D4FF, 0xFFDCE4FA, 0xFFA9B7DA)
        else day(0xFFE8EEFB, 0xFFF5F8FE, 0x995B7BD5, 0xFF1F3F8F, 0xFF8A6512, 0xFFA77A1B, 0xFF2B4C9B, 0xFF0F1F48, 0xFF233A70, 0xFF4B5D87)
    com.example.ui.settings.AppTheme.JERUSALEM_STONE -> if (isNight) night(0xFF2A2219, 0xFF3A3023, 0xFF4A3D2D, 0xE6403527, 0x99C9AE7E, 0xFFE6D3AE, 0xFFF2C872, 0xFFD19A5B, 0xFFEAD9B8, 0xFFF2E7D3, 0xFFC9B79A)
        else day(0xFFF3EBDD, 0xFFFAF5EC, 0x99B39A6B, 0xFF6B5432, 0xFF8C5E14, 0xFF9A6A2E, 0xFF5E4A2C, 0xFF33281A, 0xFF4E3F2A, 0xFF6E5E46)
    com.example.ui.settings.AppTheme.ONYX_ICE -> if (isNight) night(0xFF0B0D10, 0xFF14181D, 0xFF1E242B, 0xE61A1F25, 0x9989C2D9, 0xFFA8E4F5, 0xFFE0F2FA, 0xFF7FC8E0, 0xFFCFE9F2, 0xFFDCE6EB, 0xFFA3B1B8)
        else day(0xFFEEF3F6, 0xFFF8FAFB, 0x9989A9B9, 0xFF1E4A5C, 0xFF2D6478, 0xFF3F7F96, 0xFF294E5E, 0xFF101A20, 0xFF26363F, 0xFF52626B)
    com.example.ui.settings.AppTheme.BORDEAUX -> if (isNight) night(0xFF240A12, 0xFF36101C, 0xFF4A1727, 0xE6401422, 0x99C46A7F, 0xFFF0B2C0, 0xFFF2C14E, 0xFFE38E5A, 0xFFF5CCD5, 0xFFF4DDE2, 0xFFC9A3AC)
        else day(0xFFF8E9EC, 0xFFFDF5F6, 0x99A84D62, 0xFF6E1630, 0xFF8A5C0E, 0xFF9C4A1F, 0xFF7A2A40, 0xFF3A0A18, 0xFF5A1F30, 0xFF7A4A56)
    com.example.ui.settings.AppTheme.MAHOGANY -> if (isNight) night(0xFF1F120A, 0xFF2E1B10, 0xFF3F2618, 0xE6372114, 0x99D08A4A, 0xFFF0C08A, 0xFFFFB238, 0xFFE07B39, 0xFFF3D3B0, 0xFFF5E2CE, 0xFFCDAE92)
        else day(0xFFF7ECE2, 0xFFFCF6F0, 0x99B07040, 0xFF6A3412, 0xFF9A5A08, 0xFFAA5A1E, 0xFF7A4020, 0xFF341A0A, 0xFF52301A, 0xFF755640)
}

@Composable @ReadOnlyComposable
private fun c(): ThemeColors = LocalGabbaiPalette.current.colors

// Theme-aware accents: every screen reads these, so day mode and every theme stay readable.
val CosmicDeepSpace: Color @Composable @ReadOnlyComposable get() = c().deep
val CosmicDarkSurface: Color @Composable @ReadOnlyComposable get() = c().dark
val CosmicSurfaceCard: Color @Composable @ReadOnlyComposable get() = c().card
val CosmicSurfaceGlass: Color @Composable @ReadOnlyComposable get() = c().glass
val CosmicBorderGlow: Color @Composable @ReadOnlyComposable get() = c().border
val CosmicStardustCyan: Color @Composable @ReadOnlyComposable get() = c().cyan
val CosmicCelestialGold: Color @Composable @ReadOnlyComposable get() = c().gold
val CosmicNebulaPurple: Color @Composable @ReadOnlyComposable get() = c().purple
val CosmicAuroraBlue: Color @Composable @ReadOnlyComposable get() = c().blue
val CosmicAlertRose: Color @Composable @ReadOnlyComposable get() = c().rose
val CosmicEmeraldSuccess: Color @Composable @ReadOnlyComposable get() = c().emerald
val CosmicTextPrimary: Color @Composable @ReadOnlyComposable get() = c().text
val CosmicTextSecondary: Color @Composable @ReadOnlyComposable get() = c().text2
val CosmicTextMuted: Color @Composable @ReadOnlyComposable get() = c().muted

/** Readable text colour for solid accent buttons in both modes. */
val CosmicOnAccent: Color @Composable @ReadOnlyComposable get() = c().onAccent
