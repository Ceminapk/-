package com.example.ui.calendar

/** Georgian/Russian spelling of common Jewish names → Hebrew spelling (used for aliyah calls, Mi Shebeirach, Hazkara). */
object HebrewNames {
    private val map: Map<String, String> = linkedMapOf(
        "იაკობ" to "יעקב", "იაკოვ" to "יעקב", "იაშა" to "יעקב", "აბრაამ" to "אברהם", "ავრაამ" to "אברהם", "ისააკ" to "יצחק", "იცხაკ" to "יצחק",
        "მოშე" to "משה", "მოისე" to "משה", "მიხეილ" to "מיכאל", "დავით" to "דוד", "სოლომონ" to "שלמה", "შლომო" to "שלמה", "იოსებ" to "יוסף", "იოსეფ" to "יוסף",
        "ბენიამინ" to "בנימין", "ელიაჰუ" to "אליהו", "ილია" to "אליהו", "აარონ" to "אהרן", "შმუელ" to "שמואל", "სამუელ" to "שמואל", "რუბენ" to "ראובן",
        "შიმონ" to "שמעון", "სიმონ" to "שמעון", "ლევი" to "לוי", "იეჰუდა" to "יהודה", "იუდა" to "יהודה", "ნათან" to "נתן", "ნისან" to "ניסן",
        "მენახემ" to "מנחם", "მორდეხაი" to "מרדכי", "გავრიელ" to "גבריאל", "გაბრიელ" to "גבריאל", "რაფაელ" to "רפאל", "იონა" to "יונה", "ნოახ" to "נח",
        "ზალმან" to "זלמן", "ხაიმ" to "חיים", "იეჰოშუა" to "יהושע", "ელიეზერ" to "אליעזר", "ელდარ" to "אלדד", "დანიელ" to "דניאל", "იოელ" to "יואל",
        "იზრაელ" to "ישראל", "ისრაელ" to "ישראל", "ზახარია" to "זכריה", "ხანანია" to "חנניה", "ბარუხ" to "ברוך", "მეირ" to "מאיר", "ურიელ" to "אוריאל",
        "სარა" to "שרה", "რივკა" to "רבקה", "რებეკა" to "רבקה", "რახელ" to "רחל", "რახილ" to "רחל", "ლეა" to "לאה", "მირიამ" to "מרים", "მარიამ" to "מרים",
        "ხანა" to "חנה", "ანა" to "חנה", "ესთერ" to "אסתר", "ესთერა" to "אסתר", "დებორა" to "דבורה", "რუთ" to "רות", "იეხევედ" to "יוכבד", "ციპორა" to "צפורה",
        "შოშანა" to "שושנה", "ბათშევა" to "בת שבע", "ნაომი" to "נעמי", "ავიგაილ" to "אביגיל", "ელისევა" to "אלישבע", "მალკა" to "מלכה", "ხავა" to "חוה", "ევა" to "חוה",
        "იეფეთ" to "יפת", "მანუელ" to "עמנואל", "ელიშა" to "אלישע"
    )

    private fun norm(w: String) = w.lowercase().trim().trimEnd('ი', 'ა', 'ს').ifEmpty { w.lowercase().trim() }

    /** Hebrew spelling of one first name, or null when unknown. */
    fun of(name: String): String? {
        val w = name.trim().split(" ", "-").firstOrNull().orEmpty().lowercase()
        if (w.isBlank()) return null
        map[w]?.let { return it }
        val n = norm(w)
        return map.entries.firstOrNull { norm(it.key) == n }?.value
    }

    /** "יעקב בן שרה" style call name: son/daughter of the mother (for prayers) or father (for aliyah). */
    fun callName(name: String, parent: String, daughter: Boolean = false): String {
        val a = of(name) ?: name; val b = of(parent) ?: parent
        return if (b.isBlank()) a else "$a ${if (daughter) "בת" else "בן"} $b"
    }

    val all: List<Pair<String, String>> get() = map.entries.map { it.key to it.value }
}
