package com.example.ui.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.ui.settings.L
import java.io.File

/** One-tap messaging: WhatsApp, SMS, phone call and the system share sheet. */
object Share {
    /** Normalises a phone number for wa.me (digits only; a leading 0 becomes the Georgian code 995). */
    fun waNumber(phone: String, defaultCountry: String = "995"): String {
        val digits = phone.filter { it.isDigit() }
        if (digits.isEmpty()) return ""
        return when {
            phone.trim().startsWith("+") -> digits
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") -> defaultCountry + digits.drop(1)
            digits.length == 9 && defaultCountry == "995" -> defaultCountry + digits
            else -> digits
        }
    }

    fun whatsapp(context: Context, phone: String, text: String) {
        val n = waNumber(phone)
        val uri = Uri.parse("https://wa.me/" + n + "?text=" + Uri.encode(text))
        start(context, Intent(Intent.ACTION_VIEW, uri)) { text(context, text) }
    }

    fun sms(context: Context, phone: String, text: String) {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone.filter { it.isDigit() || it == '+' })).putExtra("sms_body", text)
        start(context, i) { text(context, text) }
    }

    fun call(context: Context, phone: String) {
        start(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone.filter { it.isDigit() || it == '+' }))) {}
    }

    fun url(context: Context, url: String) {
        start(context, Intent(Intent.ACTION_VIEW, Uri.parse(url))) {}
    }

    fun text(context: Context, text: String, title: String = L("გაზიარება")) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        start(context, Intent.createChooser(i, title)) {}
    }

    fun image(context: Context, bitmap: Bitmap, name: String, caption: String) {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, "$name.png")
        f.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_TEXT, caption)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        start(context, Intent.createChooser(i, L("გაზიარება"))) {}
    }

    private fun start(context: Context, intent: Intent, fallback: () -> Unit) {
        try { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) {
            Toast.makeText(context, L("შესაბამისი აპლიკაცია ვერ მოიძებნა"), Toast.LENGTH_SHORT).show()
            fallback()
        }
    }
}
