package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.exifinterface.media.ExifInterface
import com.example.ui.settings.L
import java.io.ByteArrayOutputStream

/** Member photos: small bounded JPEG thumbnails stored as Base64 inside the member record. */
object MemberPhotos {
    const val MAX_EDGE = 256
    const val MAX_BYTES = 48 * 1024

    fun sampleSize(w: Int, h: Int, target: Int = MAX_EDGE): Int {
        var s = 1
        while (w / (s * 2) >= target && h / (s * 2) >= target) s *= 2
        return s
    }

    fun scaled(bmp: Bitmap, edge: Int = MAX_EDGE): Bitmap {
        val longest = maxOf(bmp.width, bmp.height)
        if (longest <= edge) return bmp
        val f = edge.toFloat() / longest
        return Bitmap.createScaledBitmap(bmp, maxOf(1, (bmp.width * f).toInt()), maxOf(1, (bmp.height * f).toInt()), true)
    }

    /** Encodes to JPEG, lowering quality until it fits MAX_BYTES. */
    fun encode(bmp: Bitmap): String? {
        val small = scaled(bmp)
        var q = 85
        while (q >= 25) {
            val out = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, q, out)
            if (out.size() <= MAX_BYTES) return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            q -= 15
        }
        return null
    }

    fun decode(b64: String): Bitmap? = if (b64.isBlank()) null else try {
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    } catch (e: Exception) { null }

    fun read(context: Context, uri: Uri): String? = loadBitmap(context, uri)?.let { encode(it) }

    /** Square crop window: zoom >= 1 shrinks the square; centre (cx, cy) is 0..1 and clamped inside the image. */
    fun cropRect(w: Int, h: Int, zoom: Float, cx: Float, cy: Float): android.graphics.Rect {
        val side = maxOf(1, (minOf(w, h) / zoom.coerceIn(1f, 4f)).toInt())
        val left = (cx * w - side / 2f).toInt().coerceIn(0, w - side)
        val top = (cy * h - side / 2f).toInt().coerceIn(0, h - side)
        return android.graphics.Rect(left, top, left + side, top + side)
    }

    fun rotate(bmp: Bitmap, degrees: Float): Bitmap =
        if (degrees % 360f == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees) }, true)

    fun crop(bmp: Bitmap, zoom: Float, cx: Float, cy: Float): Bitmap {
        val r = cropRect(bmp.width, bmp.height, zoom, cx, cy)
        return Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height())
    }

    /** Loads an editable working copy (bounded to EDIT_EDGE) with EXIF orientation applied. */
    const val EDIT_EDGE = 1024
    fun loadBitmap(context: Context, uri: Uri): Bitmap? = try {
        val cr = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, EDIT_EDGE) }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val rot = cr.openInputStream(uri)?.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f
        scaled(rotate(bmp, rot), EDIT_EDGE)
    } catch (e: Exception) { null }
}

@Composable
fun MemberPhoto(photoBase64: String, size: Dp, accent: Color, modifier: Modifier = Modifier, fallback: @Composable () -> Unit) {
    val img: ImageBitmap? = remember(photoBase64) { MemberPhotos.decode(photoBase64)?.asImageBitmap() }
    Box(
        modifier = modifier.size(size).clip(CircleShape).background(accent.copy(alpha = 0.14f)).border(1.5.dp, accent, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (img != null) Image(img, contentDescription = L("წევრის ფოტო"), contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().testTag("member_photo"))
        else fallback()
    }
}

@Composable
fun MemberPhotoEditor(photoBase64: String, onChange: (String) -> Unit) {
    val context = LocalContext.current
    var error by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Bitmap?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { val b = MemberPhotos.loadBitmap(context, uri); if (b != null) { pending = b; error = false } else error = true }
    }
    // Camera preview needs no CAMERA permission because the app does not declare it.
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
        if (bmp != null) { pending = bmp; error = false }
    }
    val accent = MaterialTheme.colorScheme.primary
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        MemberPhoto(photoBase64, 72.dp, accent) {
            Icon(Icons.Default.PhotoCamera, null, tint = accent, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(
                onClick = { try { camera.launch(null) } catch (e: Exception) { error = true } },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("photo_camera")
            ) { Icon(Icons.Default.PhotoCamera, null); Spacer(Modifier.width(6.dp)); Text(L("კამერით გადაღება"), maxLines = 1) }
            OutlinedButton(
                onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("photo_pick")
            ) { Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.width(6.dp)); Text(L("გალერეიდან არჩევა"), maxLines = 1) }
            if (photoBase64.isNotBlank()) {
                OutlinedButton(
                    onClick = { onChange("") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("photo_remove")
                ) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(6.dp)); Text(L("ფოტოს წაშლა"), maxLines = 1) }
            }
            if (error) Text(L("ფოტო ვერ ჩაიტვირთა"), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }
    pending?.let { src ->
        PhotoCropDialog(src, onDismiss = { pending = null }) { result ->
            val enc = MemberPhotos.encode(result)
            if (enc != null) { onChange(enc); error = false } else error = true
            pending = null
        }
    }
}

/** Crop to a square and rotate in 90° steps before the photo is saved. */
@Composable
fun PhotoCropDialog(source: Bitmap, onDismiss: () -> Unit, onDone: (Bitmap) -> Unit) {
    var degrees by remember { mutableStateOf(0f) }
    var zoom by remember { mutableStateOf(1f) }
    var cx by remember { mutableStateOf(0.5f) }
    var cy by remember { mutableStateOf(0.5f) }
    val rotated = remember(source, degrees) { MemberPhotos.rotate(source, degrees) }
    val preview = remember(rotated, zoom, cx, cy) { MemberPhotos.crop(rotated, zoom, cx, cy).asImageBitmap() }
    FormDialog(
        onDismissRequest = onDismiss,
        title = { Text(L("ფოტოს მოჭრა და შემობრუნება")) },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Image(
                    preview, contentDescription = L("წევრის ფოტო"), contentScale = ContentScale.Crop,
                    modifier = Modifier.size(220.dp).clip(CircleShape).testTag("crop_preview")
                        .pointerInput(rotated, zoom) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                val k = 1f / (size.width * zoom)
                                cx = (cx - drag.x * k * minOf(rotated.width, rotated.height) / rotated.width).coerceIn(0f, 1f)
                                cy = (cy - drag.y * k * minOf(rotated.width, rotated.height) / rotated.height).coerceIn(0f, 1f)
                            }
                        }
                )
                Text(L("გადაათრიეთ ფოტო სასურველ ადგილზე"), style = MaterialTheme.typography.bodySmall)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ZoomIn, null)
                    Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 1f..4f, modifier = Modifier.weight(1f).testTag("crop_zoom"))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { degrees = (degrees + 270f) % 360f }, modifier = Modifier.weight(1f).testTag("rotate_left")) {
                        Icon(Icons.Default.RotateLeft, contentDescription = L("მარცხნივ შემობრუნება"))
                    }
                    OutlinedButton(onClick = { degrees = (degrees + 90f) % 360f }, modifier = Modifier.weight(1f).testTag("rotate_right")) {
                        Icon(Icons.Default.RotateRight, contentDescription = L("მარჯვნივ შემობრუნება"))
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onDone(MemberPhotos.crop(rotated, zoom, cx, cy)) }, modifier = Modifier.testTag("crop_save")) { Text(L("შენახვა"), maxLines = 1) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L("გაუქმება"), maxLines = 1) } }
    )
}
