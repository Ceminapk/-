package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppDropdown
import com.example.ui.components.CosmicGlassCard
import com.example.ui.settings.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSettingsChange: (AppSettings) -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onWipe: () -> Unit,
    onExport: () -> Unit,
    onCategoryExport: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 16.dp).testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp)
    ) {
        item {
            SettingsSection(L("ენა და განათება"), Icons.Default.Translate) {
                val langs = AppLanguage.values().toList()
                SegmentedPills(
                    options = langs.map { it.nativeName to null },
                    selected = langs.indexOf(settings.language),
                    onSelect = { onSettingsChange(settings.copy(language = langs[it])) },
                    tag = "lang_pills"
                )
                Spacer(Modifier.height(10.dp))
                SegmentedPills(
                    options = listOf(L("დღე") to Icons.Default.LightMode, L("ღამე") to Icons.Default.DarkMode),
                    selected = if (settings.lighting == LightingMode.DAY) 0 else 1,
                    onSelect = { onSettingsChange(settings.copy(lighting = if (it == 0) LightingMode.DAY else LightingMode.NIGHT)) },
                    tag = "lighting_pills"
                )
            }
        }
        item {
            SettingsSection(L("ნაგულისხმევი ვალუტა"), Icons.Default.CurrencyExchange) {
                Text(
                    L("ახალი ჩანაწერები ავტომატურად ამ ვალუტით შეიქმნება. თითოეულ ფორმაში შეგიძლიათ სხვა ვალუტის არჩევა."),
                    color = CosmicTextSecondary, style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(10.dp))
                AppDropdown(
                    label = L("ვალუტა"),
                    value = Currencies.find(settings.currency),
                    options = Currencies.all,
                    optionLabel = { "${it.code} — ${L(it.nameKa)}" },
                    onSelected = { onSettingsChange(settings.copy(currency = it.code)) }
                )
            }
        }
        item {
            SettingsSection(L("ლოცვები და შეხსენებები"), Icons.Default.NotificationsActive) {
                var shacharit by remember(settings.shacharitTime) { mutableStateOf(settings.shacharitTime) }
                var days by remember(settings.yahrzeitReminderDays) { mutableStateOf(settings.yahrzeitReminderDays.toString()) }
                OutlinedTextField(
                    value = shacharit,
                    onValueChange = { value ->
                        shacharit = value.take(5)
                        if (Regex("^(?:[01]\\d|2[0-3]):[0-5]\\d$").matches(shacharit)) onSettingsChange(settings.copy(shacharitTime = shacharit))
                    },
                    label = { Text(L("შახარითის დრო (HH:mm)")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = days,
                    onValueChange = { value ->
                        days = value.filter(Char::isDigit).take(3)
                        days.toIntOrNull()?.coerceIn(1, 365)?.let { onSettingsChange(settings.copy(yahrzeitReminderDays = it)) }
                    },
                    label = { Text(L("რამდენი დღით ადრე გამოჩნდეს იორცაიტი")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                var bdays by remember(settings.birthdayReminderDays) { mutableStateOf(settings.birthdayReminderDays.toString()) }
                OutlinedTextField(
                    value = bdays,
                    onValueChange = { value ->
                        bdays = value.filter(Char::isDigit).take(3)
                        bdays.toIntOrNull()?.coerceIn(0, 365)?.let { onSettingsChange(settings.copy(birthdayReminderDays = it)) }
                    },
                    label = { Text(L("დაბადების დღის შეხსენება — რამდენი დღით ადრე")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("birthday_days_field")
                )
                Spacer(Modifier.height(10.dp))
                var shul by remember(settings.synagogueName) { mutableStateOf(settings.synagogueName) }
                OutlinedTextField(shul, { shul = it; onSettingsChange(settings.copy(synagogueName = it)) },
                    label = { Text(L("სინაგოგის სახელი (შეტყობინებებსა და ბარათებში)")) }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("synagogue_name_field"))
                Spacer(Modifier.height(10.dp))
                var budget by remember(settings.utilityBudget) { mutableStateOf(if (settings.utilityBudget > 0) settings.utilityBudget.toLong().toString() else "") }
                OutlinedTextField(budget, { v -> budget = v.filter(Char::isDigit).take(9); onSettingsChange(settings.copy(utilityBudget = budget.toDoubleOrNull() ?: 0.0)) },
                    label = { Text(L("კომუნალურის თვიური ბიუჯეტი (0 = ლიმიტის გარეშე)")) }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("utility_budget_field"))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(settings.speakAnswers, { onSettingsChange(settings.copy(speakAnswers = it)) })
                    Spacer(Modifier.width(8.dp))
                    Text(L("AI ასისტენტი პასუხს ხმამაღლა კითხულობს"), color = CosmicTextSecondary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(settings.shabbatQuiet, { onSettingsChange(settings.copy(shabbatQuiet = it)) }, modifier = Modifier.testTag("shabbat_quiet_switch"))
                    Spacer(Modifier.width(8.dp))
                    Text(L("შაბათის ჩუმი რეჟიმი — შაბათსა და დღესასწაულზე შეხსენებები ჩერდება და გასვლის შემდეგ ჩნდება"), color = CosmicTextSecondary)
                }
            }
        }
        item {
            SettingsSection(L("გარეგნობა და სინაგოგის ბრენდი"), Icons.Default.Palette) {
                AppDropdown(label = L("ფერთა თემა"), value = settings.theme, options = AppTheme.values().toList(), optionLabel = { L(it.titleKa) },
                    onSelected = { onSettingsChange(settings.copy(theme = it)) }, modifier = Modifier.fillMaxWidth().testTag("theme_picker"))
                Spacer(Modifier.height(10.dp))
                AppDropdown(label = L("შრიფტის ზომა"), value = settings.fontScale, options = FontScale.values().toList(), optionLabel = { L(it.titleKa) },
                    onSelected = { onSettingsChange(settings.copy(fontScale = it)) }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                AppDropdown(label = L("გუმბათის ანიმაცია"), value = settings.domeStyle, options = DomeStyle.values().toList(), optionLabel = { L(it.titleKa) },
                    onSelected = { onSettingsChange(settings.copy(domeStyle = it)) }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                AppDropdown(label = L("შაბათის დროები გუმბათზე"), value = settings.shabbatTimesDaily, options = listOf(false, true),
                    optionLabel = { if (it) L("ყოველ დღე") else L("მხოლოდ ოთხშაბათიდან") },
                    onSelected = { onSettingsChange(settings.copy(shabbatTimesDaily = it)) }, modifier = Modifier.fillMaxWidth().testTag("shabbat_times_mode"))
                Spacer(Modifier.height(10.dp))
                AppDropdown(label = L("სინაგოგის ემბლემა"), value = settings.emblem, options = listOf("✡", "🕎", "📜", "🕍", "👑", "🦁", "🕯", "✦"), optionLabel = { it },
                    onSelected = { onSettingsChange(settings.copy(emblem = it)) }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(settings.haptics, { onSettingsChange(settings.copy(haptics = it)) })
                    Spacer(Modifier.width(8.dp))
                    Text(L("შეხებისას ნაზი ვიბრაცია"), color = CosmicTextSecondary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(settings.autoBackup, { onSettingsChange(settings.copy(autoBackup = it)) })
                    Spacer(Modifier.width(8.dp))
                    Text(L("ავტომატური ბექაფი ტელეფონში ყოველდღე (ბოლო 7 ასლი)"), color = CosmicTextSecondary)
                }
            }
        }
        item { ComplianceSettingsSection() }
        item { OwnGeminiKeySection() }
        item { OnlineTeamSection() }
        item {
            SettingsSection(L("მონაცემები"), Icons.Default.Storage) {
                SettingsAction(L("სრული Excel ექსპორტი"), Icons.Default.TableChart, onExport)
                SettingsAction(L("ექსპორტი კატეგორიების მიხედვით"), Icons.Default.FilterList, onCategoryExport)
                SettingsAction(L("სარეზერვო ასლის შექმნა"), Icons.Default.Backup, onBackup)
                SettingsAction(L("ასლიდან აღდგენა"), Icons.Default.Restore, onRestore)
                SettingsAction(L("ბაზის სრული გასუფთავება"), Icons.Default.DeleteForever, onWipe, danger = true)
            }
        }
        item {
            CosmicGlassCard(Modifier.fillMaxWidth()) {
                Text("Gabbai Cosmos 2.19", fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                Text(L("სინაგოგისა და ქოლელის მართვა"), color = CosmicTextSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    CosmicGlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = CosmicCelestialGold, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(8.dp))
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = CosmicTextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}

/** Compact segmented control: one soft track, the chosen option glides as a filled pill. */
@Composable
fun SegmentedPills(options: List<Pair<String, ImageVector?>>, selected: Int, onSelect: (Int) -> Unit, tag: String = "segmented") {
    val primary = MaterialTheme.colorScheme.primary
    val palette = LocalGabbaiPalette.current
    BoxWithConstraints(
        Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(21.dp))
            .background(palette.background.copy(alpha = 0.6f))
            .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(21.dp))
            .padding(3.dp).testTag(tag)
    ) {
        val w = maxWidth / options.size
        val x by androidx.compose.animation.core.animateDpAsState(w * selected.coerceAtLeast(0), androidx.compose.animation.core.tween(320), label = "seg")
        Box(Modifier.offset(x = x).width(w).fillMaxHeight().shadow(3.dp, RoundedCornerShape(18.dp), spotColor = primary).clip(RoundedCornerShape(18.dp)).background(primary))
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { i, (label, icon) ->
                val on = i == selected
                val color by androidx.compose.animation.animateColorAsState(if (on) MaterialTheme.colorScheme.onPrimary else palette.text, androidx.compose.animation.core.tween(300), label = "segc")
                Row(
                    Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(18.dp)).clickable { onSelect(i) },
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                ) {
                    if (icon != null) { Icon(icon, null, tint = color, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)) }
                    Text(label, color = color, fontSize = 13.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun ChoiceTile(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    val primary = MaterialTheme.colorScheme.primary
    val palette = LocalGabbaiPalette.current
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .shadow(if (selected) 3.dp else 0.dp, shape, spotColor = primary)
            .clip(shape)
            .background(
                if (selected) Brush.verticalGradient(listOf(primary.copy(alpha = 0.85f), primary))
                else Brush.verticalGradient(listOf(palette.glass, palette.surface))
            )
            .border(1.dp, if (selected) primary else palette.border.copy(alpha = 0.35f), shape)
            .clickable(onClick = onClick)
            .heightIn(min = 42.dp)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, null, tint = if (selected) MaterialTheme.colorScheme.onPrimary else palette.text, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
            }
            Text(
                text, color = if (selected) MaterialTheme.colorScheme.onPrimary else palette.text,
                fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SettingsAction(text: String, icon: ImageVector, onClick: () -> Unit, danger: Boolean = false) {
    val color = if (danger) MaterialTheme.colorScheme.error else LocalGabbaiPalette.current.text
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(text, color = color, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, null, tint = LocalGabbaiPalette.current.mutedText)
    }
}


@Composable
private fun OwnGeminiKeySection() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    remember { com.example.data.service.GeminiDirect.init(context); 0 }
    var key by remember { mutableStateOf(com.example.data.service.GeminiDirect.key()) }
    var status by remember { mutableStateOf(if (com.example.data.service.GeminiDirect.hasKey()) L("გასაღები შენახულია") else L("გასაღები არ არის — გამოიყენება ტელეფონის უფასო ხმა")) }
    var checking by remember { mutableStateOf(false) }
    SettingsSection(L("ჩემი Gemini API გასაღები"), Icons.Default.Key) {
        Text(L("ჩასვით Google AI Studio-ს უფასო გასაღები. ის ინახება მხოლოდ ამ ტელეფონში და გამოიყენება კითხვებისა და ქართული ხმისთვის. თუ გასაღები არ მუშაობს, ჩაირთვება ტელეფონის უფასო ხმა."),
            color = CosmicTextSecondary, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(key, { key = it.trim() }, label = { Text("API Key") }, singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().testTag("gemini_key_field"))
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(enabled = !checking && key.isNotBlank(), modifier = Modifier.weight(1f), onClick = {
                checking = true; status = L("მოწმდება...")
                scope.launch {
                    val ok = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.example.data.service.GeminiDirect.test(key) }
                    com.example.data.service.GeminiDirect.save(context, key)
                    status = if (ok) L("გასაღები მუშაობს და შენახულია") else L("გასაღები არ მუშაობს — გამოიყენება ტელეფონის უფასო ხმა")
                    checking = false
                }
            }) { Text(L("შენახვა და შემოწმება"), maxLines = 1, overflow = TextOverflow.Ellipsis) }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                key = ""; com.example.data.service.GeminiDirect.save(context, ""); status = L("გასაღები არ არის — გამოიყენება ტელეფონის უფასო ხმა")
            }) { Text(L("წაშლა"), maxLines = 1) }
        }
        Spacer(Modifier.height(6.dp))
        Text(status, color = CosmicTextSecondary, style = MaterialTheme.typography.bodySmall)
    }
}


/** Red / black list rules right in Settings (same values as „სიის წესები“ on the Members screen). */
@Composable
private fun ComplianceSettingsSection() {
    var days by remember { mutableStateOf(ComplianceRules.daysThreshold.toString()) }
    var amount by remember { mutableStateOf(ComplianceRules.amountThreshold.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() }) }
    var saved by remember { mutableStateOf(false) }
    SettingsSection(L("წითელი და შავი სიის წესები"), Icons.Default.Rule) {
        Text(L("წითელ სიაში ავტომატურად ხვდება წევრი, რომლის ვალი აღწევს ლიმიტს ან დიდი ხანია არ გადაუხდია. შავ სიას გაბაი ხელით ადგენს."), color = CosmicTextSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(days, { days = it.filter(Char::isDigit).take(4); saved = false }, label = { Text(L("გადაუხდელობის დღეები"), maxLines = 1) }, singleLine = true,
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number), modifier = Modifier.fillMaxWidth().testTag("settings_red_days"))
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(amount, { amount = it.filter { c -> c.isDigit() || c == '.' }.take(9); saved = false }, label = { Text(L("ვალის ლიმიტი"), maxLines = 1) }, singleLine = true,
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal), modifier = Modifier.fillMaxWidth().testTag("settings_red_amount"))
        Spacer(Modifier.height(8.dp))
        val d = days.toIntOrNull(); val a = amount.toDoubleOrNull()
        Button(onClick = { if (d != null && a != null) { ComplianceRules.save(d, a); saved = true } }, enabled = d != null && d > 0 && a != null && a > 0,
            modifier = Modifier.fillMaxWidth().testTag("settings_red_save")) { Text(if (saved) L("შენახულია ✓") else L("შენახვა")) }
    }
}
