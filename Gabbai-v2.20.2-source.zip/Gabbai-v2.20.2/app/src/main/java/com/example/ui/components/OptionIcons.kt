package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.data.model.*
import com.example.ui.settings.CurrencyInfo

/** One fitting icon for every selectable item in every list of the app. */
object OptionIcons {
    fun registry(name: String): ImageVector = when (name) {
        "MIKVEH" -> Icons.Default.WaterDrop
        "GEMACH" -> Icons.Default.Handshake
        "INSTALLMENT" -> Icons.Default.CalendarMonth
        "AUCTION" -> Icons.Default.Gavel
        "UTILITY" -> Icons.Default.Bolt
        "ORDER" -> Icons.Default.ShoppingCart
        "HANUKKAH" -> Icons.Default.LocalFireDepartment
        "KAPAROT" -> Icons.Default.Savings
        "CHAMETZ" -> Icons.Default.BakeryDining
        "GUESTS" -> Icons.Default.Hotel
        "TEHILLIM" -> Icons.Default.MenuBook
        "EMERGENCY" -> Icons.Default.LocalHospital
        "TORAH_DEFECT" -> Icons.Default.ReportProblem
        "LOST_FOUND" -> Icons.Default.TravelExplore
        "LIBRARY" -> Icons.Default.LocalLibrary
        "KEYS" -> Icons.Default.Key
        "HISTORY" -> Icons.Default.HistoryEdu
        "VOICE_MEMO" -> Icons.Default.KeyboardVoice
        "MINYAN" -> Icons.Default.Groups
        "TORAH_PASSPORT" -> Icons.Default.Badge
        "PUSHKE" -> Icons.Default.Savings
        "PAROCHET" -> Icons.Default.Checkroom
        "GENIZAH" -> Icons.Default.Inventory2
        "VOLUNTEER" -> Icons.Default.VolunteerActivism
        "KIDDUSH_CAL" -> Icons.Default.WineBar
        "BIKUR_CHOLIM" -> Icons.Default.Healing
        "NEW_FAMILY" -> Icons.Default.FamilyRestroom
        "RAV_QUESTION" -> Icons.Default.QuestionAnswer
        "PROGRAM" -> Icons.Default.ChildCare
        "FUND" -> Icons.Default.AccountBalanceWallet
        "MAINTENANCE" -> Icons.Default.Build
        "GOAL" -> Icons.Default.Flag
        "MEZUZAH" -> Icons.Default.SensorDoor
        "MAASER" -> Icons.Default.Percent
        "CALL_CHAIN" -> Icons.Default.PhoneInTalk
        "ALIYAH_PLAN" -> Icons.Default.EventNote
        "SEATING" -> Icons.Default.EventSeat
        "MEMO" -> Icons.Default.StickyNote2
        "BAR_MITZVAH" -> Icons.Default.Cake
        "VIP_GUEST" -> Icons.Default.Star
        "AUDIO_GUIDE" -> Icons.Default.Speaker
        "SUPPLIES" -> Icons.Default.Inventory
        "TIMERS" -> Icons.Default.Timer
        "HALL_BOOKING" -> Icons.Default.MeetingRoom
        "CEMETERY" -> Icons.Default.Place
        "HONOR_WALL" -> Icons.Default.EmojiEvents
        "FOOD_BASKETS" -> Icons.Default.LocalGroceryStore
        "MIKVEH_APPT" -> Icons.Default.Lock
        "SHABBAT_PREP" -> Icons.Default.Checklist
        "SYNAGOGUE_DIR" -> Icons.Default.LocationCity
        else -> Icons.Default.LibraryBooks
    }

    fun category(c: FinanceCategory): ImageVector = when (c.name) {
        "ALIYOT_TORAH" -> Icons.Default.MenuBook
        "NEDARIM_PLEDGES" -> Icons.Default.Handshake
        "MEMBERSHIP_DUES" -> Icons.Default.CardMembership
        "TZEDAKAH_INCOME" -> Icons.Default.VolunteerActivism
        "KIDDUSH_SPONSOR" -> Icons.Default.WineBar
        "YAHRZEIT_LIGHTS" -> Icons.Default.LocalFireDepartment
        "OTHER_INCOME" -> Icons.Default.AddCircleOutline
        "SALARIES_RABBIS" -> Icons.Default.Work
        "UTILITIES_COMMUNAL" -> Icons.Default.Bolt
        "REPAIRS_RENOVATION" -> Icons.Default.Construction
        "SEFER_TORAH_BOOKS" -> Icons.Default.AutoStories
        "EVENTS_CATERING" -> Icons.Default.Restaurant
        "KOLLEL_STIPENDS" -> Icons.Default.School
        "TZEDAKAH_DISBURSEMENT" -> Icons.Default.Favorite
        "SECURITY_CLEANING" -> Icons.Default.Shield
        else -> Icons.Default.Category
    }

    fun aliyah(a: AliyahType): ImageVector = when (a.name) {
        "KOHEN" -> Icons.Default.WorkspacePremium
        "LEVI" -> Icons.Default.WaterDrop
        "SHLISHI" -> Icons.Default.Looks3
        "REVII" -> Icons.Default.Looks4
        "CHAMISHI" -> Icons.Default.Looks5
        "SHISHI" -> Icons.Default.Looks6
        "SHEVII" -> Icons.Default.Filter7
        "MAFTIR" -> Icons.Default.AutoStories
        "HAGBAH" -> Icons.Default.PanTool
        "GELILAH" -> Icons.Default.Loop
        "PETICHA" -> Icons.Default.MeetingRoom
        "PESUKIM" -> Icons.Default.FormatQuote
        "SERVICE" -> Icons.Default.RoomService
        "MOSIF" -> Icons.Default.AddCircle
        "NEDER" -> Icons.Default.Handshake
        else -> Icons.Default.MenuBook
    }

    private val keywords: List<Pair<List<String>, ImageVector>> = listOf(
        listOf("ყველა", "все", "all", "הכל") to Icons.Default.SelectAll,
        listOf("ელექტრ", "დენ", "свет") to Icons.Default.Bolt,
        listOf("გაზ", "газ") to Icons.Default.LocalFireDepartment,
        listOf("წყალ", "вода") to Icons.Default.WaterDrop,
        listOf("ინტერნეტ", "интернет") to Icons.Default.Wifi,
        listOf("ნაღდ", "налич", "cash") to Icons.Default.Payments,
        listOf("ბარათ", "карт", "card") to Icons.Default.CreditCard,
        listOf("ბანკ", "банк", "bank", "გადარიცხ") to Icons.Default.AccountBalance,
        listOf("ალია", "алия", "עלי") to Icons.Default.MenuBook,
        listOf("ნედერ", "נדר") to Icons.Default.Handshake,
        listOf("კიდუშ", "кидуш") to Icons.Default.WineBar,
        listOf("ქორწილ", "свадьб") to Icons.Default.Favorite,
        listOf("ბარ-მიცვა", "ბარ მიცვა", "бар") to Icons.Default.Cake,
        listOf("ხელფას", "зарплат") to Icons.Default.Work,
        listOf("რემონტ", "ремонт") to Icons.Default.Construction,
        listOf("დასუფთ", "убор") to Icons.Default.CleaningServices,
        listOf("დაცვ", "охран") to Icons.Default.Shield,
        listOf("ქოლელ", "колел") to Icons.Default.School,
        listOf("ცედაკა", "цдак") to Icons.Default.VolunteerActivism,
        listOf("სანთ", "свеч") to Icons.Default.LocalFireDepartment,
        listOf("თბილის", "ქუთაის", "ბათუმ", "მოსკოვ", "იერუსალ", "თელ", "ნიუ", "город") to Icons.Default.LocationCity,
        listOf("gps") to Icons.Default.MyLocation,
        listOf("ფარაშ", "פרש") to Icons.Default.AutoStories,
        listOf("გადახდილ", "оплач") to Icons.Default.CheckCircle,
        listOf("მოლოდინ", "ожида", "აქტიურ") to Icons.Default.HourglassTop,
        listOf("დაპირებ", "обещ") to Icons.Default.Handshake,
        listOf("დასრულ", "заверш") to Icons.Default.TaskAlt,
        listOf("გაუქმ", "отмен") to Icons.Default.Cancel,
        listOf("რაბინ", "რავ", "равв") to Icons.Default.Person,
        listOf("გაბაი", "габ") to Icons.Default.ManageAccounts,
        listOf("წევრ", "член") to Icons.Default.Person,
        listOf("გარდაცვ", "умер") to Icons.Default.LocalFireDepartment,
        listOf("თვე", "месяц") to Icons.Default.CalendarMonth,
        listOf("კვირ", "недел") to Icons.Default.DateRange,
        listOf("წელ", "год") to Icons.Default.Event,
    )

    /** Picks an icon for any option: known types first, then keywords in the label. */
    fun of(item: Any?, label: String): ImageVector = when (item) {
        is RegistryKind -> registry(item.name)
        is FinanceCategory -> category(item)
        is AliyahType -> aliyah(item)
        is TransactionType -> if (item == TransactionType.INCOME) Icons.Default.TrendingUp else Icons.Default.TrendingDown
        is TransactionStatus -> when (item) {
            TransactionStatus.PAID -> Icons.Default.CheckCircle
            TransactionStatus.PENDING -> Icons.Default.HourglassTop
            TransactionStatus.PLEDGED -> Icons.Default.Handshake
        }
        is CurrencyInfo -> Icons.Default.Payments
        null -> Icons.Default.SelectAll
        else -> byLabel(label)
    }

    fun byLabel(label: String): ImageVector {
        val l = label.lowercase()
        return keywords.firstOrNull { (keys, _) -> keys.any { l.contains(it) } }?.second ?: Icons.Default.Label
    }
}
