package com.example.ui.settings

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import java.util.Locale

enum class AppLanguage(val tag: String, val nativeName: String, val short: String) {
    KA("ka-GE", "ქართული", "KA"),
    RU("ru-RU", "Русский", "RU"),
    EN("en-US", "English", "EN"),
    HE("he-IL", "עברית", "HE")
}
enum class LightingMode { DAY, NIGHT }

/** Colour themes; translate titles at read time with L(). EMERALD is the original look. */
enum class AppTheme(val titleKa: String) {
    EMERALD("კოსმოსური ზურმუხტი"), ROYAL_BLUE("სამეფო ლურჯი და ოქრო"), JERUSALEM_STONE("იერუსალიმის ქვა"),
    ONYX_ICE("ონიქსი და ყინული"), BORDEAUX("სამეფო ბორდო და ოქრო"), MAHOGANY("მაჰაგონი და ქარვა")
}
enum class FontScale(val factor: Float, val titleKa: String) { SMALL(0.9f, "პატარა"), NORMAL(1f, "ჩვეულებრივი"), LARGE(1.12f, "დიდი"), XLARGE(1.25f, "ძალიან დიდი") }
enum class DomeStyle(val titleKa: String) { COSMOS("კოსმოსი — სრული ანიმაცია"), JERUSALEM("იერუსალიმის ოქროს სხივები"), STILL("უძრავი (ელემენტის დაზოგვა)") }

data class AppSettings(
    val language: AppLanguage = AppLanguage.KA,
    val lighting: LightingMode = LightingMode.NIGHT,
    val currency: String = "GEL",
    val yahrzeitReminderDays: Int = 30,
    val shacharitTime: String = "08:00",
    val birthdayReminderDays: Int = 7,
    val synagogueName: String = "",
    val utilityBudget: Double = 0.0,
    val speakAnswers: Boolean = true,
    val shabbatQuiet: Boolean = true,
    val theme: AppTheme = AppTheme.EMERALD,
    val fontScale: FontScale = FontScale.NORMAL,
    val domeStyle: DomeStyle = DomeStyle.COSMOS,
    val haptics: Boolean = true,
    val autoBackup: Boolean = true,
    /** Emblem shown on the dome next to the synagogue name. */
    val emblem: String = "✡",
    /** Shabbat times on the dome every day (false = only from Wednesday). */
    val shabbatTimesDaily: Boolean = false
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("gabbai_settings", Context.MODE_PRIVATE)
    fun load(): AppSettings {
        val automatic = when (Locale.getDefault().language) {
            "ru" -> "RU"; "en" -> "EN"; "he", "iw" -> "HE"; else -> "KA"
        }
        return AppSettings(
            language = runCatching { AppLanguage.valueOf(prefs.getString("language", automatic) ?: automatic) }.getOrDefault(AppLanguage.KA),
            lighting = runCatching { LightingMode.valueOf(prefs.getString("lighting", "NIGHT") ?: "NIGHT") }.getOrDefault(LightingMode.NIGHT),
            currency = prefs.getString("currency", "GEL")?.takeIf { code -> Currencies.all.any { it.code == code } } ?: "GEL",
            yahrzeitReminderDays = prefs.getInt("yahrzeit_reminder_days", 30).coerceIn(1, 365),
            shacharitTime = prefs.getString("shacharit_time", "08:00") ?: "08:00",
            birthdayReminderDays = prefs.getInt("birthday_reminder_days", 7).coerceIn(0, 365),
            synagogueName = prefs.getString("synagogue_name", "") ?: "",
            utilityBudget = prefs.getFloat("utility_budget", 0f).toDouble(),
            speakAnswers = prefs.getBoolean("speak_answers", true),
            shabbatQuiet = prefs.getBoolean("shabbat_quiet", true),
            theme = runCatching { AppTheme.valueOf(prefs.getString("theme", "EMERALD") ?: "EMERALD") }.getOrDefault(AppTheme.EMERALD),
            fontScale = runCatching { FontScale.valueOf(prefs.getString("font_scale", "NORMAL") ?: "NORMAL") }.getOrDefault(FontScale.NORMAL),
            domeStyle = runCatching { DomeStyle.valueOf(prefs.getString("dome_style", "COSMOS") ?: "COSMOS") }.getOrDefault(DomeStyle.COSMOS),
            haptics = prefs.getBoolean("haptics", true),
            autoBackup = prefs.getBoolean("auto_backup", true),
            emblem = prefs.getString("emblem", "✡") ?: "✡",
            shabbatTimesDaily = prefs.getBoolean("shabbat_times_daily", false)
        )
    }
    fun save(settings: AppSettings) {
        prefs.edit()
            .putString("language", settings.language.name)
            .putString("lighting", settings.lighting.name)
            .putString("currency", settings.currency)
            .putInt("yahrzeit_reminder_days", settings.yahrzeitReminderDays)
            .putString("shacharit_time", settings.shacharitTime)
            .putInt("birthday_reminder_days", settings.birthdayReminderDays)
            .putString("synagogue_name", settings.synagogueName)
            .putFloat("utility_budget", settings.utilityBudget.toFloat())
            .putBoolean("speak_answers", settings.speakAnswers)
            .putBoolean("shabbat_quiet", settings.shabbatQuiet)
            .putString("theme", settings.theme.name)
            .putString("font_scale", settings.fontScale.name)
            .putString("dome_style", settings.domeStyle.name)
            .putBoolean("haptics", settings.haptics)
            .putBoolean("auto_backup", settings.autoBackup)
            .putString("emblem", settings.emblem)
            .putBoolean("shabbat_times_daily", settings.shabbatTimesDaily)
            .apply()
    }
}

val LocalAppSettings = compositionLocalOf { AppSettings() }

/** Legacy two-language helper; Georgian text is the dictionary key for EN/HE. */
@Composable
fun tr(ka: String, ru: String): String = when (I18n.lang) {
    AppLanguage.KA -> I18n.keepHebrewTogether(ka)
    AppLanguage.RU -> I18n.keepHebrewTogether(ru)
    else -> L(ka)
}

/** Synagogue name used in messages and cards. */
fun AppSettings.shulName(): String = synagogueName.ifBlank { L("ჩვენი სინაგოგა") }
