package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.GabbaiDao
import com.example.data.model.*

@Database(
    entities = [
        TransactionEntity::class,
        MemberEntity::class,
        AliyahEntity::class,
        KollelStudentEntity::class,
        KollelAttendanceEntity::class,
        TzedakahEntity::class,
        NeedyBeneficiaryEntity::class,
        SynagogueEventEntity::class,
        YahrzeitEntity::class,
        RegistryEntity::class
    ],
    version = 10,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun gabbaiDao(): GabbaiDao

    companion object {
        /** v2.4 -> v2.5: every money record remembers its currency; existing rows keep working as GEL. */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                listOf("transactions", "members", "aliyot", "kollel_students", "tzedakah_funds", "needy_beneficiaries", "synagogue_events").forEach { t ->
                    db.execSQL("ALTER TABLE `$t` ADD COLUMN `currency` TEXT NOT NULL DEFAULT 'GEL'")
                }
            }
        }

        /** v2.6 -> v2.7: recurring memorials linked to living congregation members. */
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `yahrzeits` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `deceasedName` TEXT NOT NULL, `hebrewName` TEXT NOT NULL, `relatedMemberId` INTEGER NOT NULL, `relatedMemberName` TEXT NOT NULL, `relationship` TEXT NOT NULL, `deathDateMillis` INTEGER NOT NULL, `hebrewMonth` INTEGER NOT NULL, `hebrewDay` INTEGER NOT NULL, `notes` TEXT NOT NULL)""")
            }
        }

        /** v2.7 -> v2.8: members get a birthday (0 = unknown); nothing else changes. */
        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `members` ADD COLUMN `birthDateMillis` INTEGER NOT NULL DEFAULT 0")
            }
        }

        /** v2.8 -> v2.9: optional member photo thumbnail; existing rows keep empty photo. */
        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `members` ADD COLUMN `photoBase64` TEXT NOT NULL DEFAULT ''")
            }
        }

        /** v2.12 -> v2.13: synagogue registers, cemetery location, family links. */
        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS `registry_entries` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `kind` TEXT NOT NULL, `title` TEXT NOT NULL, `memberName` TEXT NOT NULL DEFAULT '', `phone` TEXT NOT NULL DEFAULT '', `dateMillis` INTEGER NOT NULL DEFAULT 0, `dueMillis` INTEGER NOT NULL DEFAULT 0, `amount` REAL NOT NULL DEFAULT 0, `paidAmount` REAL NOT NULL DEFAULT 0, `count` INTEGER NOT NULL DEFAULT 1, `currency` TEXT NOT NULL DEFAULT 'GEL', `status` TEXT NOT NULL DEFAULT 'OPEN', `details` TEXT NOT NULL DEFAULT '', `extra` TEXT NOT NULL DEFAULT '')""")
                db.execSQL("ALTER TABLE `yahrzeits` ADD COLUMN `cemetery` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `yahrzeits` ADD COLUMN `plot` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `members` ADD COLUMN `relatives` TEXT NOT NULL DEFAULT ''")
            }
        }

        /** v2.18 -> v2.19: optional photo on journal records (lost and found). */
        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `registry_entries` ADD COLUMN `photoBase64` TEXT NOT NULL DEFAULT ''")
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gabbai_cosmos_database.db"
                ).addMigrations(MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
