package com.example.ui.components

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

/** The add action of the currently visible screen, shown docked in the bottom panel notch. */
class DockedAction(
    val owner: Any,
    val tag: String,
    val containerColor: Color,
    val contentColor: Color,
    val onClick: () -> Unit,
    val icon: @Composable () -> Unit
)

object DockedAdd {
    var action by mutableStateOf<DockedAction?>(null)
}

/**
 * Drop-in replacement for a screen FloatingActionButton: instead of floating over the list it
 * registers itself so the bottom panel renders it inside its notch. Renders nothing in place.
 */
@Composable
fun DockedAddButton(
    tag: String,
    onClick: () -> Unit,
    containerColor: Color,
    contentColor: Color,
    @Suppress("UNUSED_PARAMETER") modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val owner = remember { Any() }
    val click by rememberUpdatedState(onClick)
    val icon by rememberUpdatedState(content)
    DisposableEffect(tag, containerColor, contentColor) {
        DockedAdd.action = DockedAction(owner, tag, containerColor, contentColor, { click() }, { icon() })
        onDispose { if (DockedAdd.action?.owner === owner) DockedAdd.action = null }
    }
}

/** Bar outline with a smooth circular notch cut into the top centre edge. */
class NotchedBarShape(private val notchRadius: Dp, private val corner: Dp = 18.dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = with(density) { notchRadius.toPx() }
        val c = with(density) { corner.toPx() }
        val w = size.width; val h = size.height; val cx = w / 2f
        val p = Path().apply {
            moveTo(0f, h)
            lineTo(0f, c)
            quadraticBezierTo(0f, 0f, c, 0f)
            lineTo(cx - r * 1.6f, 0f)
            cubicTo(cx - r * 0.95f, 0f, cx - r * 1.05f, r, cx, r)
            cubicTo(cx + r * 1.05f, r, cx + r * 0.95f, 0f, cx + r * 1.6f, 0f)
            lineTo(w - c, 0f)
            quadraticBezierTo(w, 0f, w, c)
            lineTo(w, h)
            close()
        }
        return Outline.Generic(p)
    }
}
