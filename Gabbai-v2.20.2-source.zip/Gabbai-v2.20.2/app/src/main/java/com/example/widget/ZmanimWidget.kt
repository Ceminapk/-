package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.ui.calendar.CalendarPrefs
import com.example.ui.calendar.JewishCalendar
import com.example.ui.settings.I18n
import com.example.ui.settings.L
import com.example.ui.settings.Lf
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Home-screen widget: today's Hebrew date, prayer times and the next candle lighting / havdalah. */
class ZmanimWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        I18n.init(context); CalendarPrefs.init(context)
        val v = build(context)
        ids.forEach { manager.updateAppWidget(it, v) }
    }

    companion object {
        private fun hm(t: Long?) = if (t == null) "—" else SimpleDateFormat("HH:mm", Locale.US).format(Date(t))

        fun build(context: Context): RemoteViews {
            val city = CalendarPrefs.city
            val c = Calendar.getInstance()
            val today = JewishCalendar.day(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), city)
            val (mincha, maariv) = JewishCalendar.prayerTimes(today, city)
            val rest = JewishCalendar.nextRestPeriod(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), city)
            val shacharit = context.getSharedPreferences("gabbai_settings", Context.MODE_PRIVATE).getString("shacharit_time", "08:00")
            val v = RemoteViews(context.packageName, R.layout.widget_zmanim)
            v.setTextViewText(R.id.w_title, "✡ " + L(city.nameKa))
            v.setTextViewText(R.id.w_heb, JewishCalendar.hebrewDateHe(today.heb) + " • " + today.holidays.joinToString { it.he })
            v.setTextViewText(R.id.w_times, Lf("ზრიხა {0} • შახარითი {1} • მინხა {2}\nშკია {3} • ყარბითი {4} • ცეთ {5}",
                hm(today.sunrise), shacharit, hm(mincha), hm(today.sunset), hm(maariv), hm(today.tzeit)))
            v.setTextViewText(R.id.w_shabbat, Lf("🕯 {0}  ✨ {1}", rest?.first?.candleLighting?.let { SimpleDateFormat("EEE HH:mm", Locale.US).format(Date(it)) } ?: "—",
                rest?.second?.havdalah?.let { SimpleDateFormat("EEE HH:mm", Locale.US).format(Date(it)) } ?: "—"))
            val pi = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            v.setOnClickPendingIntent(R.id.widget_root, pi)
            return v
        }

        /** Refresh all placed widgets (called when the app opens or the city changes). */
        fun refresh(context: Context) {
            val m = AppWidgetManager.getInstance(context)
            val ids = m.getAppWidgetIds(ComponentName(context, ZmanimWidget::class.java))
            if (ids.isNotEmpty()) m.updateAppWidget(ids, build(context))
        }
    }
}
