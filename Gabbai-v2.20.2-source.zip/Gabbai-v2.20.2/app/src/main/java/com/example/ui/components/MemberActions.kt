package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemberEntity
import com.example.data.model.TransactionEntity
import com.example.ui.settings.*
import com.example.ui.share.Messages
import com.example.ui.share.Share
import com.example.ui.theme.*
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.util.Calendar

object MemberQr {
    const val PREFIX = "GABBAI-MEMBER:"
    fun payload(m: MemberEntity) = PREFIX + m.id
    fun parse(text: String?): Long? = text?.trim()?.takeIf { it.startsWith(PREFIX) }?.removePrefix(PREFIX)?.toLongOrNull()

    fun bitmap(content: String, size: Int = 640): Bitmap {
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (x in 0 until size) for (y in 0 until size) bmp.setPixel(x, y, if (matrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        return bmp
    }
}

/** One-tap actions on a member card: WhatsApp, SMS, call, greetings, reminders, certificate, QR. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MemberQuickActions(member: MemberEntity, transactions: List<TransactionEntity>) {
    val context = LocalContext.current
    val s = LocalAppSettings.current
    var qr by remember { mutableStateOf(false) }
    var cert by remember { mutableStateOf(false) }
    Spacer(Modifier.height(6.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.testTag("member_actions_${member.id}")) {
        if (member.phone.isNotBlank()) {
            SmallAction(Icons.Default.Call, L("დარეკვა")) { Share.call(context, member.phone) }
            SmallAction(Icons.Default.Chat, "WhatsApp") { Share.whatsapp(context, member.phone, Lf("შალომ, {0}!", member.fullName)) }
            if (member.birthDateMillis > 0) SmallAction(Icons.Default.Cake, L("მილოცვა")) { Share.whatsapp(context, member.phone, Messages.birthday(member.fullName, s.shulName())) }
            if (member.outstandingDebt > 0 || !member.duesPaid) SmallAction(Icons.Default.NotificationsActive, L("ვალის შეხსენება")) {
                Share.whatsapp(context, member.phone, Messages.nederReminder(member.fullName, if (member.outstandingDebt > 0) member.outstandingDebt else member.annualFeeAmount, member.currency, s.shulName()))
            }
            SmallAction(Icons.Default.Sms, "SMS") { Share.sms(context, member.phone, Lf("შალომ, {0}!", member.fullName)) }
        }
        SmallAction(Icons.Default.WorkspacePremium, L("წლიური ცნობა")) { cert = true }
        SmallAction(Icons.Default.QrCode2, L("QR ბარათი")) { qr = true }
    }
    if (qr) {
        val bmp = remember(member.id) { MemberQr.bitmap(MemberQr.payload(member)) }
        FormDialog(onDismissRequest = { qr = false },
            title = { Text(member.fullName, fontWeight = FontWeight.Bold) },
            text = { Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Image(bmp.asImageBitmap(), L("QR ბარათი"), modifier = Modifier.size(240.dp).background(Color.White))
                Text(L("სინაგოგაში მოსვლისას დაასკანერეთ — მაშინვე გაიხსნება წევრის პროფილი."), fontSize = 12.sp, color = CosmicTextSecondary)
            } },
            confirmButton = { Button(onClick = { Share.image(context, bmp, "member-qr-${member.id}", member.fullName + " — " + s.shulName()) }) { Text(L("გაზიარება")) } },
            dismissButton = { TextButton(onClick = { qr = false }) { Text(L("დახურვა")) } })
    }
    if (cert) {
        var year by remember { mutableStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
        val text = Messages.annualCertificate(member.fullName, year, transactions, s.shulName())
        FormDialog(onDismissRequest = { cert = false },
            title = { Text(L("შემოწირულობის წლიური ცნობა")) },
            text = { Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { year-- }) { Icon(Icons.Default.ChevronLeft, null) }
                    Text("$year", fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                    IconButton(onClick = { year++ }) { Icon(Icons.Default.ChevronRight, null) }
                }
                Text(nb(text), color = CosmicTextSecondary, fontSize = 13.sp)
            } },
            confirmButton = { Button(onClick = { if (member.phone.isNotBlank()) Share.whatsapp(context, member.phone, text) else Share.text(context, text) }) { Text(L("გაგზავნა")) } },
            dismissButton = { TextButton(onClick = { Share.text(context, text) }) { Text(L("გაზიარება")) } })
    }
}

@Composable
private fun SmallAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    AssistChip(onClick = onClick, label = { Text(label, fontSize = 12.sp, maxLines = 1) }, leadingIcon = { Icon(icon, null, Modifier.size(16.dp)) })
}
