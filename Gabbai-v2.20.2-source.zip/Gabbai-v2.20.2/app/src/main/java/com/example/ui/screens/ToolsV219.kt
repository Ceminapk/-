package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.*
import com.example.ui.calendar.*
import com.example.ui.components.CosmicGlassCard
import com.example.ui.settings.*
import com.example.ui.share.PdfMaker
import com.example.ui.share.Share
import com.example.ui.theme.*
import com.example.ui.viewmodel.GabbaiUiState
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private fun d9(t: Long) = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(t))
private fun hm9(t: Long?) = if (t == null) "—" else SimpleDateFormat("HH:mm", Locale.US).format(Date(t))
private const val DAY9 = 86_400_000L

@Composable
private fun Card9(icon: ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    CosmicGlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = CosmicCelestialGold); Spacer(Modifier.width(8.dp)); Text(title, fontWeight = FontWeight.Bold, color = CosmicTextPrimary) }
        Spacer(Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
    }
}

// ======================= Halacha prompter =======================

/** Daily prayer reminders for the gabbai. Months: 0 Tishrei … 5 Adar I, 6 Adar (II), 7 Nisan … 12 Elul. */
object HalachaRules {
    fun isRoshChodesh(h: HebDate) = h.day == 30 || (h.day == 1 && h.month != 0)

    fun isChanukah(h: HebDate) = (h.month == 2 && h.day >= 25) || (h.month == 3 && h.day <= 3 && !(h.day == 3 && false))

    fun isPurim(h: HebDate, israel: Boolean = false) = h.month == 6 && h.day == 14

    /** Days without Tachanun (Shacharit and Mincha). */
    fun noTachanun(h: HebDate, weekday: Int): Boolean {
        if (weekday == Calendar.SATURDAY) return true
        if (isRoshChodesh(h)) return true
        val (m, d) = h.month to h.day
        return when (m) {
            0 -> d <= 2 || d >= 9                // Rosh Hashana, Erev Yom Kippur … end of Tishrei
            2 -> d >= 25
            3 -> d <= 3
            4 -> d == 15                           // Tu BiShvat
            5 -> h.leap && (d == 14 || d == 15)    // Purim Katan
            6 -> d == 14 || d == 15
            7 -> true                              // all of Nisan
            8 -> d == 14 || d == 18                // Pesach Sheni, Lag BaOmer
            9 -> d <= 12
            11 -> d == 9 || d == 15
            12 -> d == 29
            else -> false
        }
    }

    /** Mashiv haRuach from Shemini Atzeret (22 Tishrei) until the first day of Pesach (15 Nisan). */
    fun mashivHaruach(h: HebDate): Boolean = when (h.month) {
        0 -> h.day >= 22
        in 1..6 -> true
        7 -> h.day < 15
        else -> false
    }

    /** Tal uMatar in the diaspora: from 4 December evening (5 December before a civil leap year) until Pesach. Israel: from 7 Cheshvan. */
    fun talUmatar(h: HebDate, gy: Int, gm: Int, gd: Int, israel: Boolean): Boolean {
        if (h.month == 7 && h.day >= 15 || h.month in 8..12) return false
        if (h.month == 7) return true
        if (h.month in 3..6) return true
        if (israel) return h.month == 2 || (h.month == 1 && h.day >= 7)
        val start = if ((gy + 1) % 4 == 0 && ((gy + 1) % 100 != 0 || (gy + 1) % 400 == 0)) 5 else 4
        return (gm == 12 && gd >= start) || gm in 1..3 || (h.month in 1..2 && gm == 12 && gd >= start)
    }

    fun yaaleVeyavo(h: HebDate, israel: Boolean): Boolean {
        if (isRoshChodesh(h)) return true
        return (h.month == 0 && h.day in 15..(if (israel) 22 else 23)) || (h.month == 7 && h.day in 15..(if (israel) 21 else 22)) ||
            (h.month == 9 && (h.day == 6 || (!israel && h.day == 7))) || (h.month == 0 && (h.day == 1 || h.day == 2))
    }

    /** Georgian source lines shown in the prompter. */
    fun prompts(h: HebDate, weekday: Int, gy: Int, gm: Int, gd: Int, israel: Boolean): List<String> = buildList {
        add(if (noTachanun(h, weekday)) "თახანუნი დღეს არ ითქმება" else "თახანუნი ითქმება")
        if (weekday == Calendar.SATURDAY) add(if (noTachanun(h, Calendar.MONDAY) && h.month != 7) "მინხაზე ციდკათხა არ ითქმება" else if (h.month == 7) "მინხაზე ციდკათხა არ ითქმება" else "მინხაზე ციდკათხა ითქმება")
        add(if (mashivHaruach(h)) "ამიდაში: მაშივ ჰარუახ უმორიდ ჰაგეშემ" else "ამიდაში: მორიდ ჰატალ (ნუსხის მიხედვით)")
        add(if (talUmatar(h, gy, gm, gd, israel)) "ბარეხ ალეინუ: ვეთენ ტალ უმატარ ლივრახა" else "ბარეხ ალეინუ: ვეთენ ბრახა")
        if (yaaleVeyavo(h, israel)) add("იაალე ვეიავო ითქმება")
        if (isRoshChodesh(h)) add("როშ ხოდეში: ჰალელი (ნაწილობრივი) და მუსაფი")
        if (isChanukah(h)) add("ხანუქა: ალ ჰანისიმ და სრული ჰალელი")
        if (isPurim(h)) add("პურიმი: ალ ჰანისიმ და მეგილას კითხვა")
        if (h.month == 12) add("ელული: შოფარი შახარითის შემდეგ და ლედავიდ ჰ' ორი")
        if (h.month == 0 && h.day in 3..9) add("ასერეთ იემეი თეშუვა: ჰამელეხ ჰაკადოშ და ზოხრენუ")
        if (weekday == Calendar.MONDAY || weekday == Calendar.THURSDAY) add("ორშაბათი / ხუთშაბათი: თორის კითხვა შახარითზე")
    }
}

@Composable
fun HalachaPrompterTool() {
    val c = remember { Calendar.getInstance() }
    val city = CalendarPrefs.city
    val info = remember(city) { JewishCalendar.day(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), city) }
    val lines = remember(info) { HalachaRules.prompts(info.heb, info.weekday, info.y, info.m, info.d, city.israel) }
    Card9(Icons.Default.Lightbulb, L("ჰალახური მინიშნებები დღევანდელი ლოცვისთვის")) {
        Text(JewishCalendar.hebrewDateHe(info.heb), color = CosmicCelestialGold, fontWeight = FontWeight.Bold)
        lines.forEach { Text("• " + L(it), color = CosmicTextPrimary, fontSize = 14.sp, modifier = Modifier.testTag("halacha_line")) }
        Text(L("მინიშნება ზოგადია — საეჭვო შემთხვევაში ჰკითხეთ რავს."), color = CosmicTextMuted, fontSize = 11.sp)
    }
}

// ======================= SOS =======================

@Composable
fun SosKioskRow(onSos: () -> Unit, onKiosk: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(onClick = onSos, colors = ButtonDefaults.buttonColors(containerColor = CosmicAlertRose, contentColor = Color.White),
            shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f).height(48.dp).testTag("btn_sos")) {
            Icon(Icons.Default.Sos, null); Spacer(Modifier.width(6.dp)); Text(L("SOS — საგანგებო"), fontWeight = FontWeight.Bold, maxLines = 1)
        }
        OutlinedButton(onClick = onKiosk, shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f).height(48.dp).testTag("btn_kiosk")) {
            Icon(Icons.Default.Tv, null); Spacer(Modifier.width(6.dp)); Text(L("კედლის ეკრანი"), maxLines = 1)
        }
    }
}

object SosNumbers {
    /** Georgia uses the single number 112; Israel keeps separate services. */
    fun services(israel: Boolean): List<Pair<String, String>> = if (israel)
        listOf("სასწრაფო დახმარება (מד״א)" to "101", "პოლიცია" to "100", "სახანძრო" to "102")
    else listOf("სასწრაფო დახმარება" to "112", "პოლიცია" to "112", "სახანძრო-სამაშველო" to "112")
}

@Composable
fun SosDialog(state: GabbaiUiState, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val israel = CalendarPrefs.city.israel
    val contacts = state.registry.filter { it.kind == RegistryKind.EMERGENCY.name && it.status == RegistryStatus.OPEN && it.phone.isNotBlank() }
    AlertDialog(onDismissRequest = onDismiss, modifier = Modifier.testTag("sos_dialog"),
        icon = { Icon(Icons.Default.Sos, null, tint = CosmicAlertRose, modifier = Modifier.size(40.dp)) },
        title = { Text(L("საგანგებო გამოძახება"), fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { Share.call(ctx, if (israel) "101" else "112") }, colors = ButtonDefaults.buttonColors(containerColor = CosmicAlertRose, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth().height(56.dp).testTag("sos_main")) {
                    Icon(Icons.Default.Call, null); Spacer(Modifier.width(8.dp)); Text(if (israel) "101" else "112", fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                SosNumbers.services(israel).forEach { (name, num) ->
                    OutlinedButton(onClick = { Share.call(ctx, num) }, modifier = Modifier.fillMaxWidth()) { Text("${L(name)} — $num", maxLines = 1) }
                }
                if (contacts.isNotEmpty()) Text(L("სინაგოგის საგანგებო კონტაქტები"), fontWeight = FontWeight.Bold, color = CosmicTextPrimary)
                contacts.forEach { e ->
                    OutlinedButton(onClick = { Share.call(ctx, e.phone) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Phone, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("${nb(e.title)} — ${e.phone}", maxLines = 1) }
                }
                if (contacts.isEmpty()) Text(L("საკუთარი ნომრები (რაბინი, დაცვა, ხევრა კადიშა) დაამატეთ ჟურნალში „საგანგებო კონტაქტები“."), color = CosmicTextMuted, fontSize = 12.sp)
                FilledTonalButton(onClick = { Share.text(ctx, L("🚨 სასწრაფოდ! სინაგოგაში საგანგებო სიტუაციაა, გთხოვთ დაუყოვნებლივ დაგვიკავშირდეთ.")) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Campaign, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(L("განგაშის შეტყობინება ჯგუფში"))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(L("დახურვა")) } })
}

// ======================= Kiosk / wall display =======================

@Composable
fun KioskLauncherTool(state: GabbaiUiState) {
    var open by remember { mutableStateOf(false) }
    val settings = LocalAppSettings.current
    Card9(Icons.Default.Tv, L("სინაგოგის კედლის / ტაბლეტის ეკრანი")) {
        Text(L("სრული ეკრანი: საათი, დღის დროები, ფარაშა, დღევანდელი იორცაიტები და კიდუშის სპონსორები."), color = CosmicTextSecondary, fontSize = 13.sp)
        Button(onClick = { open = true }, modifier = Modifier.testTag("btn_open_kiosk")) { Icon(Icons.Default.Fullscreen, null); Spacer(Modifier.width(6.dp)); Text(L("გახსნა")) }
    }
    if (open) KioskDialog(state, settings) { open = false }
}

@Composable
fun KioskDialog(state: GabbaiUiState, settings: AppSettings, onDismiss: () -> Unit) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(1000); now = System.currentTimeMillis() } }
    val city = CalendarPrefs.city
    val c = remember(now / DAY9) { Calendar.getInstance() }
    val info = remember(now / DAY9, city) { JewishCalendar.day(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), city) }
    val yahrzeits = remember(state.yahrzeits, now / DAY9) { YahrzeitTools.within(state.yahrzeits, 0) }
    val sponsors = state.registry.filter { it.kind == RegistryKind.KIDDUSH_CAL.name && it.dueMillis in (now - DAY9)..(now + 7 * DAY9) }
    val parasha = state.registry.filter { it.kind == RegistryKind.ALIYAH_PLAN.name && it.extra.isNotBlank() && it.dueMillis >= now - DAY9 }.minByOrNull { it.dueMillis }?.extra
    val flicker by rememberInfiniteTransition(label = "candle").animateFloat(0.85f, 1.12f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "f")
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(Color(0xFF0B1A14)).clickable(onClick = onDismiss).testTag("kiosk_screen")) {
            Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(settings.shulName(), color = Color(0xFFE8C77A), fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(now)), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Black)
                Text(JewishCalendar.hebrewDateHe(info.heb), color = Color(0xFFE8C77A), fontSize = 24.sp)
                info.holidays.forEach { Text(L(it.ka) + " • " + it.he, color = Color.White, fontSize = 18.sp) }
                parasha?.let { Text(Lf("კვირის ფარაშა: {0}", it), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
                KioskBlock(L("დღის დროები")) {
                    listOf(L("ალოთ ჰაშახარი") to info.alot, L("ნეც — მზის ამოსვლა") to info.sunrise, L("სოფ ზმან კრიათ შემა") to info.sofShema,
                        L("ხაცოთ") to info.chatzot, L("მინხა გედოლა") to info.minchaGedola, L("მზის ჩასვლა") to info.sunset, L("ცეეთ ჰაკოხავიმ") to info.tzeit)
                        .forEach { (n, t) -> KioskRow(n, hm9(t)) }
                    info.candleLighting?.let { KioskRow(L("🕯️ სანთლის ანთება"), hm9(it)) }
                    info.havdalah?.let { KioskRow(L("ჰავდალა"), hm9(it)) }
                }
                if (yahrzeits.isNotEmpty()) KioskBlock(L("დღევანდელი იორცაიტები")) {
                    yahrzeits.forEach { y ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🕯️", fontSize = 26.sp, modifier = Modifier.scale(flicker))
                            Spacer(Modifier.width(8.dp)); Text(nb(y.item.deceasedName + " ז״ל"), color = Color.White, fontSize = 20.sp)
                        }
                    }
                }
                if (sponsors.isNotEmpty()) KioskBlock(L("კიდუშის სპონსორები")) {
                    sponsors.forEach { Text(nb("${it.memberName} — ${it.title}"), color = Color.White, fontSize = 18.sp) }
                }
                Text(L("დასახურად შეეხეთ ეკრანს"), color = Color(0x88FFFFFF), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun KioskBlock(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color(0x22FFFFFF)).border(1.dp, Color(0x55E8C77A), RoundedCornerShape(22.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, color = Color(0xFFE8C77A), fontSize = 18.sp, fontWeight = FontWeight.Bold); content()
    }
}

@Composable
private fun KioskRow(name: String, value: String) {
    Row(Modifier.fillMaxWidth()) { Text(name, color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f)); Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
}

// ======================= Seat map =======================

object SeatMap {
    /** "3-12", "3/12" or "რიგი 3, ადგილი 12" → (row 3, seat 12). */
    fun parse(s: String): Pair<Int, Int>? {
        val n = Regex("\\d+").findAll(s).map { it.value.toInt() }.toList()
        return if (n.size >= 2 && n[0] in 1..60 && n[1] in 1..60) n[0] to n[1] else null
    }
}

@Composable
fun SeatMapTool(state: GabbaiUiState) {
    val seats = state.registry.filter { it.kind == RegistryKind.SEATING.name }
    val halls = (seats.map { it.extra.ifBlank { "მამაკაცთა დარბაზი" } } + "მამაკაცთა დარბაზი").distinct()
    var hall by remember { mutableStateOf(halls.first()) }
    var picked by remember { mutableStateOf<RegistryEntity?>(null) }
    Card9(Icons.Default.Chair, L("დარბაზის ადგილების ვიზუალური რუკა")) {
        com.example.ui.components.AppDropdown(label = L("დარბაზი"), value = hall, options = halls, optionLabel = { L(it) }, onSelected = { hall = it })
        val inHall = seats.filter { it.extra.ifBlank { "მამაკაცთა დარბაზი" } == hall }.mapNotNull { e -> SeatMap.parse(e.title)?.let { it to e } }.toMap()
        val rows = (inHall.keys.maxOfOrNull { it.first } ?: 4).coerceAtLeast(4)
        val cols = (inHall.keys.maxOfOrNull { it.second } ?: 8).coerceIn(4, 14)
        Text(L("ბიმა / ჰეხალი"), color = CosmicCelestialGold, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        (1..rows).forEach { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("$r", color = CosmicTextMuted, fontSize = 10.sp, modifier = Modifier.width(16.dp))
                (1..cols).forEach { s ->
                    val e = inHall[r to s]
                    val color = when { e == null -> CosmicTextMuted.copy(alpha = .25f); e.status == RegistryStatus.DONE -> CosmicEmeraldSuccess; else -> CosmicCelestialGold }
                    Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(5.dp)).background(color).clickable(enabled = e != null) { picked = e })
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Legend(CosmicEmeraldSuccess, L("დაკავებულია")); Legend(CosmicCelestialGold, L("თავისუფალია")); Legend(CosmicTextMuted.copy(alpha = .25f), L("არ არის ჩაწერილი"))
        }
        Text(L("ადგილები ემატება ჟურნალში „სინაგოგის ადგილების რუკა“ (მაგ. 3-12 = მე-3 რიგი, მე-12 ადგილი)."), color = CosmicTextMuted, fontSize = 11.sp)
        picked?.let { e -> Text(nb("${e.title}: ${e.memberName.ifBlank { L("თავისუფალია") }}" + if (e.amount > 0) " • " + money(e.amount, e.currency) else ""), color = CosmicTextPrimary, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun Legend(c: Color, t: String) {
    Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(10.dp).clip(CircleShape).background(c)); Spacer(Modifier.width(4.dp)); Text(t, color = CosmicTextSecondary, fontSize = 11.sp) }
}

// ======================= Aliyah fairness =======================

object AliyahFairness {
    /** Living members ordered by the longest wait since their last aliyah (never = first). */
    fun ranking(members: List<MemberEntity>, aliyot: List<AliyahEntity>, now: Long = System.currentTimeMillis()): List<Pair<MemberEntity, Long?>> =
        members.filter { it.status != MemberStatus.DECEASED }.map { m -> m to aliyot.filter { it.winnerName.equals(m.fullName, true) && it.dateMillis <= now }.maxOfOrNull { it.dateMillis } }
            .sortedWith(compareBy<Pair<MemberEntity, Long?>> { it.second ?: Long.MIN_VALUE }.thenBy { it.first.fullName })
}

@Composable
fun AliyahFairnessTool(state: GabbaiUiState) {
    val ranking = remember(state.members, state.aliyot) { AliyahFairness.ranking(state.members, state.aliyot) }
    var all by remember { mutableStateOf(false) }
    val now = System.currentTimeMillis()
    Card9(Icons.Default.Balance, L("სამართლიანი ალიების ისტორია")) {
        Text(L("სიის თავში არიან ისინი, ვინც ყველაზე დიდი ხანია თორასთან არ ასულა."), color = CosmicTextSecondary, fontSize = 12.sp)
        if (ranking.isEmpty()) Text(L("ჩანაწერი არ არის"), color = CosmicTextMuted)
        (if (all) ranking else ranking.take(8)).forEach { (m, last) ->
            val txt = if (last == null) L("ალია ჯერ არ ჰქონია") else Lf("ბოლო ალია: {0} ({1} დღის წინ)", d9(last), (now - last) / DAY9)
            Row { Text(nb(m.fullName), color = CosmicTextPrimary, fontSize = 13.sp, modifier = Modifier.weight(1f)); Text(txt, color = if (last == null || now - last > 60 * DAY9) CosmicAlertRose else CosmicTextSecondary, fontSize = 12.sp) }
        }
        if (ranking.size > 8) TextButton(onClick = { all = !all }) { Text(if (all) L("ნაკლები") else L("ყველას ნახვა")) }
    }
}

// ======================= WhatsApp receipt =======================

object Receipts {
    fun text(t: TransactionEntity, shul: String): String = buildString {
        appendLine("🧾 " + L("შემოწირულობის ქვითარი") + " № " + t.id.toString().padStart(5, '0'))
        appendLine(L("თარიღი") + ": " + d9(t.dateMillis))
        if (t.memberName.isNotBlank()) appendLine(L("შემომწირველი") + ": " + t.memberName)
        appendLine(L("მიზანი") + ": " + t.title)
        appendLine(L("თანხა") + ": " + money(t.amount, t.currency))
        appendLine()
        appendLine(L("თოდა რაბა! დაე, ღმერთმა გიკურთხოთ ყველაფერი."))
        append(shul)
    }
}

@Composable
fun WhatsappReceiptTool(state: GabbaiUiState) {
    val ctx = LocalContext.current
    val settings = LocalAppSettings.current
    val incomes = state.transactions.filter { it.type == TransactionType.INCOME }.sortedByDescending { it.dateMillis }.take(10)
    Card9(Icons.Default.Chat, L("ქვითარი 1 დაჭერით WhatsApp-ში")) {
        if (incomes.isEmpty()) Text(L("ჩანაწერი არ არის"), color = CosmicTextMuted)
        incomes.forEach { t ->
            val phone = state.members.firstOrNull { it.fullName.equals(t.memberName, true) }?.phone.orEmpty()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(nb("${d9(t.dateMillis)} • ${t.memberName.ifBlank { t.title }} • ${money(t.amount, t.currency)}"), color = CosmicTextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { val txt = Receipts.text(t, settings.shulName()); if (phone.isNotBlank()) Share.whatsapp(ctx, phone, txt) else Share.text(ctx, txt) }) {
                    Icon(Icons.Default.Send, L("გაგზავნა"), tint = CosmicEmeraldSuccess)
                }
            }
        }
    }
}

// ======================= Board monthly report =======================

object BoardReport {
    fun inMonth(t: Long, y: Int, m: Int): Boolean { val c = Calendar.getInstance().apply { timeInMillis = t }; return c.get(Calendar.YEAR) == y && c.get(Calendar.MONTH) == m }

    fun lines(state: GabbaiUiState, y: Int, m: Int): List<String> = buildList {
        val tx = state.transactions.filter { inMonth(it.dateMillis, y, m) }
        tx.groupBy { it.currency }.forEach { (cur, l) ->
            val inc = l.filter { it.type == TransactionType.INCOME }; val exp = l.filter { it.type == TransactionType.EXPENSE }
            add("— $cur —")
            add(L("შემოსავალი") + ": " + money(inc.sumOf { it.amount }, cur))
            inc.groupBy { it.category }.forEach { (c, g) -> add("   • " + c.titleKa + ": " + money(g.sumOf { it.amount }, cur)) }
            add(L("ხარჯი") + ": " + money(exp.sumOf { it.amount }, cur))
            exp.groupBy { it.category }.forEach { (c, g) -> add("   • " + c.titleKa + ": " + money(g.sumOf { it.amount }, cur)) }
            add(L("ნაშთი") + ": " + money(inc.sumOf { it.amount } - exp.sumOf { it.amount }, cur))
            add("")
        }
        if (tx.isEmpty()) add(L("ამ თვეში ფინანსური ჩანაწერი არ არის."))
        val debtors = state.members.filter { it.outstandingDebt > 0 }
        add(L("დავალიანებები") + ": " + debtors.size)
        debtors.groupBy { it.currency }.forEach { (cur, l) -> add("   " + money(l.sumOf { it.outstandingDebt }, cur)) }
    }
}

@Composable
fun BoardMonthlyReportTool(state: GabbaiUiState) {
    val ctx = LocalContext.current
    val settings = LocalAppSettings.current
    val c = remember { Calendar.getInstance() }
    var offset by remember { mutableStateOf(0) }
    val mc = remember(offset) { (c.clone() as Calendar).apply { add(Calendar.MONTH, -offset) } }
    val label = SimpleDateFormat("MM.yyyy", Locale.US).format(mc.time)
    Card9(Icons.Default.PictureAsPdf, L("გამგეობის ყოველთვიური PDF ანგარიში")) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { offset++ }) { Icon(Icons.Default.ChevronLeft, L("წინა თვე")) }
            Text(label, color = CosmicTextPrimary, fontWeight = FontWeight.Bold)
            IconButton(onClick = { if (offset > 0) offset-- }) { Icon(Icons.Default.ChevronRight, L("შემდეგი თვე")) }
        }
        Button(onClick = {
            val doc = PdfMaker.Doc(settings.shulName(), L("გამგეობის ფინანსური ანგარიში") + " — " + label, BoardReport.lines(state, mc.get(Calendar.YEAR), mc.get(Calendar.MONTH)), seal = settings.shulName())
            PdfMaker.share(ctx, PdfMaker.build(ctx, "board_$label".replace('.', '_'), doc), L("გამგეობის ფინანსური ანგარიში"))
        }, modifier = Modifier.testTag("btn_board_pdf")) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text(L("PDF-ის შექმნა და გაზიარება")) }
    }
}

// ======================= Journal summaries (2.19) =======================

@Composable
fun V219Summary(kind: RegistryKind, rows: List<RegistryEntity>, s: AppSettings) {
    val ctx = LocalContext.current
    when (kind) {
        RegistryKind.TORAH_PASSPORT -> if (rows.isNotEmpty()) {
            Text(L("სეფერ თორების რადარი — სად არის გადახვეული:"), color = CosmicCelestialGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            rows.forEach { Text(nb("📜 ${it.title} → ${it.extra.ifBlank { L("უცნობია") }}"), color = CosmicTextPrimary, fontSize = 13.sp) }
        }
        RegistryKind.MEZUZAH -> {
            val due = V219Rules.mezuzahDueSoon(rows)
            if (due.isNotEmpty()) {
                Text(Lf("⚠ 30 დღეში შესამოწმებელია: {0}", due.size), color = CosmicAlertRose, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                OutlinedButton(onClick = { Share.text(ctx, L("სოფერისთვის შესამოწმებელი სია:") + "\n" + due.joinToString("\n") { "• ${it.memberName} — ${it.title} (${d9(it.dueMillis)}) ${it.phone}" } + "\n" + s.shulName()) }) {
                    Text(L("სოფერისთვის სიის გაგზავნა"))
                }
            }
        }
        RegistryKind.BAR_MITZVAH -> rows.map { it.memberName }.filter { it.isNotBlank() }.distinct().forEach { boy ->
            val (done, all) = V219Rules.barMitzvahProgress(rows, boy)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(nb("$boy: $done / $all"), color = CosmicTextPrimary, fontSize = 13.sp, modifier = Modifier.weight(1f))
                LinearProgressIndicator(progress = { if (all == 0) 0f else done.toFloat() / all }, modifier = Modifier.width(80.dp), color = CosmicEmeraldSuccess)
                IconButton(onClick = {
                    val steps = rows.filter { it.memberName.equals(boy, true) }.joinToString("\n") { (if (it.status == RegistryStatus.DONE) "✅ " else "⬜ ") + it.title }
                    Share.text(ctx, Lf("ბარ-მიცვას მომზადება — {0}: {1} / {2}", boy, done, all) + "\n" + steps + "\n" + s.shulName())
                }) { Icon(Icons.Default.Share, L("მშობლებისთვის გაგზავნა")) }
            }
        }
        RegistryKind.HONOR_WALL -> if (rows.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x33E8C77A)).padding(10.dp)) {
                rows.groupBy { it.extra.ifBlank { L("სპონსორები") } }.forEach { (lvl, l) ->
                    Text(nb(lvl), color = CosmicCelestialGold, fontWeight = FontWeight.Bold)
                    l.forEach { Text(nb("✦ ${it.memberName.ifBlank { it.title }}" + if (it.memberName.isNotBlank()) " — ${it.title}" else ""), color = CosmicTextPrimary, fontSize = 13.sp) }
                }
            }
        }
        RegistryKind.HALL_BOOKING -> {
            val n = V219Rules.hallConflicts(rows.filter { it.status == RegistryStatus.OPEN }).size
            if (n > 0) Text(Lf("⚠ ორმაგი ჯავშანი: {0} ჩანაწერი ემთხვევა დღითა და სლოტით", n), color = CosmicAlertRose, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        RegistryKind.MIKVEH_APPT -> Text(L("კონფიდენციალურია: სახელი არ იწერება — მხოლოდ ჯავშნის კოდი და დრო."), color = CosmicTextMuted, fontSize = 12.sp)
        RegistryKind.SYNAGOGUE_DIR -> Text(L("მისამართები, ტელეფონები და რაბინების სახელები შეავსეთ და გადაამოწმეთ — აპი მათ არ იგონებს."), color = CosmicTextMuted, fontSize = 12.sp)
        else -> {}
    }
}

// ======================= Memorial prayers =======================

object MemorialTexts {
    const val kaddishHe = "יתגדל ויתקדש שמה רבא. בעלמא די ברא כרעותה, וימליך מלכותה, בחייכון וביומיכון ובחיי דכל בית ישראל, בעגלא ובזמן קריב, ואמרו אמן.\n" +
        "יהא שמה רבא מברך לעלם ולעלמי עלמיא.\n" +
        "יתברך וישתבח ויתפאר ויתרומם ויתנשא ויתהדר ויתעלה ויתהלל שמה דקודשא בריך הוא, לעלא מן כל ברכתא ושירתא, תושבחתא ונחמתא, דאמירן בעלמא, ואמרו אמן.\n" +
        "יהא שלמא רבא מן שמיא וחיים עלינו ועל כל ישראל, ואמרו אמן.\n" +
        "עושה שלום במרומיו הוא יעשה שלום עלינו ועל כל ישראל, ואמרו אמן."
    const val kaddishKa = "იითგადალ ვეიითქადაშ შმეჰ რაბა. ბეალმა დი ვრა ხირუთეჰ, ვეიამლიხ მალხუთეჰ, ბეხაიეხონ უვიომეიხონ უვხაიე დეხოლ ბეით ისრაელ, ბაგალა უვიზმან ქარივ, ვეიმრუ ამენ.\n" +
        "იეჰე შმეჰ რაბა მევარახ ლეალამ ულალმეი ალმაია.\n" +
        "იითბარახ ვეიიშთაბახ ვეიითფაარ ვეიითრომამ ვეიითნასე ვეიითჰადარ ვეიითალე ვეიითჰალალ შმეჰ დეკუდშა ბრიხ ჰუ, ლეელა მინ ქოლ ბირხათა ვეშირათა, თუშბეხათა ვენეხემათა, დაამირან ბეალმა, ვეიმრუ ამენ.\n" +
        "იეჰე შლამა რაბა მინ შმაია ვეხაიიმ ალეინუ ვეალ ქოლ ისრაელ, ვეიმრუ ამენ.\n" +
        "ოსე შალომ ბიმრომავ ჰუ იაასე შალომ ალეინუ ვეალ ქოლ ისრაელ, ვეიმრუ ამენ."
    const val elMaleHe = "אל מלא רחמים, שוכן במרומים, המצא מנוחה נכונה על כנפי השכינה, במעלות קדושים וטהורים כזוהר הרקיע מזהירים, את נשמת ______ בן/בת ______ שהלך/שהלכה לעולמו/לעולמה, בעבור שנודבים צדקה בעד הזכרת נשמתו/נשמתה, בגן עדן תהא מנוחתו/מנוחתה. לכן בעל הרחמים יסתירהו/יסתירה בסתר כנפיו לעולמים, ויצרור בצרור החיים את נשמתו/נשמתה, ה׳ הוא נחלתו/נחלתה, וינוח/ותנוח בשלום על משכבו/משכבה, ונאמר אמן."
}

@Composable
fun MemorialPrayersDialog(onDismiss: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    AlertDialog(onDismissRequest = onDismiss, modifier = Modifier.testTag("memorial_prayers"),
        title = { Text(L("ლოცვები საფლავთან"), fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(tab == 0, { tab = 0 }, label = { Text(L("კადიში (ივრითი)")) })
                    FilterChip(tab == 1, { tab = 1 }, label = { Text(L("ტრანსკრიფცია")) })
                    FilterChip(tab == 2, { tab = 2 }, label = { Text("אל מלא") })
                }
                val txt = when (tab) { 0 -> MemorialTexts.kaddishHe; 1 -> MemorialTexts.kaddishKa; else -> MemorialTexts.elMaleHe }
                Text(txt, color = CosmicTextPrimary, fontSize = if (tab == 1) 15.sp else 19.sp, lineHeight = 28.sp, textAlign = if (tab == 1) TextAlign.Start else TextAlign.End, modifier = Modifier.fillMaxWidth())
                Text(L("კადიში ითქმება მხოლოდ მინიანის (10 კაცის) თანდასწრებით."), color = CosmicTextMuted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(L("დახურვა")) } })
}
