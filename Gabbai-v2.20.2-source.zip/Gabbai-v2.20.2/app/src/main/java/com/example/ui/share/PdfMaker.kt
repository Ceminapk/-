package com.example.ui.share

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.example.ui.settings.L
import java.io.File

/** Elegant A5 documents (receipt, certificate, report, bimah sheet) drawn with the built-in PdfDocument. */
object PdfMaker {
    private const val W = 420
    private const val H = 595
    private val green = Color.rgb(12, 59, 46)
    private val gold = Color.rgb(180, 102, 23)

    data class Doc(val title: String, val subtitle: String, val lines: List<String>, val blessing: String = "", val seal: String = "")

    fun build(context: Context, name: String, doc: Doc): File {
        val pdf = PdfDocument()
        var pageNo = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
        var c = page.canvas
        var y = header(c, doc)
        val body = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = Color.rgb(30, 40, 35) }
        for (line in doc.lines) {
            val l = layout(line.ifBlank { " " }, body, W - 70)
            if (y + l.height > H - 110) {
                pdf.finishPage(page); pageNo++
                page = pdf.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create()); c = page.canvas
                frame(c); y = 40f
            }
            c.save(); c.translate(35f, y); l.draw(c); c.restore(); y += l.height + 3
        }
        footer(c, doc)
        pdf.finishPage(page)
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val f = File(dir, name.replace(Regex("[^\\p{L}\\d_-]+"), "_") + ".pdf")
        f.outputStream().use { pdf.writeTo(it) }
        pdf.close()
        return f
    }

    fun share(context: Context, file: File, caption: String) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val i = Intent(Intent.ACTION_SEND).setType("application/pdf").putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_TEXT, caption)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try { context.startActivity(Intent.createChooser(i, L("გაზიარება")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { android.widget.Toast.makeText(context, L("შესაბამისი აპლიკაცია ვერ მოიძებნა"), android.widget.Toast.LENGTH_SHORT).show() }
    }

    private fun layout(text: String, p: TextPaint, width: Int, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL) =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width).setAlignment(align).setLineSpacing(2f, 1f).build()

    private fun frame(c: Canvas) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = gold; strokeWidth = 2f }
        c.drawRoundRect(RectF(14f, 14f, W - 14f, H - 14f), 18f, 18f, p)
        p.strokeWidth = 0.7f; p.color = green
        c.drawRoundRect(RectF(20f, 20f, W - 20f, H - 20f), 14f, 14f, p)
    }

    private fun header(c: Canvas, d: Doc): Float {
        frame(c)
        val band = Paint().apply { color = green }
        c.drawRoundRect(RectF(20f, 20f, W - 20f, 96f), 14f, 14f, band)
        val star = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 186, 0); textSize = 26f; textAlign = Paint.Align.CENTER }
        c.drawText("✡", W / 2f, 50f, star)
        val t = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 15f; typeface = Typeface.DEFAULT_BOLD }
        val tl = layout(d.title, t, W - 60, Layout.Alignment.ALIGN_CENTER)
        c.save(); c.translate(30f, 56f); tl.draw(c); c.restore()
        val s = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = gold; textSize = 11f }
        val sl = layout(d.subtitle, s, W - 60, Layout.Alignment.ALIGN_CENTER)
        c.save(); c.translate(30f, 104f); sl.draw(c); c.restore()
        return 112f + sl.height
    }

    private fun footer(c: Canvas, d: Doc) {
        if (d.blessing.isNotBlank()) {
            val b = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = green; textSize = 11f; typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC) }
            val bl = layout(d.blessing, b, W - 170, Layout.Alignment.ALIGN_CENTER)
            c.save(); c.translate(35f, H - 95f); bl.draw(c); c.restore()
        }
        if (d.seal.isNotBlank()) {
            val cx = W - 75f; val cy = H - 70f
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = gold; strokeWidth = 2f }
            c.drawCircle(cx, cy, 40f, p); p.strokeWidth = 0.8f; c.drawCircle(cx, cy, 34f, p)
            val st = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = gold; textSize = 8f; typeface = Typeface.DEFAULT_BOLD }
            val sl = layout(d.seal + "\n✡", st, 60, Layout.Alignment.ALIGN_CENTER)
            c.save(); c.translate(cx - 30f, cy - sl.height / 2f); sl.draw(c); c.restore()
        }
    }
}
