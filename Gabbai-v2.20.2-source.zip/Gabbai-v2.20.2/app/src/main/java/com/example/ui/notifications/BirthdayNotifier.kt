package com.example.ui.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.model.MemberEntity
import com.example.ui.calendar.BirthdayTools
import com.example.ui.settings.L
import com.example.ui.settings.Lf

object BirthdayNotifier {
    private const val CHANNEL = "birthday_reminders"

    fun notifyUpcoming(context: Context, members: List<MemberEntity>, leadDays: Int) {
        val upcoming = BirthdayTools.within(members, leadDays)
        if (upcoming.isEmpty()) return
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, L("დაბადების დღის შეხსენებები"), NotificationManager.IMPORTANCE_DEFAULT)
        )
        val text = upcoming.joinToString("\n") {
            if (it.daysUntil == 0) Lf("{0} — დღეს! ({1} წელი)", it.member.fullName, it.turningAge)
            else Lf("{0} — {1} დღეში ({2} წელი)", it.member.fullName, it.daysUntil, it.turningAge)
        }
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(L("მოახლოებული დაბადების დღე"))
            .setContentText(text.lineSequence().first()).setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true).build()
        NotificationManagerCompat.from(context).notify(2702, n)
    }
}
