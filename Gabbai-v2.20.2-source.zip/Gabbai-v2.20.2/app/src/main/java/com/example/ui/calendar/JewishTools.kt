package com.example.ui.calendar

import java.util.Calendar
import java.util.GregorianCalendar

/** Halachic date calculators that build on [JewishCalendar] (pure logic, no UI). */
object JewishTools {
    private const val DAY = 86_400_000L

    // ---------- Molad / Kiddush Levana ----------
    private const val PARTS_PER_HOUR = 1080L
    private const val PARTS_PER_DAY = 24 * PARTS_PER_HOUR
    private const val MONTH_PARTS = 29 * PARTS_PER_DAY + 12 * PARTS_PER_HOUR + 793

    /** Months from creation up to the start of Hebrew year [hy]. */
    fun monthsBeforeYear(hy: Int): Long = (235L * hy - 234L).floorDiv(19L)

    /**
     * Molad (mean conjunction) of the Hebrew month, in UTC millis, using Jerusalem standard time (UTC+2).
     * [month] uses ICU numbering (0 = Tishrei … 12 = Elul); in a non-leap year month 5 (Adar I) does not exist.
     */
    fun molad(hy: Int, month: Int): Long {
        val leap = JewishCalendar.isLeap(hy)
        val idx = if (!leap && month > 5) month - 1 else month
        // Molad BaHaRaD: 5 hours 204 parts after 6 pm on the eve of Monday, 1 Tishrei AM 1 (JD 347997.25).
        val parts = (monthsBeforeYear(hy) + idx) * MONTH_PARTS + 5 * PARTS_PER_HOUR + 204
        val jd = 347997.25 + parts.toDouble() / PARTS_PER_DAY
        return ((jd - 2440587.5) * DAY).toLong() - 2 * 3_600_000L
    }

    data class Window(val start: Long, val end: Long)

    /** Kiddush Levana: from 7 days after the molad (Sephardi custom; some say 3) until 15 days after it. */
    fun kiddushLevana(hy: Int, month: Int, fromDays: Int = 7): Window {
        val m = molad(hy, month)
        return Window(m + fromDays * DAY, m + 15 * DAY + (18 * 3_600_000L) + (22 * 60_000L))
    }

    // ---------- Gregorian helpers ----------
    fun dayStart(millis: Long): Long = Calendar.getInstance().apply {
        timeInMillis = millis; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun plusDays(millis: Long, days: Int): Long = Calendar.getInstance().apply { timeInMillis = millis; add(Calendar.DAY_OF_MONTH, days) }.timeInMillis
    fun weekday(millis: Long): Int = Calendar.getInstance().apply { timeInMillis = millis }.get(Calendar.DAY_OF_WEEK)
    private fun ymd(millis: Long): Triple<Int, Int, Int> { val c = Calendar.getInstance().apply { timeInMillis = millis }; return Triple(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)) }

    /** Gregorian day (local midnight) on which the given Hebrew date falls. */
    fun gregorianOf(hy: Int, month: Int, day: Int): Long {
        val h = android.icu.util.HebrewCalendar(hy, month, 1)
        val max = h.getActualMaximum(android.icu.util.Calendar.DAY_OF_MONTH)
        val c = android.icu.util.HebrewCalendar(hy, month, day.coerceAtMost(max))
        if (day > max) c.add(android.icu.util.Calendar.DAY_OF_MONTH, 1)
        val g = GregorianCalendar().apply { timeInMillis = c.timeInMillis }
        return GregorianCalendar(g.get(Calendar.YEAR), g.get(Calendar.MONTH), g.get(Calendar.DAY_OF_MONTH)).timeInMillis
    }

    /** Hebrew date of a birth, moving to the next day if born after sunset. */
    fun hebrewBirth(birthMillis: Long, afterSunset: Boolean): HebDate {
        val (y, m, d) = ymd(if (afterSunset) plusDays(birthMillis, 1) else birthMillis)
        return JewishCalendar.toHebrew(y, m, d)
    }

    // ---------- Bar / Bat Mitzvah ----------
    data class MitzvahDate(val dateMillis: Long, val heb: HebDate, val shabbatMillis: Long)

    /** Bar mitzvah at 13 (boys) / bat mitzvah at 12 (girls) on the Hebrew birthday; Adar of a plain year becomes Adar II in a leap year. */
    fun barMitzvah(birthMillis: Long, afterSunset: Boolean, girl: Boolean = false): MitzvahDate {
        val b = hebrewBirth(birthMillis, afterSunset)
        val ty = b.year + if (girl) 12 else 13
        val tLeap = JewishCalendar.isLeap(ty)
        val month = when {
            b.month == 5 && !tLeap -> 6           // born Adar I, target plain year -> Adar
            b.month == 6 -> 6                      // Adar / Adar II stays Adar (II in a leap year)
            else -> b.month
        }
        val date = gregorianOf(ty, month, b.day)
        val wd = weekday(date)
        val shabbat = plusDays(date, (Calendar.SATURDAY - wd + 7) % 7)
        return MitzvahDate(date, JewishCalendar.toHebrew(ymd(date).first, ymd(date).second, ymd(date).third), shabbat)
    }

    // ---------- Brit Milah / Pidyon HaBen ----------
    /** Brit on the 8th day (birth day counts as day 1; after sunset counts as the next day). */
    fun britMilah(birthMillis: Long, afterSunset: Boolean): Long = plusDays(dayStart(birthMillis), 7 + if (afterSunset) 1 else 0)

    /** Pidyon HaBen on day 31; if it falls on Shabbat or a Yom Tov it moves to the next weekday. */
    fun pidyonHaben(birthMillis: Long, afterSunset: Boolean, city: ZmanimCity): Long {
        var d = plusDays(dayStart(birthMillis), 30 + if (afterSunset) 1 else 0)
        repeat(4) {
            val (y, m, dd) = ymd(d)
            val info = JewishCalendar.day(y, m, dd, city)
            if (info.isShabbat || info.isYomTov) d = plusDays(d, 1) else return d
        }
        return d
    }

    // ---------- Fasts / Eruv Tavshilin / Yizkor ----------
    data class Fast(val name: String, val nameHe: String, val dayMillis: Long, val starts: Long?, val ends: Long?, val fromSunsetBefore: Boolean)

    /** Fast days in the next [days] days; Yom Kippur and Tisha B'Av start at the previous sunset, others at dawn. */
    fun upcomingFasts(fromMillis: Long, days: Int, city: ZmanimCity): List<Fast> {
        val out = mutableListOf<Fast>()
        for (i in 0..days) {
            val dm = plusDays(dayStart(fromMillis), i)
            val (y, m, d) = ymd(dm)
            val info = JewishCalendar.day(y, m, d, city)
            info.holidays.filter { it.fast }.forEach { f ->
                val full = f.he.contains("כיפור") || f.he.contains("באב")
                val start = if (full) { val (py, pm, pd) = ymd(plusDays(dm, -1)); JewishCalendar.day(py, pm, pd, city).sunset } else info.alot
                out += Fast(f.ka, f.he, dm, start, info.tzeit, full)
            }
        }
        return out
    }

    /** The day an Eruv Tavshilin is needed: eve of a Yom Tov that runs into Friday (so Shabbat food can be cooked). */
    fun eruvTavshilinDays(fromMillis: Long, days: Int, city: ZmanimCity): List<Long> {
        val out = mutableListOf<Long>()
        for (i in 0..days) {
            val dm = plusDays(dayStart(fromMillis), i)
            if (weekday(dm) != Calendar.FRIDAY) continue
            val (y, m, d) = ymd(dm)
            if (!JewishCalendar.day(y, m, d, city).isYomTov) continue
            var eve = plusDays(dm, -1)
            while (true) { val (a, b, c) = ymd(eve); if (JewishCalendar.day(a, b, c, city).isYomTov) eve = plusDays(eve, -1) else break }
            if (eve >= dayStart(fromMillis)) out += eve
        }
        return out
    }

    /** Yizkor is said on Yom Kippur, Shemini Atzeret, the last day of Pesach and Shavuot (last day in the diaspora). */
    fun nextYizkor(fromMillis: Long, city: ZmanimCity): Pair<Long, String>? {
        for (i in 0..400) {
            val dm = plusDays(dayStart(fromMillis), i)
            val (y, m, d) = ymd(dm)
            val h = JewishCalendar.day(y, m, d, city)
            val heb = h.heb
            val yes = (heb.month == 0 && heb.day == 10) || (heb.month == 0 && heb.day == 22) ||
                (heb.month == 7 && heb.day == (if (city.israel) 21 else 22)) || (heb.month == 9 && heb.day == (if (city.israel) 6 else 7))
            if (yes) return dm to (h.holidays.firstOrNull()?.ka ?: "")
        }
        return null
    }

    // ---------- Omer ----------
    private val sefirot = listOf("ხესედ", "გევურა", "თიფერეთ", "ნეცახ", "ჰოდ", "იესოდ", "მალხუთ")
    private val sefirotHe = listOf("חסד", "גבורה", "תפארת", "נצח", "הוד", "יסוד", "מלכות")

    /** Hebrew counting text for Omer day 1..49, e.g. "היום שמונה ימים שהם שבוע אחד ויום אחד לעומר". */
    fun omerText(n: Int): String {
        val w = n / 7; val d = n % 7
        val days = if (n == 1) "יום אחד" else "${n} ימים"
        val weeks = if (n < 7) "" else " שהם " + (if (w == 1) "שבוע אחד" else "$w שבועות") + (if (d == 0) "" else if (d == 1) " ויום אחד" else " ו־$d ימים")
        return "היום $days$weeks לעומר"
    }

    fun omerSefira(n: Int): Pair<String, String> {
        val inner = (n - 1) % 7; val outer = (n - 1) / 7
        return "${sefirot[inner]} შებე${sefirot[outer]}" to "${sefirotHe[inner]} שב${sefirotHe[outer]}"
    }

    // ---------- Tehillim ----------
    /** Splits the 150 psalms as evenly as possible between [people] readers, in order. */
    fun splitTehillim(people: Int): List<IntRange> {
        if (people <= 0) return emptyList()
        val n = people.coerceAtMost(150)
        val base = 150 / n; val rest = 150 % n
        var start = 1
        return (0 until n).map { i -> val size = base + if (i < rest) 1 else 0; (start until start + size).also { start += size } }
    }
}
