package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.settings.I18n
import com.example.ui.settings.L
import com.example.ui.theme.*

/** Occasions offered for a quick pledge; the gabbai can also type any other text. */
fun nederReasons(): List<String> = listOf(
    L("ზოგადი ნედერი"), L("ალიის დროს"), L("მი შებერახ"), L("იორცაიტი / აზკარა"), L("ავადმყოფის გამოჯანმრთელება"),
    L("ბარ-მიცვა"), L("ქორწილი"), L("ბავშვის დაბადება"), L("კიდუში"), L("სინაგოგის შენობა"), L("ცედაკა")
)

/** One-screen pledge entry: who, how much, why — saved as an unpaid pledge (or paid now). */
@Composable
fun QuickNederDialog(
    memberNames: List<String>,
    onAddMember: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: (name: String, amount: Double, currency: String, reason: String, paidNow: Boolean) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf(I18n.defaultCurrency) }
    var reason by remember { mutableStateOf(L("ზოგადი ნედერი")) }
    var paid by remember { mutableStateOf(false) }
    var showErrors by remember { mutableStateOf(false) }
    val amount = amountText.toDoubleOrNull() ?: 0.0

    FormDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.VolunteerActivism, null, tint = CosmicCelestialGold) },
        title = { Text(L("სწრაფი ნედერი") + " • נדר", fontWeight = FontWeight.Bold, color = CosmicTextPrimary) },
        text = {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).testTag("neder_dialog"), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                MemberField(label = L("ვინ დადო ნედერი"), value = name, onValueChange = { name = it }, memberNames = memberNames, onAddMember = onAddMember)
                if (showErrors && name.isBlank()) Text(L("აირჩიეთ ან ჩაწერეთ სახელი"), color = CosmicAlertRose, fontSize = 12.sp)
                AmountCurrencyField(label = L("თანხა"), amountText = amountText, onAmountChange = { amountText = it }, currency = currency, onCurrencyChange = { currency = it })
                // One-tap amounts for speed
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(18, 36, 100, 180).forEach { v ->
                        FilterChip(selected = amountText == v.toString(), onClick = { amountText = v.toString() }, label = { Text("$v", maxLines = 1, softWrap = false, color = CosmicTextPrimary, fontWeight = FontWeight.Bold) }, modifier = Modifier.weight(1f))
                    }
                }
                if (showErrors && amount <= 0) Text(L("მიუთითეთ თანხა"), color = CosmicAlertRose, fontSize = 12.sp)
                SuggestField(label = L("მიზეზი / შემთხვევა"), value = reason, onValueChange = { reason = it }, suggestions = nederReasons())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = paid, onCheckedChange = { paid = it })
                    Spacer(Modifier.width(10.dp))
                    Text(if (paid) L("გადახდილია ახლავე") else L("ვალად ჩაიწეროს (გადაიხდის მოგვიანებით)"), color = CosmicTextPrimary, fontSize = 14.sp)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank() && amount > 0) onSave(name.trim(), amount, currency, reason.trim(), paid) else showErrors = true
            }, colors = ButtonDefaults.buttonColors(containerColor = CosmicCelestialGold), modifier = Modifier.testTag("neder_save")) {
                Text(L("შენახვა"), color = CosmicOnAccent, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(L("გაუქმება"), color = CosmicTextSecondary, maxLines = 1) } },
        containerColor = CosmicDarkSurface
    )
}
