package com.example.ui.voice

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.example.ui.settings.I18n
import com.example.ui.settings.L
import java.util.Locale
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody

/** Returns a function that opens the system speech dialog in the app language and delivers the text. */
@Composable
fun rememberSpeechInput(onText: (String) -> Unit): () -> Unit {
    val context = LocalContext.current
    val cb by rememberUpdatedState(onText)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.takeIf { it.isNotBlank() }?.let { cb(it) }
        }
    }
    return remember {
        {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, I18n.lang.tag)
                .putExtra(RecognizerIntent.EXTRA_PROMPT, L("ილაპარაკეთ..."))
            try { launcher.launch(i) } catch (e: Exception) { Toast.makeText(context, L("ხმის ამოცნობა ამ მოწყობილობაზე მიუწვდომელია"), Toast.LENGTH_SHORT).show() }
        }
    }
}

/** Text-to-speech bound to the composition; speaks in the current app language. */
class Speaker(context: android.content.Context) {
    private val appContext = context.applicationContext.also { com.example.data.service.GeminiDirect.init(it) }
    private val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.Main)
    private var job: kotlinx.coroutines.Job? = null
    private var call: okhttp3.Call? = null
    private var track: android.media.AudioTrack? = null
    private var ready = false
    private val tts = TextToSpeech(appContext) { ready = it == TextToSpeech.SUCCESS }
    private val client = okhttp3.OkHttpClient.Builder().readTimeout(0, java.util.concurrent.TimeUnit.MILLISECONDS).build()
    var speaking by mutableStateOf(false); private set
    init {
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { if (id == "last") android.os.Handler(android.os.Looper.getMainLooper()).post { speaking = false } }
            override fun onError(id: String?) { android.os.Handler(android.os.Looper.getMainLooper()).post { speaking = false } }
        })
    }
    @Volatile private var gen = 0L
    fun speak(text: String) {
        if (text.isBlank()) return
        stop()
        val my = gen
        if (I18n.lang.tag.startsWith("ka") && com.example.data.service.GeminiDirect.hasKey()) {
            speaking = true
            job = scope.launch {
                var ok = false
                try {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { playWithOwnKey(text.replace("*", ""), my) }
                    ok = true
                } catch (e: kotlinx.coroutines.CancellationException) { throw e }
                catch (e: Exception) { android.util.Log.w("Speaker", "own key voice failed: ${e.message}") }
                if (gen != my) return@launch
                speaking = false
                // Own key missing quota/invalid -> free phone speaker
                if (!ok) speakNative(text)
            }
            return
        }
        speakNative(text)
    }
    private fun speakNative(text: String) {
        if (!ready) return
        tts.language = Locale.forLanguageTag(I18n.lang.tag)
        val chunks = text.replace("*", "").chunked(TextToSpeech.getMaxSpeechInputLength() - 10)
        chunks.forEachIndexed { i, c -> tts.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, if (i == chunks.lastIndex) "last" else "a$i") }
        speaking = true
    }
    private fun playWithOwnKey(text: String, my: Long) {
        val pieces = splitForSpeech(text)
        if (pieces.isEmpty()) return
        val pool = java.util.concurrent.Executors.newFixedThreadPool(2)
        try {
            // Prefetch pieces in parallel so playback starts after the short first sentence.
            val futures = pieces.map { p -> pool.submit(java.util.concurrent.Callable { if (gen == my) com.example.data.service.GeminiDirect.speech(p) else ByteArray(0) }) }
            val first = futures[0].get()
            if (gen != my) return
            val player = android.media.AudioTrack.Builder()
                .setAudioAttributes(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(android.media.AudioFormat.Builder().setSampleRate(24000).setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT).setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(48000, android.media.AudioTrack.getMinBufferSize(24000, android.media.AudioFormat.CHANNEL_OUT_MONO, android.media.AudioFormat.ENCODING_PCM_16BIT)))
                .setTransferMode(android.media.AudioTrack.MODE_STREAM).build()
            synchronized(this) { if (gen != my) { player.release(); return }; track = player }
            var frames = 0
            try {
                player.play()
                for (i in pieces.indices) {
                    val bytes = if (i == 0) first else runCatching { futures[i].get() }.getOrNull() ?: break
                    val size = bytes.size - bytes.size % 2
                    var pos = 0
                    while (pos < size) {
                        if (gen != my) return
                        val w = player.write(bytes, pos, minOf(4800, size - pos), android.media.AudioTrack.WRITE_BLOCKING)
                        if (w <= 0) return
                        pos += w
                    }
                    frames += size / 2
                }
                while (gen == my && player.playbackHeadPosition < frames) Thread.sleep(30)
            } finally {
                synchronized(this) { if (track === player) track = null }
                runCatching { player.pause(); player.flush(); player.stop() }; player.release()
            }
        } finally { pool.shutdownNow() }
    }
    fun stop() {
        synchronized(this) { gen++ ; val t = track; track = null; runCatching { t?.pause(); t?.flush() } }
        job?.cancel(); job = null; call?.cancel(); call = null; tts.stop(); speaking = false
    }
    fun shutdown() { stop(); scope.cancel(); tts.shutdown() }
}

/** Short first piece (first sentence) for a fast start, then ~500-char pieces at sentence boundaries. */
fun splitForSpeech(text: String): List<String> {
    val sentences = Regex("(?<=[.!?։\n])\\s+").split(text.trim()).filter { it.isNotBlank() }
    val out = mutableListOf<String>(); val cur = StringBuilder()
    for (s in sentences) {
        val limit = if (out.isEmpty()) 160 else 500
        if (cur.isNotEmpty() && cur.length + s.length + 1 > limit) { out += cur.toString(); cur.clear() }
        if (s.length > 500) { s.chunked(500).forEach { out += it }; continue }
        if (cur.isNotEmpty()) cur.append(' '); cur.append(s)
    }
    if (cur.isNotEmpty()) out += cur.toString()
    return out
}

@Composable
fun rememberSpeaker(): Speaker {
    val context = LocalContext.current
    val s = remember { Speaker(context) }
    DisposableEffect(Unit) { onDispose { s.shutdown() } }
    return s
}
