package com.example.ui.calendar

import com.example.data.model.YahrzeitEntity
import java.util.Calendar
import java.util.GregorianCalendar

data class UpcomingYahrzeit(val item: YahrzeitEntity, val dateMillis: Long, val daysUntil: Int)

object YahrzeitTools {
    fun gregorianForHebrew(year: Int, month: Int, day: Int): Long? = runCatching {
        android.icu.util.HebrewCalendar(year, month, day).timeInMillis
    }.getOrNull()

    fun upcoming(item: YahrzeitEntity, now: Long = System.currentTimeMillis()): UpcomingYahrzeit? {
        val today = GregorianCalendar().apply { timeInMillis = now; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val currentHebrewYear = JewishCalendar.toHebrew(today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1, today.get(Calendar.DAY_OF_MONTH)).year
        val candidates = (currentHebrewYear..currentHebrewYear + 1).mapNotNull { year ->
            gregorianForHebrew(year, item.hebrewMonth, item.hebrewDay)?.let { millis ->
                GregorianCalendar().apply { timeInMillis = millis; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            }
        }
        val target = candidates.firstOrNull { it >= today.timeInMillis } ?: return null
        return UpcomingYahrzeit(item, target, ((target - today.timeInMillis) / 86_400_000L).toInt())
    }

    fun within(items: List<YahrzeitEntity>, days: Int, now: Long = System.currentTimeMillis()) =
        items.mapNotNull { upcoming(it, now) }.filter { it.daysUntil in 0..days }.sortedBy { it.dateMillis }
}
