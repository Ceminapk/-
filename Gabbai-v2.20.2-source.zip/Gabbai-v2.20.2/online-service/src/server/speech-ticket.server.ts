const enc = new TextEncoder();
async function key(secret: string) { return crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']); }
export async function textHash(text: string) { return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(text))), b => b.toString(16).padStart(2, '0')).join(''); }
export async function issueSpeechTicket(text: string, secret: string) {
  const payload = btoa(JSON.stringify({ hash: await textHash(text), expires: Date.now() + 600000 }));
  const signature = await crypto.subtle.sign('HMAC', await key(secret), enc.encode(payload));
  return payload + '.' + btoa(String.fromCharCode(...new Uint8Array(signature)));
}
export async function verifySpeechTicket(text: string, ticket: string, secret: string) {
  try {
    const [payload, signature] = ticket.split('.');
    if (!payload || !signature) return false;
    const valid = await crypto.subtle.verify('HMAC', await key(secret), Uint8Array.from(atob(signature), c => c.charCodeAt(0)), enc.encode(payload));
    const data = JSON.parse(atob(payload));
    return valid && data.expires > Date.now() && data.hash === await textHash(text);
  } catch { return false; }
}
