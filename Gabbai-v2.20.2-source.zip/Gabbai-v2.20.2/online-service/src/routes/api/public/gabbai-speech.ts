import { createFileRoute } from '@tanstack/react-router';
import { z } from 'zod';
const Body = z.object({ text: z.string().min(1).max(12000), ticket: z.string().max(1000), offset: z.number().int().min(0).max(11999) });
export const Route = createFileRoute('/api/public/gabbai-speech')({ server: { handlers: {
  POST: async ({ request }) => {
    const parsed = Body.safeParse(await request.json().catch(() => null));
    if (!parsed.success) return Response.json({ message: 'Invalid speech request' }, { status: 400 });
    const secret = process.env['LOVABLE_API_KEY'];
    if (!secret) return Response.json({ message: 'Speech is not configured' }, { status: 503 });
    const { verifySpeechTicket } = await import('@/server/speech-ticket.server');
    if (!await verifySpeechTicket(parsed.data.text, parsed.data.ticket, secret)) return Response.json({ message: 'Ask the assistant again to authorize audio playback' }, { status: 401 });
    const { requestSpeech } = await import('@/server/speech-request.server');
    const upstream = await requestSpeech({ baseURL: 'https://ai.gateway.lovable.dev', apiKey: secret, model: 'google/gemini-3.1-flash-tts-preview', format: 'gemini', voice: 'Charon' },
      'Read aloud in natural Georgian, with clear Georgian pronunciation, calm pacing, and correct reading of names and currencies. Read only this text: ' + parsed.data.text.slice(parsed.data.offset, parsed.data.offset + 600), false, request.signal);
    const headers = new Headers({ 'Content-Type': upstream.headers.get('content-type') || 'text/event-stream', 'Cache-Control': 'no-store' });
    upstream.headers.forEach((value, name) => { if (name.toLowerCase().startsWith('x-lovable-aig-')) headers.set(name, value); });
    return new Response(upstream.body, { status: upstream.status, headers });
  }
} } });
