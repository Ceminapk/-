import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Body = z.object({
  question: z.string().min(1).max(2000),
  context: z.string().max(60000),
  language: z.enum(["ka", "ru", "en", "he"]).default("ka"),
});

const CLIENT_HEADER = "gabbai-cosmos-android";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type, x-gabbai-client",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...cors },
  });

export const Route = createFileRoute("/api/public/gabbai-ask")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: cors }),
      POST: async ({ request }) => {
        if (request.headers.get("x-gabbai-client") !== CLIENT_HEADER) {
          return json({ error: "forbidden" }, 403);
        }
        let parsed;
        try {
          parsed = Body.parse(await request.json());
        } catch {
          return json({ error: "invalid_input" }, 400);
        }
        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!apiKey) return json({ error: "not_configured" }, 500);

        const names = { ka: "Georgian", ru: "Russian", en: "English", he: "Hebrew" } as const;
        const lang = names[parsed.language];
        const summary = { ka: "მოკლე შეჯამება", ru: "Краткое резюме", en: "Summary", he: "סיכום" }[parsed.language];
        const system = `You are the AI navigator of Gabbai Cosmos, a synagogue administration app, and an expert in Jewish law and synagogue life.
You answer ANY question about:
1. How to use the app — use the APP GUIDE in the context and give exact step-by-step instructions (which button, which field).
2. The gabbai's duties and responsibilities (aliyot order and priorities: Kohen, Levi, chiyuvim such as yahrzeit, bar mitzvah, chatan; minyan, Torah reading, kaddish, kiddush, synagogue upkeep, tzedakah, honours).
3. Halacha in general and especially synagogue halacha (Shulchan Aruch, Mishnah Berurah, Sephardi and Ashkenazi customs where they differ): prayers, Shabbat, holidays, zmanim, mourning and yahrzeit, kashrut, tzedakah, Sefer Torah, mezuzah, tefillin, etc. Cite the source briefly. For a practical personal ruling, add a short note to consult the local rabbi.
4. The synagogue's own records (finances, members, tzedakah) — use ONLY the RECORDS in the context and never invent numbers.
IMPORTANT: For general halacha, customs, prayers, Shabbat/holiday law and any question not about this synagogue's own data (e.g. "may a hammer be moved on Shabbat?"), answer fully from your own knowledge. NEVER reply that the records or database do not contain the answer for such questions.
Reply in ${lang} (if the question is clearly written in another of Georgian/Russian/English/Hebrew, use that language). Keep Hebrew terms whole on one line.
Format: a clear direct answer first, then a section titled "${summary}" with 2-4 short bullet points. Be concise.`;

        const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            model: "google/gemini-3-flash-preview",
            messages: [
              { role: "system", content: system },
              { role: "user", content: `RECORDS:\n${parsed.context}\n\nQUESTION:\n${parsed.question}` },
            ],
          }),
        });
        if (res.status === 429) return json({ error: "rate_limited" }, 429);
        if (res.status === 402) return json({ error: "credits_exhausted" }, 402);
        if (!res.ok) return json({ error: "ai_error" }, 502);
        const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
        const answer = data.choices?.[0]?.message?.content ?? "";
        const { issueSpeechTicket } = await import('@/server/speech-ticket.server');
        return json({ answer, speechTicket: answer ? await issueSpeechTicket(answer, apiKey) : "" });
      },
    },
  },
});
