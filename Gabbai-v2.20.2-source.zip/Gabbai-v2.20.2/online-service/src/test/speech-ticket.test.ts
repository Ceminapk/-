import { describe, it, expect } from 'vitest';
import { issueSpeechTicket, verifySpeechTicket } from '../server/speech-ticket.server';
describe('answer-bound speech authorization', () => {
  it('accepts the original answer', async () => { const ticket = await issueSpeechTicket('გამარჯობა', 'test-only'); expect(await verifySpeechTicket('გამარჯობა', ticket, 'test-only')).toBe(true); });
  it('rejects altered text', async () => { const ticket = await issueSpeechTicket('გამარჯობა', 'test-only'); expect(await verifySpeechTicket('სხვა ტექსტი', ticket, 'test-only')).toBe(false); });
  it('rejects another signing key', async () => { const ticket = await issueSpeechTicket('გამარჯობა', 'test-only'); expect(await verifySpeechTicket('გამარჯობა', ticket, 'other')).toBe(false); });
  it('rejects expired tickets', async () => { const ticket = await issueSpeechTicket('გამარჯობა', 'test-only'); const original = Date.now; Date.now = () => original() + 700000; try { expect(await verifySpeechTicket('გამარჯობა', ticket, 'test-only')).toBe(false); } finally { Date.now = original; } });
});
