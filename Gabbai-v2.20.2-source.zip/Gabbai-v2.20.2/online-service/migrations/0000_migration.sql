CREATE TABLE public.synagogues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT '',
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.synagogue_users (
  synagogue_id uuid NOT NULL REFERENCES public.synagogues(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  email text NOT NULL DEFAULT '',
  role text NOT NULL CHECK (role IN ('owner','gabbai','deputy','treasurer')),
  joined_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (synagogue_id, user_id)
);
CREATE TABLE public.synagogue_invites (
  code text PRIMARY KEY,
  synagogue_id uuid NOT NULL REFERENCES public.synagogues(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('gabbai','deputy','treasurer')),
  created_by uuid NOT NULL,
  expires_at timestamptz NOT NULL DEFAULT now() + interval '7 days',
  used_by uuid
);
CREATE TABLE public.synagogue_data (
  synagogue_id uuid NOT NULL REFERENCES public.synagogues(id) ON DELETE CASCADE,
  section text NOT NULL CHECK (section IN ('members','finance','aliyot','registry')),
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  version integer NOT NULL DEFAULT 0,
  updated_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (synagogue_id, section)
);

GRANT SELECT ON public.synagogues TO authenticated;
GRANT SELECT ON public.synagogue_users TO authenticated;
GRANT SELECT ON public.synagogue_invites TO authenticated;
GRANT SELECT ON public.synagogue_data TO authenticated;
GRANT ALL ON public.synagogues, public.synagogue_users, public.synagogue_invites, public.synagogue_data TO service_role;

ALTER TABLE public.synagogues ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.synagogue_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.synagogue_invites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.synagogue_data ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.synagogue_role(_sid uuid)
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT role FROM public.synagogue_users WHERE synagogue_id = _sid AND user_id = auth.uid()
$$;

CREATE OR REPLACE FUNCTION public.can_read_section(_sid uuid, _section text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE public.synagogue_role(_sid)
    WHEN 'owner' THEN true WHEN 'gabbai' THEN true
    WHEN 'treasurer' THEN _section IN ('finance','members')
    WHEN 'deputy' THEN _section IN ('aliyot','members')
    ELSE false END
$$;

CREATE OR REPLACE FUNCTION public.can_write_section(_sid uuid, _section text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT CASE public.synagogue_role(_sid)
    WHEN 'owner' THEN true WHEN 'gabbai' THEN true
    WHEN 'treasurer' THEN _section = 'finance'
    WHEN 'deputy' THEN _section = 'aliyot'
    ELSE false END
$$;

CREATE POLICY "members see their synagogue" ON public.synagogues FOR SELECT TO authenticated
  USING (public.synagogue_role(id) IS NOT NULL);
CREATE POLICY "members see team" ON public.synagogue_users FOR SELECT TO authenticated
  USING (public.synagogue_role(synagogue_id) IS NOT NULL);
CREATE POLICY "owners see invites" ON public.synagogue_invites FOR SELECT TO authenticated
  USING (public.synagogue_role(synagogue_id) = 'owner');
CREATE POLICY "role-based read" ON public.synagogue_data FOR SELECT TO authenticated
  USING (public.can_read_section(synagogue_id, section));

CREATE OR REPLACE FUNCTION public.create_synagogue(_name text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE sid uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not signed in'; END IF;
  INSERT INTO public.synagogues(name, created_by) VALUES (left(coalesce(_name,''), 200), auth.uid()) RETURNING id INTO sid;
  INSERT INTO public.synagogue_users(synagogue_id, user_id, email, role)
    VALUES (sid, auth.uid(), coalesce(auth.jwt()->>'email',''), 'owner');
  RETURN sid;
END $$;

CREATE OR REPLACE FUNCTION public.create_invite(_sid uuid, _role text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE c text;
BEGIN
  IF public.synagogue_role(_sid) IS DISTINCT FROM 'owner' THEN RAISE EXCEPTION 'only the owner can invite'; END IF;
  IF _role NOT IN ('gabbai','deputy','treasurer') THEN RAISE EXCEPTION 'bad role'; END IF;
  c := upper(substr(replace(gen_random_uuid()::text,'-',''), 1, 8));
  INSERT INTO public.synagogue_invites(code, synagogue_id, role, created_by) VALUES (c, _sid, _role, auth.uid());
  RETURN c;
END $$;

CREATE OR REPLACE FUNCTION public.join_synagogue(_code text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE inv public.synagogue_invites;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'not signed in'; END IF;
  SELECT * INTO inv FROM public.synagogue_invites WHERE code = upper(trim(_code)) AND used_by IS NULL AND expires_at > now();
  IF NOT FOUND THEN RAISE EXCEPTION 'invite not valid'; END IF;
  INSERT INTO public.synagogue_users(synagogue_id, user_id, email, role)
    VALUES (inv.synagogue_id, auth.uid(), coalesce(auth.jwt()->>'email',''), inv.role)
    ON CONFLICT (synagogue_id, user_id) DO NOTHING;
  UPDATE public.synagogue_invites SET used_by = auth.uid() WHERE code = inv.code;
  RETURN inv.synagogue_id;
END $$;

CREATE OR REPLACE FUNCTION public.set_member_role(_sid uuid, _user uuid, _role text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF public.synagogue_role(_sid) IS DISTINCT FROM 'owner' THEN RAISE EXCEPTION 'only the owner'; END IF;
  IF _user = auth.uid() THEN RAISE EXCEPTION 'cannot change own role'; END IF;
  IF _role = 'remove' THEN DELETE FROM public.synagogue_users WHERE synagogue_id = _sid AND user_id = _user; RETURN; END IF;
  IF _role NOT IN ('gabbai','deputy','treasurer') THEN RAISE EXCEPTION 'bad role'; END IF;
  UPDATE public.synagogue_users SET role = _role WHERE synagogue_id = _sid AND user_id = _user;
END $$;

-- Optimistic write: succeeds only when the caller saw the latest version.
CREATE OR REPLACE FUNCTION public.push_section(_sid uuid, _section text, _data jsonb, _base_version integer)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE cur integer;
BEGIN
  IF NOT public.can_write_section(_sid, _section) THEN RAISE EXCEPTION 'no permission for this section'; END IF;
  SELECT version INTO cur FROM public.synagogue_data WHERE synagogue_id = _sid AND section = _section FOR UPDATE;
  IF NOT FOUND THEN
    INSERT INTO public.synagogue_data(synagogue_id, section, data, version, updated_by) VALUES (_sid, _section, _data, 1, auth.uid());
    RETURN 1;
  END IF;
  IF cur <> _base_version THEN RAISE EXCEPTION 'conflict: newer data on server (version %)', cur; END IF;
  UPDATE public.synagogue_data SET data = _data, version = cur + 1, updated_by = auth.uid(), updated_at = now()
    WHERE synagogue_id = _sid AND section = _section;
  RETURN cur + 1;
END $$;

REVOKE EXECUTE ON FUNCTION public.create_synagogue(text), public.create_invite(uuid,text), public.join_synagogue(text),
  public.set_member_role(uuid,uuid,text), public.push_section(uuid,text,jsonb,integer),
  public.synagogue_role(uuid), public.can_read_section(uuid,text), public.can_write_section(uuid,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_synagogue(text), public.create_invite(uuid,text), public.join_synagogue(text),
  public.set_member_role(uuid,uuid,text), public.push_section(uuid,text,jsonb,integer),
  public.synagogue_role(uuid), public.can_read_section(uuid,text), public.can_write_section(uuid,text) TO authenticated;