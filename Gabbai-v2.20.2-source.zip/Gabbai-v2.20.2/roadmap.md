# Roadmap

## v2.16 phase 1 (Android) — delivered
- [x] Sefer Torah passport, Pushke collection, Parochet/holy items, Genizah
- [x] Volunteer board, Kiddush sponsor calendar, Bikur cholim / shiva, New family onboarding, Rav questions
- [x] Women's & children's programs, Designated funds, Maintenance calendar, Tzedakah goal progress
- [x] Mezuzah/tefillin checks, Maaser tracker, Emergency message chain
- [x] Shabbat Shalom messenger, Hebrew name dictionary, Member timeline
- [x] Journal picker became a searchable dropdown; 4-language translations; tests; signed APK + source

## v2.16 phase 2 (2.16.2) — delivered
- [x] AI voice debrief after Shabbat (dictate honors/pledges → parsed into records)
- [x] PDF receipt + annual donation certificate (logo, seal, Hebrew date, WhatsApp share)
- [x] Bimah helper: Mi Shebeirach / Hazkara in 1 tap; Shabbat bimah plan sheet
- [x] Smart budget alarm; Minyan attendance stars; Annual meeting report (PDF)
- [x] Shabbat quiet mode (pause reminders)
- [x] Multi-gabbai sync with roles — online service and password sign-in implemented in 2.16.3.

## v2.16.4 — online team follow-up
- [x] Translate online team screens and common errors into Russian, English and Hebrew; no translation gaps.
- [x] Fix local-edit loss, sign-out baseline loss, pull-transaction race and initial concurrent server writes; test sync decisions and role matrix.
- [ ] End-to-end password sign-in and two-device synchronization — blocked: no confirmed online auth account exists.
- [x] Upgrade Georgian AI speech to Gemini 3.1 Flash TTS Preview; verify completed PCM audio through the app service and unauthorized-ticket rejection.
- [ ] Activate and listen to Georgian speech on a real phone — blocked: updated web service must be published; Android device unavailable.
- [x] Full Android test suite: 114 tests, zero failures; server authorization tests: 4 passed.
- [x] Deliver updated signed APK ZIP and clean source ZIP; final APK version and signature verified, targeted sync tests passed.

## v2.17 — delivered
- [x] Advance aliyot scheduler (priority hints, last-aliyah warning, WhatsApp/SMS, send to bimah)
- [x] 5 extra colour themes, font size, dome animation styles, synagogue emblem, haptics, daily auto backup
- [x] Shabbat bulletin PDF, finance chart, receipt photos, group SMS/WhatsApp, Bar/Bat mitzvah calculator, QR certificate verification
- [x] Netz countdown + spoken day times, dedication text generator, Kiddush/kashrut guide
- [x] New journals: seating chart, quick memo, bar mitzvah plan, VIP guests, audio guide, Havdalah supplies, Shabbat timers
